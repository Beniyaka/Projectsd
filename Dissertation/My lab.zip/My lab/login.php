<link rel="shortcut icon" href="./Ressources/IMG/logo.ico" type="image/x-icon"/>

<?php
define('INCLUDE_CHECK',true);
require './connect.php';
require './functions.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="/Ressources/CSS/main.css" rel="stylesheet"/>
  <title>Lab Helper System</title>
<link rel="stylesheet" href="/Ressources/CSS/main.css"/>

    <?php include("./baseInclude.php"); ?>
   	<?php		
	echo '<script type="text/javascript" >$(window).load(function(){ 
	setTimeout(function() {
  	$("#middle").css("visibility","visible");
  	$("#loading").hide();
	},500);
});</script>';


?>
  </head>
  <body onload="startTime()">

    <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		<div id="header">
		<img class="me" src="./Ressources/IMG/testt.jpg"/><img id="logo" src="./Ressources/IMG/logo.png"/><input required="true" type="button" value="Welcome" class="button" onclick="location.href='./login.php';" />
<div id="txt"></div><h1 id="text">Lab Helper System</h1>

</div>
		</div>
	</div>
	<?php
	if(isset($_POST['login'])){
	$username=$_POST['username'];
$password=md5($_POST['password']);

  if ($link->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
  }
  $row = mysqli_fetch_assoc(mysqli_query($link, "SELECT usr, accType FROM Users WHERE usr='{$_POST['username']}' AND pswd='".md5($_POST['password'])."' AND approvedUser='true' AND activeUser='true'"));
  if(isset($row['usr']))
  {
    	 $_SESSION['mysesi']=$row['usr'];
    	echo "<script>window.location.assign('./home.php')</script>";
	} 
   else{
echo'<div class="err">
  <p><strong>Warning!</strong><p> This username or password not same with database.</p>Please contact an administrator to reset your password</p>
</div>';
  }
  }
if(isset($_POST['register'])){
     $err = array();
	
	if(strlen($_POST['username'])<4 || strlen($_POST['username'])>32)
	{
		echo'<div class="err">
  <p><strong>Warning!</strong><p>Your username must be between 3 and 32 characters!</p>
</div>';
return;
	}
	
	elseif(preg_match('/[^a-z0-9\-\_\.]+/i',$_POST['username']))
	{
		echo'<div class="err">
  <p><strong>Warning!</strong><p>Your username contains invalid characters!</p>
</div>';
return;	
	}
	
	elseif(!checkEmail($_POST['email']))
	{
		echo'<div class="err">
  <p><strong>Warning!</strong><p>Your email is not valid!</p>
</div>';
		return;
	}
	
	elseif(preg_match('/[^a-z0-9\.]+/i',$_POST['accountType'])){
		echo'<div class="err">
  <p><strong>Warning!</strong><p>Please select an account type!</p>
</div>';
		return;
	}
	
	else
	{
		// If there are no errors
		
		$pass = substr(md5($_SERVER['REMOTE_ADDR'].microtime().rand(1,100000)),0,6);
		// Generate a random password
		
		$_POST['email'] = mysqli_real_escape_string($link, $_POST['email']);
		$_POST['username'] = mysqli_real_escape_string($link, $_POST['username']);
		// Escape the input data
		
		
		mysqli_query($link, "	INSERT INTO login_session(usr,pass,account_type,email,regIP,dt)
						VALUES(
						
							'".$_POST['username']."',
							'".md5($pass)."',
							'".$_POST['accountType']."',
							'".$_POST['email']."',
							'".$_SERVER['REMOTE_ADDR']."',
							NOW()
							
						)");
		
		if(mysqli_affected_rows($link)==1)
		{
			
			$message ="Please follow the following link to complete your registration:
			
			$domain_name/Registration/?pg=continueReg&session=$pass
						 ";
						 
			$to = $_POST['email']; 
			$subject = 'MyLab Registration - Registration Link';
		
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			$headers .= "Content-type: text/html\r\n";
			$headers = 'From: registration@mylab.macs.hw.ac.uk' . "\r\n" .
			'Reply-To: reply@example.com' . "\r\n" .
			'X-Mailer: PHP/' . phpversion();
			
			mail($to, $subject, $message, $headers);
			echo'<div class="success">
  <p><strong>Success!</strong><p>An email has been sent to '.$to.'. Thank you for using the Lab Helper System</p>
</div>';
		}
		else{
		echo'<div class="err">
  <p><strong>Warning!</strong><p>This username and/or email address is already taken!</p>
</div>';
		}
	}
}

if(isset($_POST['reset'])){
	if(!checkEmail($_POST['email']))
	{
		echo'<div class="err">
  <p><strong>Warning!</strong><p>Your email is not valid!</p>
</div>';
		
	}
	else{
		
		$row = mysqli_fetch_assoc(mysqli_query($link, "SELECT usr FROM Users WHERE email='{$_POST['email']}'"));
		$pass = substr(md5($_SERVER['REMOTE_ADDR'].microtime().rand(1,100000)),0,6);
		if($row['usr']== NULL && $row['usr']==""){
		echo'<div class="err">
  <p><strong>Error!</strong><p>Your email does not exist!</p>
</div>';
		}
		else{
		// Generate a random password
		
		$_POST['email'] = mysqli_real_escape_string($link, $_POST['email']);
		$type = "reset";
		// Escape the input data
		
		
		mysqli_query($link, "	INSERT INTO password(username,email,password, type)
						VALUES(
						
							'".$row['usr']."',
							'".$_POST['email']."',
							'".md5($pass)."',
							'".$type."'			
						)");
			
		if(mysqli_affected_rows($link)==1)
		{
			
			$message ="Please follow the following link to change your password:
			
			$domain_name/Reset/?pg=continueReg&pass=$pass
						 ";
						 
			$to = $_POST['email']; 
			$subject = 'MyLab Registration - Registration Link';
		
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			$headers .= "Content-type: text/html\r\n";
			$headers = 'From: password@mylab.macs.hw.ac.uk' . "\r\n" .
			'Reply-To: reply@example.com' . "\r\n" .
			'X-Mailer: PHP/' . phpversion();
			
			mail($to, $subject, $message, $headers);
			echo'<div class="success">
  <p><strong>Success!</strong><p>An email has been sent to '.$to.'. Thank you for using the Lab Helper System</p>
</div>';
		}
	}
}
}

if(isset($_POST['contact'])){
	if(!checkEmail($_POST['email']))
	{
		echo'<div class="err">
  <p><strong>Warning!</strong><p>Your email is not valid!</p>
</div>';
		
	}
	else{
		$row = mysqli_fetch_assoc(mysqli_query($link, "SELECT email FROM Users WHERE accType='Administrator'"));
			
			$message ="
			from: {$_POST['email']}
			
			ID: {$_POST['id']}
			
			Message: {$_POST['message']}";
						 
			$to = $row['email']; 
			$subject = $_POST['subject'];
		
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			$headers .= "Content-type: text/html\r\n";
			$headers = 'From: query@mylab.macs.hw.ac.uk' . "\r\n" .
			'Reply-To: reply@example.com' . "\r\n" .
			'X-Mailer: PHP/' . phpversion();
			
			mail($to, $subject, $message, $headers);
			echo'<div class="success">
  <p><strong>Success!</strong><p>Your message has been sent to an administrator. Thank you for using the Lab Helper System</p>
</div>';
	}	
}
?>
	
	<div class="row">
		<div class="col-md-12">
		<div id="nav3">
<li><a onclick="ben();">Reset Password</a></li>
<li><a onclick="beni();">Contact Administrator</a></li>
</div>
<div id="section" class="containers">
<button id="push"  onclick="be();">Register</button>
<button id="push1"  onclick="bent();" hidden="true">Login</button>

<div id="contact" style="display: none">
	<form method="post" action="" class="login">
	<input required="true" type="text" name="id" id="id"  placeholder="Heriot-Watt ID" autocomplete="off" >
	<p>
	<input required="true" type="text" name="email" id="email"  placeholder="Heriot-Watt Email address" autocomplete="off" ></p>
	<p>
	<input required="true" type="text" name="subject" id="subject"  placeholder="Subject" autocomplete="off" ></p>
	<p>
	<textarea name="message" id="message"  placeholder="Message" ></textarea></p>
	<p class="submit"><input type="submit" name="contact" value="Submit"></p>
</form>
</div>

<div id="test" style="display: none">
<form method="post" action="" class="login">
		<br /><select name="accountType" size="0" class="field"  autofocus>
						<option value="--Account Type--" >-- Account Type --</option>
						<option value="Helper">Helper</option>
 	 					<option value="Lecturer">Lecturer</option>
		 </select>
		<p><input required="true" type="text" name="email" id="email"  placeholder="Email" autocomplete="off" ></p>
       		 <p><input required="true" type="text" name="username" id="username" placeholder="Username" autocomplete="off" ></p>
       				<p class="submit"><input type="submit" name="register" value="Register"></p>
		<input type="hidden" name="Nscmd" value="Nlogin" />
	</form>
</div>

<div id="login">
<form method="post" action="" class="login">
			<p><input required="true"  type="text" name="username" id="username"  placeholder="Username" autocomplete="off" ></p>
       		 <p><input required="true" type="password" name="password" id="password" placeholder="Password" autocomplete="off"></p>
       				<p class="submit"><input type="submit" name="login" value="Login"></p>
	</form></div>

<div id="reset" style="display: none">
<form method="post" action="" class="login">
<label>Please input your email address</label>
	<p><input required="true" type="text" name="email" id="email"  placeholder="Email" autocomplete="off" ></p>
	<p class="submit"><input type="submit" name="reset" value="Reset"></p>
</form>
</div>

</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-12"><div id="footer">
<h3>This website was developed by <a href="http://ibktech.tk/en/Our-Team/#wb_element_instance149" style="text-decoration:none;"><span style="font-style:italic; font: 16px/1 Lobster,Arial,sans-serif;"> Beni Iyaka </span>.</a></h3>
</div>
		</div>
	</div>
</div>
  <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
    <script type="text/javascript" >
$(function() {
	$(".tabs a:last-child").css("border-radius","0px 6px 6px 0px");
	$(".tabs a:first-child").css("border-radius"," 6px 0px 0px 6px");
	$( "a", ".tabs" ).button();
});
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
function be(){
	$( "#push" ).hide();
  $( "#push1" ).show();
    $( "#test" ).slideDown( 1000, function() {
    $( this )
      .filter( ".middle" )
        .css( "background", "yellow" )
        .focus();
    $( "#login" ).hide();
    $("#contact").hide();
    $("#reset").hide();
  });	
	}
function ben(){
    $( "#reset" ).slideDown( 1000, function() {
    $( this )
      .filter( ".middle" )
        .css( "background", "yellow" )
        .focus();
    $( "#login" ).hide();
    $("#test").hide();
    $("#contact").hide();
    });

		
	}
function beni(){
    $( "#contact" ).slideDown( 1000, function() {
    $( this )
      .filter( ".middle" )
        .css( "background", "yellow" )
        .focus();
    $( "#login" ).hide();
    $("#test").hide();
    $("#reset").hide();
  });
  }
 function bent(){
    $( "#login" ).slideDown( 1000, function() {
    $( this )
      .filter( ".middle" )
        .css( "background", "yellow" )
        .focus();
    $( "#contact" ).hide();
    $("#test").hide();
    $("#reset").hide();
    $( "#push1" ).hide()
  $("#push").show();
  });
}

</script>
  </body>
</html>