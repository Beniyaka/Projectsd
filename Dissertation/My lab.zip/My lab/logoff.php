<?php
session_start();
session_destroy();
echo '<script>alert("Thank you for using Lab Helper System."</script>';
$home_url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/login.php';
header('Location: ' . $home_url);

?>