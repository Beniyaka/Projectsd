<?php
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<?php
define('INCLUDE_CHECK',true);
require '../connect.php';

session_name('mylabLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();

?>

<html>
<head>

</head>
<body>

<br /><h1>Permission Error you are logged on as: <?php echo $me; ?></h1>
<br /> You will be redirected to your homepage <br />
<p>This is a simple example site demonstrating the website look it might turn into. Simplz yez?</p>
<br /><br /><br /><br />

<?php
	echo '<meta HTTP-EQUIV="REFRESH" content="3; url='.$domain_name.'">';
?>
</body>

</html>