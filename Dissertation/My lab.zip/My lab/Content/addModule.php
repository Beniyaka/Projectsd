<?php 

define('INCLUDE_CHECK',true);

require '../connect.php';

$sqlNewModuleSkills = "INSERT INTO Skills (skillType, skillName) VALUES ";
for($i=0; $i<sizeof($_POST['newSkills']); $i++){
	if($i>0){ $sqlNewModuleSkills.=",";}
		$skillN=mysqli_real_escape_string($link,$_POST['newSkillType'][$i]);
		$skillT=mysqli_real_escape_string($link, $_POST['newSkills'][$i]);
     $sqlNewModuleSkills .= "(".$skillN.",'".$skillT."')";
}



$sqlModule = mysqli_prepare($link, "INSERT INTO Modules(mCode,mName,mTerm,mNotes) VALUES(?,?,?,?)");
mysqli_stmt_bind_param($sqlModule, 'ssds', $_POST['moduleCode'], $_POST['moduleName'], $_POST['moduleTerm'], $_POST['mNotes']);			
		
$moduleCode = mysqli_real_escape_string($link, $_POST['moduleCode']);

$sqlAddNewModuleSkills = "INSERT INTO ModuleSkillsRequired (moduleID, skillID) VALUES ";
for($i=0; $i<sizeof($_POST['newSkills']); $i++){
	if($i>0){ $sqlAddNewModuleSkills.=",";}
     $sqlAddNewModuleSkills .= "((SELECT mID FROM Modules WHERE mCode = '".$moduleCode."') ,(SELECT skillID FROM Skills WHERE skillName ='".mysqli_real_escape_string($link, $_POST['newSkills'][$i])."'))";
}

$sqlModuleSkills = "INSERT INTO ModuleSkillsRequired (moduleID, skillID) VALUES ";
for($i=0; $i<sizeof($_POST['skills']); $i++){
	if($i>0){ $sqlModuleSkills.=",";}
     $sqlModuleSkills .= "((SELECT mID FROM Modules WHERE mCode = '".$moduleCode."') ,".mysqli_real_escape_string($link, $_POST['skills'][$i]).")";
}

$sqlModuleLevels = "INSERT INTO ModuleLevels (moduleID, mLevel) VALUES ";
for($i=0; $i<sizeof($_POST['moduleLevels']); $i++){
	if($i>0){ $sqlModuleLevels.=",";}
   $sqlModuleLevels .= "((SELECT mID FROM Modules WHERE mCode='".$moduleCode."') ,".$_POST['moduleLevels'][$i].")";
}	

$sqlModuleTimes = "INSERT INTO Timetable (mID, ttDay, ttStartTime, ttEndTime, ttLocation, ttNoHelpers) VALUES ";
$counter = 0;
for($i=0; $i<sizeof($_POST['weekday']); $i++){
		$ttDay=mysqli_real_escape_string($link, trim($_POST['weekday'][$i]));
		$ttStartTime=mysqli_real_escape_string($link, trim($_POST['timetableTime1'][$i]));
		$ttEndTime=mysqli_real_escape_string($link, trim($_POST['timetableTime2'][$i]));
		$ttRoom=mysqli_real_escape_string($link, trim($_POST['room'][$i]));
		$ttNoHelpers=mysqli_real_escape_string($link, trim($_POST['helperNum'][$i]));
		$_POST['timetableWeeks'][$i]=mysqli_real_escape_string($link, trim($_POST['timetableWeeks'][$i]));
		
		if($_POST['timetableWeeks'][$i]!=null && $_POST['timetableWeeks'][$i]!=''){
			$weeks []= explode(",",$_POST['timetableWeeks'][$i]);
		}
		
	if($ttStartTime!="" && $ttStartTime!=null){
		if($counter>0){ $sqlModuleTimes.=",";}
		$sqlModuleTimes .= "((SELECT mID FROM Modules WHERE mCode='".$moduleCode."'),'".$ttDay."','".$ttStartTime."','".$ttEndTime."','".$ttRoom."',".$ttNoHelpers.")";
		$counter=$counter+1;
	}
}


if(mysqli_stmt_execute($sqlModule)){
	mysqli_stmt_close($sqlModule);
	if(isset($_POST['skills'])){
		mysqli_query($link, $sqlModuleSkills);
	}
	if(isset($_POST['newSkillType'])){
		mysqli_query($link, $sqlNewModuleSkills) or die(mysqli_error($link));
		mysqli_query($link, $sqlAddNewModuleSkills) or die(mysqli_error($link));
	}
	mysqli_query($link, $sqlModuleLevels) or die("Error: "+mysqli_error($link));
	mysqli_query($link, $sqlModuleTimes) or die("Error: "+mysqli_error($link));
	
	$id = mysqli_insert_id($link);
	$sqlttWeeks = 'INSERT INTO ModuleWeeks (ttID,week) VALUES ';
	
	for($x=0; $x<sizeof($weeks); $x++){
		if($x>0){ $sqlttWeeks.=",";}
	for($i=0; $i<sizeof($weeks[$x]); $i++){
			if($i>0){ $sqlttWeeks.=",";}
			$sqlttWeeks .= '('.$id.','.$weeks[$x][$i].')';
		}
		$id++;
	}
	mysqli_query($link, $sqlttWeeks) or die("Error: "+mysqli_error($link));
}

?>
