<?php

	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	define('INCLUDE_CHECK',true);
	require '../connect.php';

$sqlCheckRequests = mysqli_query($link, 'SELECT * FROM Helpers H
								ORDER BY (SELECT COUNT(*) FROM HelperSkills HS, ModuleSkillsRequired S 
								WHERE HS.helperID=H.hID AND HS.skillID = S.skillID AND S.moduleID=8) DESC')or die(mysqli_error($link));

while($row=mysqli_fetch_assoc($sqlCheckRequests)){
	echo $row['usr'].'<br>';	
}

?>