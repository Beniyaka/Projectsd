<?php

	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	
	define('INCLUDE_CHECK',true);
	$requireStuff = (isset($_POST['conn'])) ? $_POST['conn']:'../connect.php' ;
	require $requireStuff;
	
	$sqlRequest = 'INSERT INTO Requests (usrTo,ttID,seen) VALUES';
	for($i=0; $i<sizeof($_POST['usr']); $i++){
		if($i>0) $sqlRequest.=',';
		$sqlRequest .= ' (\''.$_POST['usr'][$i].'\','.$_POST['ttID'].',\'false\')';
	}
	mysqli_query($link, $sqlRequest) or die(mysqli_error($link));

?>