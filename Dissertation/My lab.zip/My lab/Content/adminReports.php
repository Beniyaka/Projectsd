	<title>Administrative Module reports - MyLab Helper Allocation System</title>

    <link rel="stylesheet" type="text/css" href="./Ressources/JS/jqplot/jquery.jqplot.min.css" />
    <link type="text/css" rel="stylesheet" href="./Ressources/JS/jqplot/examples/syntaxhighlighter/styles/shCoreDefault.min.css" />
    <link type="text/css" rel="stylesheet" href="./Ressources/JS/jqplot/examples/syntaxhighlighter/styles/shThemejqPlot.min.css" />
  <!--[if lt IE 9]><script language="javascript" type="text/javascript" src="./Ressources/JS/jqplot/excanvas.js"></script><![endif]-->


    <style type="text/css">
    	#chartBody div { margin-left: auto; margin-right: auto; }
    	.jqplot-title, .jqplot-point-label, table.jqplot-table-legend { 
    		color:#555555;
		}
		table.jqplot-table-legend {
			margin-left: 450px;
		}
		.jqplot-x2axis, .jqplot-x2axis-tick {
			color: red; display: none;
		}
		.example-content { width: 100%; margin: 0px; }
		#chartBody { margin:0px; padding: 0px; }
		
        .jqplot-target {
            margin: 20px;
            height: 340px;
            width: 70%;
            color: #dddddd;
        }

        .ui-widget-content {
            background: rgb(57,57,57);
        }
		
		
        table.jqplot-table-legend {
            border: 0px;
            background-color: rgba(100,100,100, 0.0);
        }

        .jqplot-highlighter-tooltip {
            background-color: rgba(57,57,57, 0.9);
            padding: 7px;
            color: #dddddd;
        }
		
		table { width: 30%; }
		
		td.jqplot-table-legend.jqplot-table-legend-label { overflow: hidden; white-space: pre-wrap;}
    </style>
   
      
   
<form id="selectYear" action="" method="GET" style="float:right;">
	<select name="years" id="years" onchange="this.form.submit()">
		<?php
			$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y WHERE T.termYearID=Y.tYearID ORDER BY T.termID DESC");
			while($row=mysqli_fetch_assoc($sqlTerms)){
				echo '<option value="'.$row['termID'].'" '.(($_GET['years']==$row['termID'])?"selected=\"selected\"":"").' >'.$row['tYearStart']."-".$row['tYearEnd'].": Semester ".$row['term'].'</option>';
				if(!isset($first)){ $first=$row['termID'];}
			}
		?>
	</select>
	<?php echo '<input type="hidden" name="pg" value="'.$_GET['pg'].'"/>'; ?>
</form>
<button type="button" class="noPrint" onclick="window.print()">Print</button><br />

<div id="chartBody" style="color: black;">

	<div id="chart1" style="height:450px; width:650px;"></div>
	<div class="code prettyprint">
		<pre class="code prettyprint brush: js"></pre>
	</div>
	<div class="charts1 dataTable"></div>
	<div id="chart2" style="height:450px; width:600px; page-break-before:always;"></div>
	<div class="code prettyprint">
		<pre class="code prettyprint brush: js"></pre>
	</div>

    <script type="text/javascript">

 $(document).ready(function () {
   $.jqplot._noToImageButton = true;
            
    <?php
      $helpers="var helpers =[";
      $totalMods="var totalModules =[";
      $rate="var rate =[";
      $hHoursMod="var hHours=[";
      $x=0;
      
      $sqlMoneyByTerm = mysqli_query($link,'select SUM(T.ttNoHelpers) AS helperNo, (SELECT COUNT(MM.mID) FROM Modules MM WHERE MM.mTerm=M.Mterm) AS totalModules, SUM(HOUR(TIMEDIFF(T.ttEndTime,T.ttStartTime))*T.ttNoHelpers*(SELECT COUNT(week) FROM ModuleWeeks MW WHERE T.ttID=MW.ttID)) AS totHours, SUM(HOUR(TIMEDIFF(T.ttEndTime,T.ttStartTime))*T.ttNoHelpers*(SELECT COUNT(week) FROM ModuleWeeks MW WHERE T.ttID=MW.ttID))*TM.helperRate AS termTotal, TM.helperRate, TM.term,TY.tYearStart, TY.tYearEnd, COUNT(T.ttID) as totalTTs FROM Timetable T, Terms TM, TermYears TY, Modules M WHERE M.mTerm=TM.termID AND T.mID=M.mID AND TY.tYearID=TM.termYearID GROUP BY M.mTerm;') or die(mysqli_error($link));
		while($rowTermTotal = mysqli_fetch_assoc($sqlMoneyByTerm)){
			if($x!=0) { 
				$helpers.=",";
				$totalMods.=",";
				$hHoursMod.=",";
				$rate.=",";
			}
			$trollface = $rowTermTotal['tYearStart']."-".$rowTermTotal['tYearEnd']." T".$rowTermTotal['term'];
		$helpers.="[\"".$trollface."\",".$rowTermTotal['termTotal']."]";
		$rate.="[\"".$trollface."\",".$rowTermTotal['helperRate']."]";
		$hHoursMod .= "[\"".$trollface."\",".$rowTermTotal['totHours']."]";
		$totalMods.="[".$rowTermTotal['totalModules'].",".$rowTermTotal['totHours'].",".$rowTermTotal['helperRate'].",".($rowTermTotal['helperNo']/$rowTermTotal['totalTTs'])."]";
			$x.=1;
		}
		$helpers.="];";
		$totalMods.="];";
		$hHoursMod.="];";
		$rate.="];";
		echo $helpers;  
		echo $totalMods;
		echo $hHoursMod;
		echo $rate;
    ?>

	var plot1DataTable = '<table border="1" style="width: 90%; margin-left: auto; margin-right: auto;"><tr><th>ID</th><th>Term</th><th># Modules</th><th>Hrs.</th><th>Rate (AED/hr)</th><th>Avg. H/M</th><th>Cost (AED)</th></tr>';
	for(var x=0;x<helpers.length; x++){
		plot1DataTable+='<tr><td style="text-align: center;">'+(x+1)+'</td><td style="text-align: center;">'+helpers[x][0]+'</td><td style="text-align: center;">'+totalModules[x][0]+'</td><td style="text-align: center;">'+totalModules[x][1]+'</td><td style="text-align: center;">'+(totalModules[x][2]).toFixed(2)+'</td><td style="text-align: center;">'+(totalModules[x][3]).toFixed(2)+'</td><td style="text-align: right;">'+(helpers[x][1]).toFixed(2)+'</td></tr>';
	}
	$(".charts1.dataTable").html(plot1DataTable+"</table>");

 //{xaxis:'xaxis', yaxis:'y2axis', label: 'Helper Hours per Term'}
  var plot1 = $.jqplot('chart1', [helpers, hHours], {
  	 title:"Helper Cost and Time Overview",
    series:[{xaxis:'xaxis', yaxis:'yaxis', label: 'Term Cost'}, {xaxis:'x2axis', yaxis:'y2axis', label: 'Helper Hours per Term',renderer:$.jqplot.BarRenderer, pointLabels:{ypadding: 1,show:true, stackedValue: true}}],
    axesDefaults: {
        tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
        tickOptions: {
          angle: -30
        }
    },
    axes: {
      xaxis: {
        renderer: $.jqplot.CategoryAxisRenderer,
        label:'Terms',
        labelRenderer: $.jqplot.CanvasAxisLabelRenderer
      },
      x2axis: {
        renderer: $.jqplot.CategoryAxisRenderer,
        label:'Terms',
        labelRenderer: $.jqplot.CanvasAxisLabelRenderer
      },
      yaxis: {
        autoscale:true,
        tickOptions:{
         formatString:'AED%.2f',
        	angle: 0
        },
        label:'Total Cost(AED)',
        labelRenderer: $.jqplot.CanvasAxisLabelRenderer
      },
      y2axis: {
        	autoscale:true,
        	tickOptions:{
        		angle: 0
        	},
        	label:'Helper Hours',
        	labelRenderer: $.jqplot.CanvasAxisLabelRenderer
      }
    },
    highlighter: {
      show: true,
      sizeAdjust: 7.5,
      useAxesFormatters: true,
    	tooltipAxes: 'both'
    },
    cursor: {
      show: false
    },
    legend: {
	    show: true,
       location: 's',     // compass direction, nw, n, ne, e, se, s, sw, w.
       placement: 'outsideGrid'
   },
}).moveSeriesToFront(0);



 <?php
      $helpHours="var helpHours =[";
      $x=0;
      $_GET['years']=(!isset($_GET['years']))?$first:$_GET['years'];
      
      $sqlThisTerm = mysqli_query($link,'select M.mCode,M.mName, SUM(HOUR(TIMEDIFF(T.ttEndTime,T.ttStartTime))*T.ttNoHelpers*(SELECT COUNT(week) FROM ModuleWeeks MW WHERE T.ttID=MW.ttID)) As mHours from Timetable T, Modules M WHERE T.mID=M.mID AND M.mTerm='.$_GET['years'].' GROUP BY M.mID') or die(mysqli_error($link));
		while($rowTermTotal = mysqli_fetch_assoc($sqlThisTerm)){
			if($x!=0) { 
				$helpHours.=",";
			}
		$helpHours.="[\"".$rowTermTotal['mCode']."\",".$rowTermTotal['mHours']."]";
		$x.=1;
		}
		$helpHours.="];";
		echo $helpHours;
		echo $term="";
    ?>

 
  var plot2 = $.jqplot('chart2', [helpHours], {
    title: 'Helper Hours per Module - '+($("option:selected").html()),
    seriesDefaults: {
          renderer: $.jqplot.BarRenderer,
          pointLabels:{show:true, stackedValue: true},
          padding: 20,
          label: 'Helper Hours per Module'
      },
    axesDefaults: {
        tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
        tickOptions: {
          angle: -30,
          fontSize: '10pt'
        }
    },
    axes: {
      xaxis: {
        renderer: $.jqplot.CategoryAxisRenderer,
        labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
        label: 'Modules by Code'
      },
      yaxis:{
      	tickOptions: {
          angle: 0,
          fontSize: '10pt'
        },
        labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
        label: "Total Helper Hours for Term"
      }
    },
     legend: {
        show: true,
        location: 's',     // compass direction, nw, n, ne, e, se, s, sw, w.
        placement: 'outsideGrid'
    }
  });




});


    </script>


<!-- End example scripts -->

<!-- Don't touch this! -->


    <script type="text/javascript" src="./Ressources/JS/jqplot/jquery.jqplot.min.js"></script>

<!-- End Don't touch this! -->

<!-- Additional plugins go here -->
<script type="text/javascript" src="./Ressources/JS/jqplot/plugins/jqplot.highlighter.min.js"></script>
<script type="text/javascript" src="./Ressources/JS/jqplot/plugins/jqplot.cursor.min.js"></script>
<script type="text/javascript" src="./Ressources/JS/jqplot/plugins/jqplot.dateAxisRenderer.min.js"></script>
<script type="text/javascript" src="./Ressources/JS/jqplot/plugins/jqplot.canvasTextRenderer.min.js"></script>
<script type="text/javascript" src="./Ressources/JS/jqplot/plugins/jqplot.canvasAxisLabelRenderer.min.js"></script>
<script type="text/javascript" src="./Ressources/JS/jqplot/plugins/jqplot.canvasAxisTickRenderer.min.js"></script>
<script type="text/javascript" src="./Ressources/JS/jqplot/plugins/jqplot.categoryAxisRenderer.min.js"></script>
<script type="text/javascript" src="./Ressources/JS/jqplot/plugins/jqplot.barRenderer.min.js"></script>
<script type="text/javascript" src="./Ressources/JS/jqplot/plugins/jqplot.pointLabels.min.js"></script>


<!-- End additional plugins -->


</div>
