<?php 
	if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>


<title>Change Details - MyLab Helper Allocation</title>

<style type="text/css">

	form span { padding: 10px; }
	.ok { background-color: #D3EEAB; }
	.no { background-color: #edabac; }
	form span input { font-size: 1.2em;  }
	#submitFormD { font-size: 1em; padding: 3px; }

</style>


<script type="text/javascript" >



	$( "#newPassFormD" ).submit(function(event) {
		event.preventDefault();
		$(".viewResult").html("");
		var pass=0;
		
		$(".error").html("");	
		$(".ok").removeClass("ok");
		$(".no").removeClass("no");
		
		if( $("#firstName").val()=="" || $("#firstName").val()==null ){ 
			$("#firstName").parent().addClass("no");
			$("#firstNameError").html("Please enter a first name");
			pass=1;
		}else {
			$("#firstName").parent().addClass("ok");
		}

		if( $("#lastName").val()=="" || $("#lastName").val()==null ){ 
			$("#lastName").parent().addClass("no");
			$("#lastNameError").html("Please enter a last name");
			pass=1;
		}else {
			$("#lastName").parent().addClass("ok");
		}
		
		if( isNaN($("#phone").val()) && ($("#phone").val()=="" || $("#phone").val()==null) && $("#phone").val().length<13 ){ 
			$("#phone").parent().addClass("no");
			$("#phoneError").html("must be a number");
			pass=1;
		}else {
			$("#phone").parent().addClass("ok");
		}
		
		if(pass==0){
			$.post('./Content/settingsChangeDetails.php', $("#newPassFormD").serialize(), function(data) {
					$(".viewResult").append(data);
			});
		}
		
	});
	


</script>

<div class="viewResult"></div>

<form id="newPassFormD" action="/">
<?php
	$sqlGetDetails = "";
	if($me=="Lecturer"){
		$sqlGetDetails = mysqli_query($link, "SELECT lFirstName AS firstName, lSurname AS lastName, lphone AS phone FROM Lecturers WHERE usr='".$_SESSION['mysesi']."' LIMIT 1") or die(mysqli_error($link));
   }elseif($me=="Helper"){
   	$sqlGetDetails = mysqli_query($link, "SELECT hFirstName AS firstName, hSurname AS lastName, hphone AS phone FROM Helpers WHERE usr='".$_SESSION['mysesi']."' LIMIT 1") or die(mysqli_error($link));
   }
   $rowd=mysqli_fetch_assoc($sqlGetDetails);
		echo '<label for="oldPass">First Name</label><br />
			<span><input type="text" name="firstName" id="firstName" class="input" value="'.$rowd['firstName'].'" /><span id="firstNameError" class="error"></span></span><br /><br />';
		echo '<label for="lastName">Last Name</label><br />
			<span><input type="text" name="lastName" id="lastName" class="input" value="'.$rowd['lastName'].'" /><span id="lastNameError" class="error"></span></span><br /><br />';
		echo '<label for="phone">Phone</label><br />
			<span><input type="text" name="phone" id="phone" class="input" value="'.$rowd['phone'].'" /><span id="phoneError" class="error"></span></span><br /><br />';
		echo '<input id="submitForm" name="submitForm" value="Save Details" class="input" type="submit"/>';
	
?>
</form>
