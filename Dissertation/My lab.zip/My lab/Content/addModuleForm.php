<?php 
$em=0;
if(isset($_GET['mID'])){
	$_GET['mID']=mysqli_real_escape_string($link, $_GET['mID']);
	$sqlEdit = mysqli_query($link, "SELECT M.mName, M.mCode, M.mTerm, M.mNotes FROM Modules M WHERE M.mID=".$_GET['mID']." LIMIT 1") or die(mysqli_error($link));
	$sqlEditTT = mysqli_query($link, "SELECT T.ttDay, T.ttLocation, T.ttStartTime, T.ttEndTime, T.ttNoHelpers, T.ttNotes, (select group_concat(MW.week separator ',') FROM ModuleWeeks MW WHERE MW.ttID=T.ttID) AS weeks FROM Timetable T WHERE T.mID=".$_GET['mID']) or die(mysqli_error($link));
	$EditName=mysqli_fetch_assoc($sqlEdit);
	$em=1;
}
?>

<?php 
	$skillTypes = '<script type="text/javascript" >var skillTypeList = "';
	$sqlTerms = mysqli_query($link, "SELECT typeName, typeID FROM SkillType");
	$skillTypes .= '<select name=\"newSkillType[]\">';
	while($row2=mysqli_fetch_assoc($sqlTerms)){
		$skillTypes.= '<option value=\"'.$row2['typeID'].'\" >'.$row2['typeName'].'</option>';
	}
	$skillTypes.= '</select>";';
	
	$sqlTermsNum = mysqli_query($link, "SELECT COUNT(mLevel) AS typeCount FROM ModuleLevelNames LIMIT 1");
	$row2=mysqli_fetch_assoc($sqlTermsNum);
	$skillTypes.='var maxCourseLevels = '.$row2['typeCount'].';</script>';
	echo $skillTypes;
?>


<style type="text/css">
	html { font-size: 1em; }
	label { font-size: 1em; font-weight: bold; }
	form { width: 100%; }
	#submit { font-size:1em; padding: 5px 20px; }
	
	.error { color: red; }
	.module { border: 3px inset #cde5ef; background: #cde5ef; border-radius: 4px; padding: 10px; }
	
	#moduleInfoMain { width: 190px; }
	#addCourseLevelMain { float: right; width: 170px; }
	#addCourseTimesMain { float: right; width: 280px; margin-left: 20px; }
	#skillsMain { width: 400px; }
	#newSkillsMain { border: 2px solid #cde5ef; background: #cde5ef; border-radius: 4px; width: 310px; }
	#moduleNotes { display: inline-block;  width: 280px; clear: right; float: right; margin-top: 20px;} 
	
</style>


<script type="text/javascript" >

$(document).ready(function(){
	var courseLevelList = $("#addCourseLevel").html();
	var newSkillsCount = 0;
	var courseCount = 0;
	
	$("#addSkill").click(function(){
		$("#newSkills").prepend("<div id=\"newSkill"+newSkillsCount+"\"><input type=\"text\" class=\"newSkill\" name=\"newSkills[]\" />"+skillTypeList+"</div>");
		newSkillsCount++;

	});
	
	$("#rmvSkill").click(function(){
		if((newSkillsCount-1)>=0){
			$("#newSkill"+(newSkillsCount-1)).remove();
			if((newSkillsCount)!=0) newSkillsCount--;
		}
	});
	
	$("#addLevel").click(function(){
		if(courseCount < maxCourseLevels-1){
			$("#addCourseLevel").prepend(courseLevelList);
			courseCount++;
		}
	});
	
	$("#rmvLevel").click(function(){
		if(courseCount>0){
			$("#addCourseLevel select:lt(1)").remove();
			courseCount--;
		}
	});
	
	
	
	$('#submit').click(function() {
		var pass=0;
		
		$(".error").html("");		
		
		if( ($("#moduleName").val()=="" || $("#moduleName").val()==null) || ($("#moduleCode").val()=="" || $("#moduleCode").val()==null) ){ 
			$("#moduleNameError").html("Please fill out both name boxes.");
			pass=1;
		}
		
		// Check that at least one skill is chosen
		var is_checked = 0;
		$(".skills").each(function(index){ 
			if(this.checked){	is_checked ++;	}
		});
		if(is_checked==0){
			if( $("#newSkill0 input").val()=="" || $("#newSkill0 input").val()==null ){
				pass=1;
				$("#skillError").html("Please select at least one skill from below.");
			}
		}
		var is_checked = 0;
		$(".newSkills").each(function(index){ 
			if(this.value=="" || this.value==null){	is_checked ++;	}
		});
		
		// Check that information is inputed for timetable info
		var is_checked = 0;
		$(".classes").each(function(){ 
			if(!(/^([0-9]{1,2}(,[0-9]{1,2}){0,11})$/.test($(this).find(".timetableWeeks").val()))){
				$(this).find("div .weeksError").html("<br />Please write the weeks in the following comma seperatedformat: 1,2,3,4,5");
				pass=1;
			}
			if(isNaN($(this).find(".thelperNum").val()) || $(this).find(".thelperNum").val()<1){
				$(this).find("div .helpersNumError").html("<br />Must be a number, 2 digits or less.");
				pass=1;
			}
			if($(this).find(".troom").val().length<1){
				$(this).find("div .roomError").html("<br />Please enter a room location");
				pass=1;
			}
		});
		
		
		if(pass==0){
			if($("#editConf").length){
				$.post('./Content/updateModule.php', $("#moduleForm").serialize(), function(data) {
			 		alert(data+"The module has been added.");
			 	});
			}else{
				$.post('./Content/addModule.php', $("#moduleForm").serialize(), function(data) {
			 		alert(data+"The module has been added.");
			 	});
			}
		}
	});
	
	var courses=1;
	var addit= $("#timetableContent").html();

	$("#addClass").click(function(){
		$("#timetableContent").append(addit);
		courses+=1;
	});	
	$("#rmvClass").click(function(){
		if(courses>1){
			$(".classes").last().remove();
			courses-=1;;
		}
	});
	
	$(".timetableTime1").live("change",function(){
		var selected=$(this).prop("selectedIndex");
		var parent = $(this).parent();
		parent.find(".timetableTime2 option").removeAttr("disabled");
		for(var x=0; x<selected ;x++){
			parent.find(".timetableTime2 option:eq("+x+")").attr("disabled","disabled");
		}
		parent.find(".timetableTime2").prop("selectedIndex",selected);
	});
	
});

</script>

<title>Create Module - MyLab Helper Allocation</title>


<form method="post" id="moduleForm" name="moduleForm">
	<?php if($em==1) echo '<input type="hidden" value="'.$_GET['mID'].'" name="mID" id="editConf"/>'; ?>
	
	<div id="addCourseTimesMain" class="module">
	<label for="addCourseTimes">Course Timetable</label>
		<?php  include("./Content/picker.php"); ?>
	</div>	

	<div id="addCourseLevelMain" class="module">
	<label for="addCourseLevel">Course Level(s)</label><br />
		<button type="button" name="addModuleYear" id="addLevel" style="width: 70px;" >add</button>
		<button type="button" name="rmvModuleYear" id="rmvLevel" style="width: 70px;">remove</button><br />
		<div id="addCourseLevel">
			<?php
				$sqlYears = mysqli_query($link, "SELECT mLevel, mLevelID FROM ModuleLevelNames") or die(mysqli_error($link));
				echo '<select name="moduleLevels[]">';
				while($row=mysqli_fetch_assoc($sqlYears)){
					echo '<option value="'.$row['mLevelID'].'" >'.$row['mLevel'].'</option>';
				}
				echo '</select>';
			?>
		</div>
	</div>
	
	<div id="moduleNotes" class="module">
		<h3>Notes</h3><br>
		<textarea name="mNotes" id="mNotes" cols="31" rows="5"><?php echo ($em==1)?$EditName['mNotes']:""; ?></textarea>
	</div>
	
	<div id="moduleInfoMain" class="module">
		<label for="moduleName">Module Name</label><br />
			<?php echo '<input name="moduleName" id="moduleName" '.(($em==1)?"value=\"".$EditName['mName']."\"":"").' /><br />'; ?>
		<label for="moduleCode">Module Code</label><br />
			<?php echo '<input name="moduleCode" id="moduleCode" '.(($em==1)?"value=\"".$EditName['mCode']."\"":"").' /><br />'; ?>
		<!-- ADD TIMETABLE -->
		<label>Module Semester</label><br />
		<?php
			
			$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y WHERE T.termYearID=Y.tYearID ORDER BY T.termID DESC");
			echo '<select name="moduleTerm">';
			while($row=mysqli_fetch_assoc($sqlTerms)){
				$ee=""; // select if in edit mode
				if($em==1){ $ee=($EditName['mTerm']==$row['termID'])?" selected=\"selected\"":""; }
				echo '<option value="'.$row['termID'].'"'.$ee.' >'.$row['tYearStart']."-".$row['tYearEnd'].": Semester ".$row['term'].'</option>';
			}
			echo '</select>';
		?>
	<span id="moduleNameError" class="error"></span><br />
	</div>
	
	<br />
	<div id="skillsMain" class="module"><span id="skillError" class="error"></span>
		<?php
			getSkillsTable($link,(isset($_GET['mID'])? $_GET['mID'] : -1));
		?>
		
		<br />
		<div id="newSkillsMain">
			<button type="button" name="addSkill" id="addSkill">Add New Skill</button><button type="button" name="rmvSkill" id="rmvSkill">Remove new Skill</button><br />
			<div id="newSkills"></div>
		</div>
		<br />
	</div>
	<br />
	
	
	<button id="submit" name="submitModule" value="submitModule" type="button">Save Module</button>
	
	<div style="clear:both;"> </div>
</form>

<?php
		 if($em==1){
		 	echo '<script type="text/javascript">$(function(){';
		 	$xf=0;
		 	echo 'var parent = "";';
		 	while($ttRow=mysqli_fetch_assoc($sqlEditTT)){
		 		if($xf!=0){
		 			echo '$("#addClass").click();';
		 		}
		 		echo 'parent = $(".classes").last();
		 		parent.find(".timetableWeeks").val("'.$ttRow['weeks'].'");
		 		parent.find(".thelperNum").val("'.$ttRow['ttNoHelpers'].'");
		 		parent.find(".troom").val("'.$ttRow['ttLocation'].'");
		 		parent.find(".weekday").val("'.$ttRow['ttDay'].'");
		 		parent.find(".timetableTime1").val("'.$ttRow['ttStartTime'].'");
		 		parent.find(".timetableTime2").val("'.$ttRow['ttEndTime'].'");';
		 		$xf=$xf+1;
		 	}
		 	echo '});</script>';
		 
		 }		
		?>
