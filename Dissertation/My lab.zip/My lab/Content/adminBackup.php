<?php
	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	

		define('INCLUDE_CHECK',true);
		require '../connect.php' ;
		
		$dumpfile = "./backups".$db_database . "_" . date("Y-m-d_H-i-s") . ".sql";
		
		system("C:\wamp\bin\mysql\mysql5.6.17\bin\mysqldump.exe -h localhost -uroot  mylab  > $dumpfile");
		// must look like "-- Dump completed on ..." 
		system("tail -1 $dumpfile");
	
	
?>