<title>MyLab Settings</title>

<style type="text/css">
	#settingsMenu button {
	height: 120px; width: 120px; font-size: 1.2em; margin: 10px; float: left; text-align: center;
  font-weight: bold;
  color: #527881;
  text-shadow: 0 1px #e3f1f1;
  background: #cde5ef;
  border: 1px solid;
  border-color: #b4ccce #b3c0c8 #9eb9c2;
  border-radius: 16px;
  outline: 0;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  -webkit-box-shadow: inset 0 1px white, 0 1px 2px rgba(0, 0, 0, 0.15);
  box-shadow: inset 0 1px white, 0 1px 2px rgba(0, 0, 0, 0.15); }
	
	button img { height: 55px; width: auto; }
	table { border: 1px solid black; border-collapse: collapse; }
	th { border: 1px solid black; font-size: 1em; font-weight: bold; padding: 5px; }
	td { border: 1px solid black; font-size: 1em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; padding: 5px;}
</style>

<script>
	$(function() {
		$( "button", "#settingsMenu" ).button();
		$( "button", "#settingsMenu" ).click(function() { 
			$("#settingsMenu").hide("slide", { direction: "left" }, 500);
			$("#"+$(this).attr("class").split(" ")[0]).delay(500).show("slide", { direction: "right" }, 1000);
		});
	});
</script>

<body>

<div id="settingsMenu">
	<?php 
		/* (1)EDIT PASSWORD - (2)EDIT DETAILS - (3)DISABLE ACCOUNT */
		/*1*/ if($yes==2) echo '<button type="button" class="addNews ui-widget-content"><img src="./Ressources/IMG/news.png" /><br/>Edit News</button> ';
		/*2*/ echo '<button type="button" class="changePassword ui-widget-content"><img src="./Ressources/IMG/password.png" /><br/>Change Password</button> ';
		/*3*/ if($yes!=2) echo '<button type="button" class="editDetails ui-widget-content"><img src="./Ressources/IMG/pen.png" /><br/>Edit Details</button> ';
		if($yes==2) echo'<button type="button" class="listusers ui-widget-content"><img src="./Ressources/IMG/list.png"/><br />List All Users</button>';
		/*4*/ if($yes!=2) echo '<button type="button" class="disableAccount ui-widget-content"><img src="./Ressources/IMG/skull.and.crossbones.png" /><br/>Disable Account</button> ';

		/*6*/ if($yes==2) echo '<button type="button" class="backupData ui-widget-content"><img src="./Ressources/IMG/backup.png" /><br/>Back-up Database</button> ';
		/*7*/ if($yes==2) echo '<button type="button" class="restoreData ui-widget-content"><img src="./Ressources/IMG/restore.png" /><br/>Restore Database</button> ';
		/*8*/ if($yes==2) echo '<button type="button" class="editRates ui-widget-content"><img src="./Ressources/IMG/currency_black_pound.png" /><br/>Edit Rates</button> ';
		/*9*/ if($yes==2) echo '<button type="button" class="editSemester ui-widget-content"><img src="./Ressources/IMG/add.png" /><br/>Add Semester</button> ';
	?>
	<div style="clear: both;"></div>
</div>
<div id="addNews" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/newsForm.php'); ?></div>
<div id="changePassword" class="chosenSetting" style="display: none;"><?php include('./Content/settingsChangePasswordForm.php'); ?></div>
<div id="editDetails" class="chosenSetting" style="display: none;"><?php if($yes!=2) include('./Content/settingsChangeDetailsForm.php'); ?></div>
<div id="disableAccount" class="chosenSetting" style="display: none;"><?php if($yes!=2) include('./Content/settingsDisableAccountForm.php'); ?></div>
<div id="permittedEmails" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsPermittedEmailsForm.php'); ?></div>
<div id="backupData" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsBackupForm.php'); ?></div>
<div id="restoreData" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsRestoreForm.php'); ?></div>
<div id="editRates" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsEditRatesForm.php'); ?></div>
<div id="editSemester" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsEditSemesterForm.php'); ?></div>
<div id="listusers" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/listAllUsers.php'); ?></div>

</body>
</html>