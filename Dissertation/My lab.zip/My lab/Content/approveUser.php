<?php
define('INCLUDE_CHECK',true);
require '../connect.php';
require '../functions.php';

session_start();
$me = "Administrator";
$answer = mysqli_real_escape_string($link, trim($_POST['answer']));

if($me=='Administrator'){
	if($answer=='true'){
		$sqlApproveUser = mysqli_query($link, "UPDATE Users SET approvedUser='".$answer."' WHERE usr='".$_POST['usr']."'") or die(mysqli_error($link));
		
		mail(($_POST['email']),
						'MyLab Registration Accepted',
						'An administrator has accepted your application to use the MyLab system.');
			 			 echo'<script>alert("User approved")</script>';			 	
		
	}else{
			$sqlApproveUser = mysqli_query($link, "DELETE FROM Users WHERE usr='".$_POST['usr']."'") or die(mysqli_error($link));
			mail(trim($_POST['email']),
						'MyLab Registration Rejected',
						'An administrator has Rejected your application to use the MyLab system.');
			 			 echo'<script>alert("User Rejected")</script>';			 	
			}
}

?>