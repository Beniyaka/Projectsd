<html>
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
<script type="text/javascript">
$(function() {
// Handler for .ready() called.
$('#SubmitForm').submit(function( event ) {

    $.ajax({
            url: './addModuleForm.php',
            type: 'POST',
            dataType: 'html',
            data: $('#SubmitForm').serialize(),
            success: function(content)
            {
                $("#light").html(content);
            }  
    });

    event.preventDefault();
});

});
</script>
<body>
        <form id="SubmitForm" method="post">
            <div id="SubmitDiv" style="background-color:black;">
            <p>This is the main content. To display a lightbox click <a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='block';document.getElementById('fade').style.display='block'"><button >Submit</button></a></p>
                
            </div>
        </form>
        <div id="DisplayDiv" style="background-color:red;">
            <!-- This is where test2.php should be inserted -->
        </div>
</body>
 
        <div id="light" class="white_content"><a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'">Close</a></div>
       
<style>
.white_content {
	display: none;
	position: absolute;
	top: 25%;
	left: 25%;
	width: 50%;
	height: 50%;
	padding: 16px;
	border: 16px solid orange;
	background-color: white;
	z-index:1002;
	overflow: auto;
}
</style>

