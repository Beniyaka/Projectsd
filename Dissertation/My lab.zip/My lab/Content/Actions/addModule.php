<?php 

define('INCLUDE_CHECK',true);

require '../../connect.php';

$sqlModule = mysqli_prepare($link, "INSERT INTO Modules(mCode,mName,mTerm) VALUES(?,?,?)");
mysqli_stmt_bind_param($sqlModule, 'sss', $_POST['moduleCode'], $_POST['moduleName'], $_POST['moduleTerm']);			
		
$moduleCode = mysqli_real_escape_string($link, $_POST['moduleCode']);
							
$sqlModuleSkills = "INSERT INTO ModuleSkillsRequired (moduleID, skillID) VALUES ";
for($i=0; $i<sizeof($_POST['skills']); $i++){
	if($i>0){ $sqlModuleSkills.=",";}
     $sqlModuleSkills .= "((SELECT mID FROM Modules WHERE mCode = '".$moduleCode."') ,".mysqli_real_escape_string($link, $_POST['skills'][$i]).")";
}

$sqlModuleLevels = "INSERT INTO ModuleLevels (moduleID, mLevel) VALUES ";
for($i=0; $i<sizeof($_POST['moduleLevels']); $i++){
	if($i>0){ $sqlModuleLevels.=",";}
     $sqlModuleLevels .= "((SELECT mID FROM Modules WHERE mCode = '".$moduleCode."') ,'".mysqli_real_escape_string($link, $_POST['moduleLevels'][$i])."')";
}	

if(mysqli_stmt_execute($sqlModule)){
	mysqli_stmt_close($sqlModule);
	if(mysqli_query($link, $sqlModuleSkills)){
			mysqli_query($link, $sqlModuleLevels) or die("Error: "+mysqli_error($link));
	}
}

?>
