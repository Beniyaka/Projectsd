<?php
define('INCLUDE_CHECK',true);

require '../../connect.php';
require '../../functions.php';
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>MyLab Add Module</title>

<?php include("./baseInclude.php"); ?>

<?php 
	$skillTypes = '<script type="text/javascript" >var skillTypeList = "';
	$sqlTerms = mysqli_query($link, "SELECT typeName, typeID, COUNT(*) AS typeCount FROM SkillType");
	$skillTypes .= '<select name=\"newSkillType[]\">';
	while($row2=mysqli_fetch_assoc($sqlTerms)){
		$skillTypes.= '<option value=\"'.$row2['typeID'].'\" >'.$row2['typeName'].'</option>';
	}
	$skillTypes.= '</select>";';
	
	$sqlTermsNum = mysqli_query($link, "SELECT COUNT(mLevel) AS typeCount FROM ModuleLevelNames LIMIT 1");
	$row2=mysqli_fetch_assoc($sqlTermsNum);
	$skillTypes.='var maxCourseLevels = '.$row2['typeCount'].';</script>';
	echo $skillTypes;
?>


<style type="text/css">
	html { font-size: 1em; }
	label { font-size: 1em; font-weight: bold; }
	form { width: 420px; }
	#submit { font-size:1em; padding: 5px 20px; }
	
	.error { color: red; }
	.module { border: 3px inset #F6F6F6; background: #F6F6F6; border-radius: 4px; padding: 10px; }
	
	#moduleInfoMain { width: 190px; }
	#addCourseLevelMain { float: right; width: 170px; }
	#skillsMain { }
	#newSkillsMain { border: 2px solid #C7C7C7; background: #C7C7C7; border-radius: 4px; width: 310px; }
</style>


<script type="text/javascript" >

$(document).ready(function(){
	var courseLevelList = $("#addCourseLevel").html();
	var newSkillsCount = 0;
	var courseCount = 0;
	
	$("#addSkill").click(function(){
		$("#newSkills").prepend("<div id=\"newSkill"+newSkillsCount+"\"><input type=\"text\" class=\"newSkill\" name=\"newSkills[]\" />"+skillTypeList+"</div>");
		newSkillsCount++;

	});
	
	$("#rmvSkill").click(function(){
		if((newSkillsCount-1)>=0){
			$("#newSkill"+(newSkillsCount-1)).remove();
			if((newSkillsCount)!=0) newSkillsCount--;
		}
	});
	
	$("#addLevel").click(function(){
		if(courseCount < maxCourseLevels-1){
			$("#addCourseLevel").prepend(courseLevelList);
			courseCount++;
		}
	});
	
	$("#rmvLevel").click(function(){
		if(courseCount>0){
			$("#addCourseLevel select:lt(1)").remove();
			courseCount--;
		}
	});
	
	
	
	$('#submitModule').click(function() {
		var pass=0;
		
		$(".error").html("");		
		
		if( ($("#moduleName").val()=="" || $("#moduleName").val()==null) || ($("#moduleCode").val()=="" || $("#moduleCode").val()==null)){ 
			$("#moduleNameError").html("Please fill out both name boxes.");
			pass=1;
		}
		
		// Check that at least one skill is chosen
		var is_checked = 0;
		$(".skills").each(function(index){ 
			if(this.checked){	is_checked ++;	}
		});
		if(is_checked==0){
			pass=1;
			$("#skillError").html("Please select at least one skill from below.");
		}
		
		
		if(pass==0){
			$.post('./addModule.php', $("#moduleForm").serialize(), function(data) {
				alert(data+"The module has been added.");
			});
		}
	});
	
	
	
});

</script>



</head>

<body>

<form method="post" id="moduleForm" name="moduleForm">

	<div id="addCourseLevelMain" class="module">
	<label for="addCourseLevel">Course Level(s)</label><br />
		<button type="button" name="addModuleYear" id="addLevel" style="width: 70px;" >add</button>
		<button type="button" name="rmvModuleYear" id="rmvLevel" style="width: 70px;">remove</button><br />
		<div id="addCourseLevel">
			<?php
				$sqlYears = mysqli_query($link, "SELECT mLevel FROM ModuleLevelNames") or die(mysqli_error($link));
				echo '<select name="moduleLevels[]">';
				while($row=mysqli_fetch_assoc($sqlYears)){
					echo '<option value="'.$row['mLevel'].'" >'.$row['mLevel'].'</option>';
				}
				echo '</select>';
			?>
		</div>
	</div>

	<div id="moduleInfoMain" class="module">
		<label for="moduleName">Module Name</label><br />
			<input type="text" name="moduleName" id="moduleName" /><br />
		<label for="moduleCode">Module Code</label><br />
			<input type="text" name="moduleCode" id="moduleCode" /><br />
			
		<!-- ADD TIMETABLE -->
		<?php
			$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y WHERE T.termYearID=Y.tYearID ORDER BY T.termID DESC");
			echo '<select name="moduleTerm">';
			while($row=mysqli_fetch_assoc($sqlTerms)){
				echo '<option value="'.$row['termID'].'" >'.$row['tYearStart']."-".$row['tYearEnd'].": Semester ".$row['term'].'</option>';
			}
			echo '</select>';
		?>
	<span id="moduleNameError" class="error"></span><br />
	</div>
	
	<br />
	<div id="skillsMain" class="module"><span id="skillError" class="error"></span>
		<?php
			getSkillsTable($link);
		?>
		
		<br />
		<div id="newSkillsMain">
			<button type="button" name="addSkill" id="addSkill">Add New Skill</button><button type="button" name="rmvSkill" id="rmvSkill">Remove new Skill</button><br />
			<div id="newSkills"></div>
		</div>
		<br />
	</div>
	<br />
	
	
	<!-- ADD LECTURERS -->
	
	<button id="submitModule" name="submitModule" value="submitModule" type="button">Save Module</button>
</form>

</body>


</html>