<?php

session_name('mylabLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();

define('INCLUDE_CHECK',true);

require '../../connect.php';

$sqlJoinModule = "INSERT INTO ModuleLecturers(lecturerID,mID) VALUES((SELECT lecturerID FROM Lecturers WHERE usr='".$_SESSION['usr']."'),".$_POST['moduleID'].")";

mysqli_query($link, $sqlJoinModule) or die("Error: ".mysqli_error($link));

?>