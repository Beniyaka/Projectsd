<?php
define('INCLUDE_CHECK',true);

require '../../connect.php';
require '../../functions.php';
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>MyLab Add Module</title>

<?php include("./baseInclude.php"); ?>

<?php 
	$skillTypes = '<script type="text/javascript" >var skillTypeList = "';
	$sqlTerms = mysqli_query($link, "SELECT typeName, typeID, COUNT(*) AS typeCount FROM SkillType");
	$skillTypes .= '<select name=\"newSkillType[]\">';
	while($row2=mysqli_fetch_assoc($sqlTerms)){
		$skillTypes.= '<option value=\"'.$row2['typeID'].'\" >'.$row2['typeName'].'</option>';
	}
	$skillTypes.= '</select>";';
	
	$sqlTermsNum = mysqli_query($link, "SELECT COUNT(mLevel) AS typeCount FROM ModuleLevelNames LIMIT 1");
	$row2=mysqli_fetch_assoc($sqlTermsNum);
	$skillTypes.='var maxCourseLevels = '.$row2['typeCount'].';</script>';
	echo $skillTypes;
?>


<style type="text/css">
	html { font-size: 1em; }
	label { font-size: 1em; font-weight: bold; }
	form { width: 420px; }
	#submit { font-size:1em; padding: 5px 20px; }
	
	.error { color: red; }
	.module { border: 3px inset #F6F6F6; background: #F6F6F6; border-radius: 4px; padding: 10px; }
	
	#joinLecturerToModule { width: 450px; }
	#joinModuleData { width: 300px; }

</style>

<?php
	$sqlFirst = '<script type="text/javascript" >$(document).ready(function(){';
	//$sqlFirst .= '$(function() {	';
	$sqlTagNames = 'var availableTags = [';
	$sqlTagIDs = 'var courseIDs = [';
	
	$sqlTerms = mysqli_query($link, "SELECT mID, mCode, mName FROM Modules");
	
	$xxx = 0;
	while($row2=mysqli_fetch_assoc($sqlTerms)){
		if($xxx>0){ $sqlTagNames.=','; $sqlTagIDs.=','; }
		$sqlTagNames .= '"'.$row2['mCode'].' - '.$row2['mName'].'"';
		$sqlTagIDs .= '"'.$row2['mID'].'"';
		$xxx .= 1;
	}
			
	$sqlTagNames .= '];';
	$sqlTagIDs .= '];';
	$sqlEnd .=' $( "#joinModuleData" ).autocomplete({ source: availableTags }); ';
	
	echo $sqlFirst.$sqlTagNames.$sqlTagIDs.$sqlEnd;
?>

// <script type="text/javascript" >

// $(document).ready(function(){
	
	$('#joinModule').click(function() {
		var pass=0;
		
		$(".error").html("");				
		
		if( $("#joinModuleData").val()=="" || $("#joinModuleData").val()==null ){ 
			$("#joinModuleError").html("Please select a module to join by typing its name.");
			pass=1;
		}else if( jQuery.inArray($("#joinModuleData").val(),availableTags)==-1){ 
			$("#joinModuleError").html("The module you have requested is not available, please check your information and try again or add your module using the \"add module\" function.<br />");
			pass=1;
		}
		
		
		if(pass==0){
			$.post('./joinModule.php', {"moduleID" : courseIDs[availableTags.indexOf($("#joinModuleData").val())] }, function(data) {
				alert(data);
			});
		}
	});
	
	
	
});

</script>



</head>

<body>

	<div id="joinLecturerToModule" class="module">
		<span id="joinModuleError" class="error"></span>
		<input type="" id="joinModuleData" name="moduleID" class="ui-widget"/>
		<button type="button" id="joinModule" class="ui-widget"> Join Module</button><br />
	</div>

</body>


</html>
