<?php 
	if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<title>Back Up Database - MyLab Helper Allocation</title>

<style type="text/css">
	#backup button { height: 120px; font-size: 1.2em; margin: 10px; text-align: center; display: block; width: 98%; }
</style>

<script type="text/javascript" >
		
		$( "button", "#backup" ).button();
		$( "#backitup" ).click(function(event) { 
			event.preventDefault();
			$.post("./Content/adminBackup.php",{ 'backup':'true' }, function(data){
				if(data!="" && data!=null){ $("#backupResponse").removeClass("err").addClass("success").html(data+'<meta HTTP-EQUIV="REFRESH" content="2; url=./?pg=settings"/>');
				}else 
				$("#backupResponse").removeClass("success").addClass("err").html("There was an error backing up the database. Wait a bit and try again, if the problem persists please contact the administrator.");
			});
			return false;
		});

</script>

<div id="backup">
	<span id="backupResponse"></span><br>
	<button id="backitup">Click Me to backup database</button>
</div>
