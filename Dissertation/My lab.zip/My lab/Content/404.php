<?php
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<html>
<head>

</head>
<body>

<br /><h1>The page you asked for does not exist</h1>
<br /> You will be redirected to your homepage <br />
<p>This is a simple example site demonstrating the website look it might turn into. Simplz yez?</p>
<br /><br /><br /><br />

<meta HTTP-EQUIV="REFRESH" content="3; url=./">
</body>

</html>