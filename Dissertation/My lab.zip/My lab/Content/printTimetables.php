<?php
	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	
	define('INCLUDE_CHECK',true);
	
	require '../connect.php';
?>
<html>
<head>
	<title>User Timetables & Information</title>

	<link rel="stylesheet" type="text/css" href="../Ressources/CSS/jquery-ui-1.8.17.custom.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="../Ressources/CSS/jquery-ui-1.8.17.custom.css" media="print" />
	<script type='text/javascript' src='../Ressources/JS/jquery-1.7.1.min.js'></script>
	<script type='text/javascript' src='../Ressources/JS/jquery-ui-1.8.17.custom.min.js'></script>
	
	
	<style type="text/css">
	@media print, screen {
		html, body { background: white; }
		tr { position: relative; left:0px;}
		td { padding: 5px; padding-left: 10px; padding-right: 10px;  position: relative; left:0px; }
		td img { width: 100%; height: 100%; position: absolute; top: 0px; left: 0px; z-index: -9999; }
		#fullTT { float: left; width: 500px; overflow: auto;}
		#news { float: right; width: 250px; }
		#news1 { border: 1px solid #ddd; background-color: #eee; padding: 10px; }
		#selectYear { float: right; display: block; margin-right: 30px;}
		
		.userMod { border-bottom: 4px solid black; font-size: 2em; font-weight: bold;}
		#report h1 { text-align: center; vertical-align: middle; position: relative; top: 300px; margin-right: auto; margin-left: auto; }
		
		.pageBreak { page-break-after: always; }
		#big { font-size: 3.5em; }
		
		.email { font-size: 0.6em; float: right; vertical-align: bottom; font-style: italic; position: relative; top: 12px; }
		.usr { font-size: 0.8em; float: right; font-weight: normal; font-style: italic; }
	}
	
	@media print {
		td img { display: none; }
	}
		
	</style>
	
</head>

<body onload="window.print()">

<div id="report">

	<?php
	
	
	if(isset($_GET['years'])){
		$sqlUsers=mysqli_query($link,"SELECT U.usr, U.accType, U.email, IF(U.accType='Lecturer',L.lFirstName,H.hFirstName) AS firstName, IF(U.accType='Lecturer',L.lSurname,H.hSurname) AS lastName 
												FROM Users U, Lecturers L, Helpers H, ModuleHelpers MH, ModuleLecturers ML, Modules M 
												WHERE U.approvedUser='true' AND IF(U.accType='Helper',(U.usr=H.usr AND MH.helperID=H.hID AND MH.mID=M.mID AND MH.aproved='true'), (U.usr=L.usr AND ML.lecturerID=L.lecturerID AND ML.mID=M.mID)) AND M.mTerm=".$_GET['years']." 
												GROUP BY U.usr 
												ORDER BY U.accType ASC;") or die(mysqli_error($link));
		$accType='';

		if(mysqli_affected_rows($link)>0){		
		
			while($rowd=mysqli_fetch_assoc($sqlUsers)){
				if($accType!=$rowd['accType']) {
					if($accType!='') echo '<div class="pageBreak"></div>';
					echo '<h1 id="big">MyLab</h1><h1 class="sub">'.strtoupper($rowd['accType']).' TIMETABLES FOR<br></h1>';
					$accType=$rowd['accType'];
					if($accType!='') echo '<div class="pageBreak"></div>';
				}
				echo '<div class="pageBreak"></div>';
				$_POST['usr']=$rowd['usr'];
				$_POST['firstName']=$rowd['firstName'];
				$_POST['lastName']=$rowd['lastName'];
				$_POST['accType']=$rowd['accType'];
				$_POST['email']=$rowd['email'];
				include('./getTimetable.php');
			}
			
			echo '<script type="text/javascript" >$(".sub").append("'.$termName.'");</script>';
		}else echo '<h1>No data as of yet, please wait for people to add and join modules</h1>';
	}else echo '<h1>No data as of yet, please wait for people to add and join modules</h1>';
	?>
</div>


<script type="text/javascript" >

$(".even img").attr("src","../Ressources/IMG/Print/eeeeee.png");
$(".odd img").attr("src","../Ressources/IMG/Print/cccccc.png");

</script>

</body>

</html>