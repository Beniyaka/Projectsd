<?php
require('../Ressources/PDF/fpdf.php');

class PDF extends FPDF
{
// Page header
function Header()
{
	global $semester;
	global $accType;
	global $title;

    // Arial bold 15
    $this->SetFont('Arial','I',11);
    // Move to the right
    $this->Cell(19);
    // Title
    $this->Cell(1,0,$accType.' Timetables',0,0,'C');
    
    // Arial bold 15
    $this->SetFont('Arial','I',11);
    // Move to the right
    $this->Cell(140);
    // Title
    $this->Cell(0,0,$semester,0,0,'C');
    // Line break
    $this->Ln(20);

}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    $this->SetX(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',9);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    
}

function ChapterTitle($num, $label)
{
	global $subtitle;
    // Arial 12
    $this->SetFont('Arial','B',18);
    // Background color
    $this->SetFillColor(255,255,255);
    // Title
    $this->Cell(0,6,$subtitle,0,1,'L',true);
    // Line break
    $this->Ln(4);
}

function ChapterBody($file)
{
    // Read text file
    $txt = ($file);
    // Times 12
    $this->SetFont('Times','',12);
    // Output justified text
    $this->MultiCell(0,5,$txt);
    // Line break
    $this->Ln();
    // Mention in italics
    $this->SetFont('','I');
    $this->Cell(0,5,'(end of excerpt)');
    $this->Ln();
}

function PrintChapter($num, $title, $file)
{
    $this->AddPage();
    $this->ChapterTitle($num,$title);
    $this->ChapterBody($file);
}

// Load data
function LoadData($file)
{
    // Read file lines
    $lines = file($file);
    $data = array();
    foreach($lines as $line)
        $data[] = explode(';',trim($line));
    return $data;
}

// Colored table
function FancyTable($header, $data)
{
    // Colors, line width and bold font
    $this->SetFillColor(255,255,255);
    $this->SetTextColor(0);
    $this->SetDrawColor(255,255,255);
    $this->SetLineWidth(.3);
    $this->SetFont('','B',14);
    // Header
    $w = array(40, 35, 40, 45);
    for($i=0;$i<count($header);$i++)
        $this->Cell($w[$i],7,$header[$i],1,0,'C',true);
    $this->Ln();
    // Color and font restoration
    $this->SetFillColor(204,204,204);
    $this->SetTextColor(0);
    $this->SetFont('');
    // Data
    $fill = true;
    $one = 238;
    $two = 238;
    $three=204;
    foreach($data as $row)
    {
        $this->Cell($w[0],6,$row[0],'LR',0,'L',$fill);
        $this->SetFillColor($one,$one,$one);
        $this->Cell($w[1],6,$row[1],'LR',0,'L',$fill);
        $this->SetFillColor($one,$one,$one);
        $this->Cell($w[2],6,number_format($row[2]),'LR',0,'R',$fill);
        $this->SetFillColor($one,$one,$one);
        $this->Cell($w[3],6,number_format($row[3]),'LR',0,'R',$fill);
        $this->SetFillColor($one,$one,$one);
        $this->Ln();
        $one = ($one==$two)?$three:$two;
    }
    // Closing line
    $this->Cell(array_sum($w),0,'','T');
}


}




// Instanciation of inherited class
$pdf = new PDF();
$accType = 'Lecturer';
$semester = '2011-2012 T1';
$subtitle = 'Boswell, Andrew';

// Column headings
$header = array('Country', 'Capital', 'Area (sq km)', 'Pop. (thousands)');
// Data loading
$data = $pdf->LoadData('countries.txt');


$pdf->SetTitle($title);
$pdf->SetAuthor('Jules Verne');

$pdf->PrintChapter(1,'A RUNAWAY REEF','20k_c1.txt');
$pdf->FancyTable($header,$data);
$pdf->PrintChapter(2,'THE PROS AND CONS','Lot of weird stuff');

$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);

// $pdf->Image('./graph.php',60,30,90,0,'PNG');
$pdf->Image("http://www2.macs.hw.ac.uk/~acb8/mylab/Content/graph.php",60,30,90,0,'PNG');
$pdf->Output();


?>