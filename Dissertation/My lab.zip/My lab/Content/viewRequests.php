<?php
	if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<style type="text/css">
	#mainBit { min-height: 400px; position: relative; }
	
	#selectable .ui-selecting { background: #FECA40; }
	#selectable .ui-selected { background: #F39814; color: white; }
	#selectable { list-style-type: none; margin: 0; padding: 0; width: 100%; position: relative; }
	#selectable li { margin: 3px; padding: 0.4em; display: block; text-align: center; }
	
	.response { position: relative; }
	.nameItalic { font-style: italic; }
	.deleteResp { position: absolute;right:10px; bottom: 15px;}
	
</style>

<script type="text/javascript" >//$(function() {$("#circle").hide();});
	var currID = -1;
	$(".request").live("click",function(){
		currID=$(this).attr("id");
		$("#dialog-confirm").html("confirm request for "+$(this).html());
		$( "#dialog-confirm" ).dialog( "open" );
	});
	$(function() {
		$( "#dialog:ui-dialog" ).dialog( "destroy" );
	
		$( "#dialog-confirm" ).dialog({
			autoOpen: false,
			resizable: false,
			height:"auto",
			modal: true,
			buttons: {
				"Accept Request": function() {
					$( this ).dialog( "close" );
					$.post('./Content/acknowledge.php', { 'rID': currID,'answer':'true' }, function(data){
						if(data==""){
							window.location.href = "?pg=viewRequests";
						}else alert(data);
					});
				},
				Reject: function() {
					$( this ).dialog( "close" );
					$.post('./Content/acknowledge.php', { 'rID': currID,'answer':'false' }, function(data){
						if(data==""){
							window.location.href = "?pg=viewRequests";
						}else alert(data);
					});
				}
			}
		});
	});
</script>

<div id="mainBit">
<div id="selectable">

<?php
	if($me=='Helper'){
		$sqlCheckRequests = mysqli_query($link, "SELECT R.rID, M.mID, M.mName, R.usrFrom, R.seen, R.acknowledged FROM Requests R, Modules M, Timetable T WHERE R.ttID=T.ttID AND T.mID=M.mID AND usrTo='".$_SESSION['mysesi']."' AND acknowledged IS NULL") or die(mysqli_error($link));
		$sqlCheckResponse = mysqli_query($link, "SELECT R.rID, M.mID, M.mName, R.usrTo, R.seen, R.acknowledged FROM Requests R, Modules M, Timetable T WHERE R.ttID=T.ttID AND T.mID=M.mID AND usrFrom='".$_SESSION['mysesi']."' AND acknowledged IS NOT NULL AND seen='false' AND usrTo IS NULL") or die(mysqli_error($link));



		$sqlCheckRecommendations =  mysqli_query($link, "SELECT M.mID, M.mName, M.mCode
										FROM Helpers H, Modules M, Terms T 
										WHERE T.termID=M.mTerm AND T.termID=(SELECT MAX(TT.termID) FROM Terms TT) AND
											H.usr NOT IN (SELECT R.usrFrom FROM Requests R, Timetable TT WHERE R.ttID=TT.ttID AND TT.mID=M.mID AND H.usr=R.usrFrom) 
												AND H.usr NOT IN (SELECT R.usrTo FROM Requests R, Timetable TT WHERE R.ttID=TT.ttID AND TT.mID=M.mID AND H.usr=R.usrTo) 
												AND H.usr NOT IN (SELECT HH.usr FROM ModuleHelpers HM, Helpers HH, Timetable TT WHERE HM.ttID=TT.ttID AND TT.mID=M.mID AND H.hID=HM.helperID AND HH.hID=HM.helperID) 
												AND H.usr='".$_SESSION['mysesi']."' 
												AND (((SELECT COUNT(HS.skillID) FROM HelperSkills HS, ModuleSkillsRequired S
													WHERE HS.helperID=H.hID AND HS.skillID = S.skillID AND S.moduleID=M.mID )
													/
													(SELECT COUNT(*) FROM ModuleSkillsRequired S WHERE S.moduleID=M.mID )
													
													)*100)>=50
										ORDER BY (SELECT COUNT(*) FROM HelperSkills HS, ModuleSkillsRequired S 
												WHERE HS.helperID=H.hID AND HS.skillID = S.skillID AND S.moduleID=M.mID) DESC") or die(mysqli_error($link));
		
		
		
		
		
		// ModuleHelpers MH, Helpers H WHERE R.mID=M.mID AND MH.helperID=H.hID AND MH.mID=R.mID AND H.usr='".$_SESSION['mysesi']."' 
		// AND R.acknowledged IS NOT NULL AND seen='false' AND R.usrFrom IS NULL");
	
	}

elseif($me=='Lecturer'){
		$sqlCheckRequests = mysqli_query($link, "SELECT TT.ttDay,TT.ttStartTime,TT.ttEndTime, R.rID, M.mID, M.mName, R.usrFrom, H.hFirstName, H.hSurname, R.seen, R.acknowledged FROM Requests R, Modules M, ModuleLecturers ML, Lecturers L, Helpers H, Timetable TT WHERE H.usr=R.usrFrom AND R.ttID=TT.ttID AND TT.mID=M.mID AND ML.lecturerID=L.lecturerID AND ML.mID=TT.mID AND TT.ttID=R.ttID AND L.usr='".$_SESSION['mysesi']."' AND R.acknowledged IS NULL AND R.usrTo IS NULL") or die(mysqli_error($link));
		$sqlCheckResponse = mysqli_query($link, "SELECT R.rID, M.mID, M.mName, R.usrTo, H.hFirstName, H.hSurname, R.seen, R.acknowledged FROM Requests R, Modules M, ModuleLecturers ML, Lecturers L, Helpers H, Timetable TT WHERE H.usr=R.usrTo AND R.ttID=TT.ttID AND TT.mID=M.mID AND ML.lecturerID=L.lecturerID AND ML.mID=TT.mID AND TT.ttID=R.ttID AND L.usr='".$_SESSION['mysesi']."' AND R.acknowledged IS NOT NULL AND seen='false' AND R.usrFrom IS NULL") or die(mysqli_error($link));
	}

elseif($me=='Administrator'){
		$sqlCheckNewUsers = mysqli_query($link, "SELECT U.usr, U.email, U.accType, (IF(accType='Helper', H.hFirstName,L.lFirstname)) AS firstName, (IF(accType='Helper', H.hSurname,L.lSurname)) AS lastName  FROM Users U, Lecturers L, Helpers H WHERE U.approvedUser='false' AND (U.usr=H.usr OR U.usr=L.usr) GROUP BY U.usr") or die(mysqli_error($link));
	}
	
	if($me=="Lecturer" || $me=="Helper" ){
	//$sqlUpdateRequests = "UPDATE Requests SET acknowledged='true' WHERE ";
	$xx=0;
	echo '<div id="requests"><h1>Requests</h2><br><ol>';
	while($row=mysqli_fetch_assoc($sqlCheckRequests)){
		echo '<li id="'.$row['rID'].'" class="request ui-widget-content">For '.$row['mName']." ".$row['ttDay']." ".$row['ttStartTime']."-".$row['ttEndTime'].(($row['usrFrom']=='')?'':' -- From <span class="nameItalic">'.$row['hFirstName'].' '.$row['hSurname']).'</span></li>';
		$xx++;
	}
	echo '</ol>';
	
	if($xx>0){
	
	//mysqli_query($link, $sqlUpdateRequests) or die(mysqli_error($link));

	echo '';
	}else{
	 echo '<h2>You do not have any pending requests</h2><br>';
	}
	$xx=0;
	echo '</div><div id="responses"><h1>Responses</h2><br><ol>';
	while($row=mysqli_fetch_assoc($sqlCheckResponse)){
		echo '<li id="'.$row['rID'].'" class="response ui-widget-content"> '.$row['mName'].'<br/>'.(($row['usrTo']=='')?'A Lecturer':'<span class="nameItalic">'.$row['hFirstName'].' '.$row['hSurname']).'</span> has '.(($row['acknowledged']=='false')?'<span class="err">declined</span>':'<span class="success">accepted</span>')." your offer<button class=\"deleteResp\" type=\"button\">X</span></li>";
		$xx++;
	}
	if($xx>0){
	
	//mysqli_query($link, $sqlUpdateRequests) or die(mysqli_error($link));

	echo '<script type="text/javascript" >//$(function() {$("#circle").hide();});
	var currID1 = -1;
	$(".deleteResp").click(function(){
		currID1=$(this).parent().attr("id");
		$.post(\'./Content/acknowledge.php\', { \'rID\': currID1 }, function(data){
			if(data==""){
				window.location.href = "./?pg=viewRequests";
			}else alert(data);
		});
	});
	</script>';
	}else{
	 echo '<h2>You do not have any pending responses</h2><br>';
	}
	
	
	echo '</ol></div>';
	}
	
	
	if($me=="Helper"){
		$xx=0;
		echo '<div id="recommendations"><h1>Recommendations</h2><br><ol>';
		while($row=mysqli_fetch_assoc($sqlCheckRecommendations)){
			echo '<li id="'.$row['mID'].'" class="recommendations ui-widget-content"> '.$row['mName'].' -- '.$row['mCode'].'</li>';
			$xx++;
		}
		if($xx>0){
		
		//mysqli_query($link, $sqlUpdateRequests) or die(mysqli_error($link));
	
		echo '<script type="text/javascript" >//$(function() {$("#circle").hide();});
			var currID2 = -1;;
			$(".recommendations").click(function(){
				currID2=$(this).attr("id");
				email = $(this).find("span").html();
				$("#dialog-confirm1").html("Send a request to join "+$(this).html()+ "?");
				$( "#dialog-confirm1" ).dialog( "open" );
			});
			$(function() {
				$( "#dialog:ui-dialog" ).dialog( "destroy" );
			
				$( "#dialog-confirm1" ).dialog({
					autoOpen: false,
					resizable: false,
					height:"auto",
					modal: true,
					buttons: {
						"Yes": function() {
							$( this ).dialog( "close" );
							$.post(\'./Content/joinModule.php\', { \'moduleID\' : currID2 }, function(data){
								window.location.href = "./?pg=viewRequests";
							});
						},
						"No": function() {
							$( this ).dialog( "close" );
							$.post(\'./Content/joinModule.php\', { \'moduleID\' : currID2, \'usr\': currID2, \'no\':\'no\'}, function(data){
								window.location.href = "./?pg=viewRequests";
							});
						}
					}
				});
			});</script>';
		}else{
		 echo '<h2>You do not have any recommendations.</h2><br>';
		}
	
	
	echo '</ol></div>';
	
	}elseif($me=="Administrator"){
		$xx=0;
		echo '<div id="newUsers"><h1>Users to be Approved</h2><br><ol>';
		while($row=mysqli_fetch_assoc($sqlCheckNewUsers)){
			echo '<li id="'.$row['usr'].'" class="newUsers ui-widget-content"> '.$row['accType'].': '.$row['firstName'].' '.$row['lastName'].' -- <span style="font-style:italic">'.$row['email'].'</span></li>';
			$xx++;
		}
		if($xx>0){
		
		//mysqli_query($link, $sqlUpdateRequests) or die(mysqli_error($link));
	
		echo '<script type="text/javascript" >
	var currID3 = -1;
	var email="";
	$(".newUsers").click(function(){
		currID3=$(this).attr("id");
		email = $(this).find("span").html();
		$("#dialog-confirm").html("confirm User<br> "+$(this).html());
		$( "#dialog-confirm" ).dialog( "open" );
	});
	$(function() {
		$( "#dialog:ui-dialog" ).dialog( "destroy" );
	
		$( "#dialog-confirm" ).dialog({
			autoOpen: false,
			resizable: false,
			height:"auto",
			modal: true,
			buttons: {
				"Approve": function() {
					$( this ).dialog( "close" );
					$.post(\'./Content/approveUser.php\', { \'usr\' : currID3, "answer" : "true" }, function(data){
						if(data==""){
							window.location.href = "./?pg=viewRequests";
						}else alert(data);
					});
				},
				Reject: function() {
					$( this ).dialog( "close" );
					$.post(\'./Content/approveUser.php\', { \'usr\': currID3,\'answer\':\'false\',\'email\':email }, function(data){
						if(data==""){
							window.location.href = "./?pg=viewRequests";
						}else alert(data);
					});
				}
			}
		});
	});</script>';
		}else{
		 echo '<h2>You do not have any pending user requests.</h2><br>';
		}
	
	
	echo '</ol></div>';
	}else echo '</div>';
	
	
?>
</div>
<div id="dialog-confirm" style="display:none;" class="nav"></div>
<div id="dialog-confirm1" style="display:none;" class="nav"></div>
</div>

