<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />

<style type="text/css">

	#timetableResult div input { font-size: 1em;  }
	.weekday { font-weight: bold; width: 118px; border: 0; background: transparent; padding: 2px; font-size: 1em; }
	.timetableTime1, .timetableTime2 { width: 64px; padding: 2x; }
	.timetableWeeks { width: 222px; padding: 2px; }
	.troom { width: 57px; padding: 2px; float: right; margin-right: 14px; }
	.thelperNum { width: 25px; padding: 1px; }
	
	#maxHelpers { font-size: 0.8em; }
	
</style>


</head>
<body>

<button type="button" id="addClass" style="display:inline;">Add</button>
<button type="button" id="rmvClass" style="display:inline;">Remove</button>
<br>
<div id="timetableResult" >
<br />
	<div id="timetableContent">
		<div class="classes">
			<select name="weekday[]" class="weekday">
				<option value="Monday">Monday</option>
				<option value="Tuesday">Tuesday</option>
				<option value="Wednesday">Wednesday</option>
				<option value="Thursday">Thursday</option>
				<option value="Friday">Friday</option>
			</select> 
			<select name="timetableTime1[]" class="timetableTime1">
				<option value="8:15">08:15</option>
				<option value="9:15">09:15</option>
				<option value="10:15">10:15</option>
				<option value="11:15">11:15</option>
				<option value="12:15">12:15</option>
				<option value="13:15">13:15</option>
				<option value="14:15">14:15</option>
				<option value="15:15">15:15</option>
				<option value="16:15">16:15</option>
				<option value="17:15">17:15</option>
			</select> - 
			<select name="timetableTime2[]" class="timetableTime2">
				<option value="9:15">09:15</option>
				<option value="10:15">10:15</option>
				<option value="11:15">11:15</option>
				<option value="12:15">12:15</option>
				<option value="13:15">13:15</option>
				<option value="14:15">14:15</option>
				<option value="15:15">15:15</option>
				<option value="16:15">16:15</option>
				<option value="17:15">17:15</option>
				<option value="17:15">18:15</option>
			</select><br />
			<label>Number of Helper not more than 2</label>
			<input type="text" name="helperNum[]" class="thelperNum" maxlength="2" />
			<label>Timetable Weeks(Separated by ",")</label>
			<input class="timetableWeeks" name="timetableWeeks[]"/>
			<br /><label>Room Number</label>
			<br /><input name="room[]" />
			<div style="clear: both;">
				<span class="error roomError"></span>
				<span class="error weeksError"></span>
				<span class="error helpersNumError"></span>
			</div><br />
		</div>
	</div>
</div>


</body>
</html>