<?php

session_name('mylabLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();

define('INCLUDE_CHECK',true);
$me = $_POST['me'];
require '../connect.php';
if($me=="Helper"){
	if(!isset($_POST['no'])){
		$sqlJoinModule = "INSERT INTO ModuleHelpers(helperID,ttID,aproved) VALUES((SELECT hID FROM Helpers WHERE usr='".$_SESSION['mysesi']."'),".$_POST['ttID'].",'false');"; 
		$sqlRequests = "INSERT INTO `Requests`(`usrFrom`, `ttID`, `seen`) VALUES ('".$_SESSION['mysesi']."',".$_POST['ttID'].",'false');";
		mysqli_query($link, $sqlJoinModule) or die("Error: ".mysqli_error($link));
		mysqli_query($link, $sqlRequests) or die("Error: ".mysqli_error($link));
		echo '<span class="success">You have successfully requested to join the module.</span>';
	}else{
		$sqlRequests = "INSERT INTO `Requests`(`usrFrom`, `mID`, `seen`,`acknowledged`) VALUES ('".$_SESSION['mysesi']."',".$_POST['moduleID'].",'true','true');";
		mysqli_query($link, $sqlRequests) or die("Error: ".mysqli_error($link));
	}
}elseif($me=="Lecturer"){
	$sqlJoinModule = "INSERT INTO ModuleLecturers(lecturerID,mID) VALUES((SELECT lecturerID FROM Lecturers WHERE usr='".$_SESSION['mysesi']."'),".$_POST['moduleID'].")";
	mysqli_query($link, $sqlJoinModule) or die("Error: ".mysqli_error($link));
	echo '<span class="success">You have successfully joined the module.</span>';
}


?>