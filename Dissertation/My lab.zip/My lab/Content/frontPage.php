<?php
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<html>
<head>

</head>
<body>

<br /><h1>Please, <a class="open" href="#">login</a> or register!</h1>
<br />
<p>This is a simple example site demonstrating the website look it might turn into. Simplz yez?</p>
<br /><br /><br /><br />

</body>

</html>