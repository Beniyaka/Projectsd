<?php
header('Content-Type: image/png');

require_once ('../Ressources/Jpgraph/src/jpgraph.php');
require_once ('../Ressources/Jpgraph/src/jpgraph_pie.php');
require_once ('../Ressources/Jpgraph/src/jpgraph_pie3d.php');

// Some data
$data = array(40,60,21,33);

// Create the Pie Graph. 
$graph = new PieGraph(600,500);

$theme_class= new VividTheme;
$graph->SetTheme($theme_class);
// Set A title for the plot
$graph->title->Set("A Simple 3D Pie Plot");

// Create
$p1 = new PiePlot3D($data);
$graph->Add($p1);

$p1->ShowBorder();
$p1->SetColor('black');
$p1->ExplodeSlice(1);

$gdImgHandler = $graph->Stroke(_IMG_HANDLER);
 
// Stroke image to a file and browser
 
// Send it back to browser
$graph->img->SetImgFormat('PNG');
$graph->img->Headers();
$graph->img->Stream();

$graph->Stroke();

?>