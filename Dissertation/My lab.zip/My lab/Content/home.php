<?php 
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<title>Home timetable - MyLab Helper Allocation System</title>

<style type="text/css">
	
		td { padding: 5px; padding-left: 10px; padding-right: 10px; }
		#fullTT { float: left; width: 100%; overflow: auto;}
		#news { float: right; width: 250px; }
		#news1 { border: 1px solid #ddd; background-color: #eee; padding: 10px; }
		#selectYear { float: right; display: block; margin-right: 30px;}
		
</style>

<div id="fullTT">
	<div>
	
	<button type="button" class="noPrint" onclick="window.print()" >Print</button>
	<form id="selectYear" method="GET">
	<select name="years" id="years" onchange="this.form.submit()">
		<?php
			if($me=='Lecturer'){
				$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y, Lecturers L, ModuleLecturers ML, Modules M WHERE T.termYearID=Y.tYearID AND L.usr='".$_SESSION['mysesi']."' AND ML.lecturerID=L.lecturerID AND ML.mID=M.mID AND M.mTerm=T.termID GROUP BY T.termID ORDER BY T.termID DESC");
			}elseif($me=='Helper'){
				$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y, Helpers H, ModuleHelpers MH, Modules M, Timetable TT WHERE T.termYearID=Y.tYearID  AND H.usr='".$_SESSION['mysesi']."' AND MH.helperID=H.hID AND MH.ttID=TT.ttID AND TT.mID=M.mID AND M.mTerm=T.termID GROUP BY T.termID ORDER BY T.termID DESC") or die(mysqli_error($link));
			}
			
			while($row=mysqli_fetch_assoc($sqlTerms)){
				if(!isset($first)) $first = $row['termID'];
				echo '<option value="'.$row['termID'].'" '.(($_GET['years']==$row['termID'])?"selected=\"selected\"":"").' >'.$row['tYearStart']."-".$row['tYearEnd'].": Semester ".$row['term'].'</option>';
			}
			if(!isset($first)){ $first=0; }
		?>
	</select>
	</form><br><br>
	
	
	
	
	
	
<?php

	$specify = "";
	$tableS = "";
//if(isset($first)){
	if(isset($_GET['years']) && $_GET['years']!="all"){ 
		$tableS=", Terms TE "; 
		$specify = "AND M.mTerm=TE.termID AND TE.termID=".$_GET['years'];
	}else{
		$tableS=", Terms TE "; 
		$specify = "AND M.mTerm=TE.termID AND TE.termID=".$first;
	}

	if($me=='Lecturer'){
	$sqlCheckRequests = mysqli_query($link, 'SELECT M.mID, M.mName, M.mCode, (SELECT TIME_FORMAT(T.ttStartTime, \'%H:%i\')) AS ttStartTime, 
		(SELECT TIME_FORMAT(T.ttEndTime, \'%H:%i\')) AS ttEndTime, T.ttLocation, T.ttDay, (SELECT GROUP_CONCAT(DISTINCT MW.week ORDER BY MW.week ASC SEPARATOR \',\') FROM ModuleWeeks MW WHERE MW.ttID=T.ttID AND T.mID=M.mID) AS ttweeks 
		FROM Modules M, ModuleLecturers ML, Timetable T, Lecturers L, Weekdays W '.$tableS.'
		WHERE W.dayName=T.ttDay AND T.mID=M.mID AND M.mID=ML.mID AND L.lecturerID=ML.lecturerID AND L.usr=\''.$_SESSION['mysesi'].'\' '.$specify.' 
		ORDER BY W.dayID, T.ttStartTime') or die(mysqli_error($link));
	}elseif($me=='Helper'){
		$sqlCheckRequests = mysqli_query($link, 'SELECT M.mID, M.mName, M.mCode, (SELECT TIME_FORMAT(T.ttStartTime, \'%H:%i\')) AS ttStartTime, 
		(SELECT TIME_FORMAT(T.ttEndTime, \'%H:%i\')) AS ttEndTime, T.ttLocation, T.ttDay, (SELECT GROUP_CONCAT(DISTINCT MW.week ORDER BY MW.week ASC SEPARATOR \',\') FROM ModuleWeeks MW WHERE MW.ttID=T.ttID AND T.mID=M.mID) AS ttweeks 
		FROM Modules M, ModuleHelpers MH, Timetable T, Helpers H, Weekdays W '.$tableS.' 
		WHERE W.dayName=T.ttDay AND T.mID=M.mID AND MH.ttID=T.ttID AND T.mID=M.mID AND H.hID=MH.helperID AND H.usr=\''.$_SESSION['mysesi'].'\' AND MH.aproved=\'true\' '.$specify.' 
		ORDER BY W.dayID, T.ttStartTime') or die(mysqli_error($link));
	}
	
	$xx=0;

	echo '<table>';
	if(mysqli_affected_rows($link)>0){echo '<tr><th>Day</th><th>Module</th><th>Time</th><th>Room</th><th>Weeks</th></tr>';}
	
	$day = '';
	$name= '';
	$names=array();
	
	while($row=mysqli_fetch_assoc($sqlCheckRequests)){
		if($day!=$row['ttDay']){ 
			if($xx>0){ echo ''; }
			$day = $row['ttDay'];
			$colorClass=($colorClass=="even")?"odd":"even";
		}else {$day=""; }
		$name=$row['mName']; 
		
		$currCode='';
		$codeArray = explode(" ", $row['mName']);
		for($z=0; $z<sizeof($codeArray); $z++){ 
			$currCode .= substr($codeArray[$z],0,1); 
		}

		if(!in_array($name, $names)){ 
			$code []= $currCode;
			$names[]=$name;
		}
		
		// Work out weeks and concatenate
		$weeks=explode(",",$row['ttweeks']);
		$last=0; $lastChar="";
		for($w=0;$w<sizeof($weeks);$w++){
			if($w==0) {$row['ttweeks']=$weeks[$w];}
			else{
				$lastChar=$row['ttweeks'][strlen ($row['ttweeks'])-1];
				$row['ttweeks'].=($weeks[$w]-$last!=1)?(($lastChar=='-')?$last:'').','.(($w==sizeof($weeks)-1)?'':$weeks[$w]):(($lastChar=='-')?'':'-');
				$lastChar=substr($row['ttweeks'],sizeof($row['ttweeks']),1);
				if($w==sizeof($weeks)-1){
					$row['ttweeks'].=(($lastChar=='-')?''.$weeks[$w]:'');
				}
			}
			$last=$weeks[$w];
		}
		
		if($xx>0){ $sqlUpdateRequests.=" OR ";}
		echo '<tr span id="'.$row['mCode'].'" class="'.$colorClass.'" ><td>'.$day.'</td><td>'.$currCode.'</td><td>'.$row['ttStartTime']."-".$row['ttEndTime'].'</td><td>'.$row['ttLocation'].'</td><td style="white-space:nowrap;">'.$row['ttweeks'].',.</td></tr>';
		$xx++;
	}
	echo '</table></div>';
	for($xxx=0; $xxx<sizeof($names); $xxx++){
		echo '<br>'.$code[$xxx].' = '.$names[$xxx];
	}
	if($xx==0){ echo "<h1>None.</h1><h3>No timetable info, try <a href='?pg=viewModuleForm'>finding a module</a>.</h3>"; }
?>

	<script type="text/javascript" >
		$('.even').css('background-color', '#eee');
		$('.odd').css('background-color','#ccc');
	
	</script>
</div>
</div>
<div style="clear: both;"> </div>