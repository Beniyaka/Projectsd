<?php

	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	
	define('INCLUDE_CHECK',true);
	$requireStuff = (isset($_POST['conn'])) ? $_POST['conn']:'../connect.php' ;
	require $requireStuff;
	
	$mID = mysqli_real_escape_string($link, $_POST['chosenModule']);
	$ttID = mysqli_real_escape_string($link, $_POST['ttID']);

	$sql = mysqli_query($link, "SELECT H.hID, H.hFirstName, H.hSurname, H.usr 
										FROM Helpers H, Users U 
										WHERE H.usr NOT IN (SELECT R.usrFrom FROM Requests R WHERE ttID=".$ttID." AND H.usr=R.usrFrom) AND H.usr NOT IN (SELECT R.usrTo FROM Requests R WHERE ttID=".$ttID." AND H.usr=R.usrTo)
										GROUP BY H.hID 
										ORDER BY (SELECT COUNT(*) FROM HelperSkills HS, ModuleSkillsRequired S 
											WHERE U.usr=H.usr AND U.activeUser='true' AND U.approvedUser='true' AND HS.helperID=H.hID AND HS.skillID = S.skillID AND S.moduleID=".$mID.") DESC") or die(mysqli_error($link));
	

	if(mysqli_affected_rows($link)>0){
		echo '	<h1>What helpers are you interested in?</h1>
		<br><br><br><ol id="selectable2">';

		while($row=mysqli_fetch_assoc($sql)){
			echo "<li class=\"selectable ui-widget-content\" id=".$row['usr'].">".$row['hFirstName']." ".$row['hSurname']." usr:".$row['usr']."<br>";
					
					//$sqlgetAllModuleSkills = mysqli_fetch_array(mysqli_query($link, "SELECT S.skillName FROM ModuleSkillsRequired MS, Skills S WHERE MS.skillID=S.skillID AND MS.moduleID=".$mID));

			$sqlModuleAndHelperSkills= mysqli_query($link, "SELECT S.skillName FROM ModuleSkillsRequired MS, HelperSkills L, Skills S WHERE S.skillID=L.skillID AND L.helperID=".$row['hID']." AND MS.skillID=S.skillID AND MS.moduleID=".$mID) or die(mysqli_error($link));
			$sqlAllOtherHelperSkills= mysqli_query($link, "SELECT S.skillName FROM ModuleSkillsRequired MS, HelperSkills L, Skills S WHERE S.skillID=L.skillID AND L.helperID=".$row['hID']." AND MS.skillID=S.skillID AND MS.moduleID!=".$mID." GROUP BY S.skillID") or die(mysqli_error($link));
			
			echo '<span style="font-style: italic;">';
			while($row2=mysqli_fetch_assoc($sqlModuleAndHelperSkills)){
				echo '<span style="font-weight: bold;">'.$row2['skillName'].'</span> ';
			}
			while($row2=mysqli_fetch_assoc($sqlAllOtherHelperSkills)){
				echo $row2['skillName'].' ';
			}
			echo '</span></li>';
		}
	}else("<H3> There are no helpers available.");
	echo'</ol>';
	echo'<br><br><div align="center"><button type="button" id="backH">Back</button><button type="button" id="invite">Invite</button></div>';

?>