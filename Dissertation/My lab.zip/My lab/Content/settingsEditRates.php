<?php
	// Starting the session
	session_name('mylabLogin');
	session_start();
	
$me ="Administrator";
if($me=="Administrator"){
	define('INCLUDE_CHECK',true);
	require('../connect.php');
	if(isset($_POST['getRate'])){
		$getRate = mysqli_fetch_assoc(mysqli_query($link, "SELECT helperRate FROM Terms WHERE termID=".mysqli_real_escape_string($link,$_POST['getRate']))) or die(mysqli_error($link));
		echo $getRate['helperRate'];
	}else{
		$years=mysqli_real_escape_string($link,$_POST['years']);	
		$newRate=mysqli_real_escape_string($link,$_POST['newRate']);	

		mysqli_query($link, "UPDATE Terms SET helperRate=".$newRate." WHERE termID=".$years) or die(mysqli_error($link));
		
		if(mysqli_affected_rows($link)==1){
			echo '<span class="success">You have successfully updated the helper rate.</span>
					<meta HTTP-EQUIV="REFRESH" content="3; url=?pg=settings"/>';
		}else{
			echo '<span class="error">Rate change failed, please try again.</span>';
		}
	}
}

?>