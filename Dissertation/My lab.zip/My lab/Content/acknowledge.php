<?php
define('INCLUDE_CHECK',true);
require '../connect.php';

session_name('mylabLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();

$variable = ($_POST['answer'])?"acknowledged":"seen";
$answer = ($_POST['answer'])? $_POST['answer']:"true";

if($me=='Lecturer'){
	$sqlAcknowledge = mysqli_query($link, "UPDATE Requests SET ".$variable."='".$answer."' WHERE rID=".$_POST['rID']) or die(mysqli_error($link));
	if($_POST['answer']=='true'){	
		$sqlAcknowledge = mysqli_query($link, "UPDATE ModuleHelpers MH, Helpers H, Requests R SET MH.aproved='".$_POST['answer']."' WHERE MH.helperID=H.hID AND H.usr=R.usrFrom AND R.rID='".$_POST['rID']."' AND MH.ttID=R.ttID") or die(mysqli_error($link));
	}elseif($_POST['answer']=='false'){	
		$sqlAcknowledge = mysqli_query($link, "DELETE FROM ModuleHelpers MH WHERE MH.hID=(SELECT FROM Helpers H, Requests R WHERE MH.helperID=H.hID AND H.usr=R.usrFrom AND R.rID='".$_POST['rID']."' AND MH.ttID=R.ttID") or die(mysqli_error($link));
	}
}

if($me=='Helper'){
	$sqlAcknowledge = mysqli_query($link, "UPDATE Requests SET ".$variable."='".$answer."' WHERE rID=".$_POST['rID']) or die(mysqli_error($link));
	if($_POST['answer']=='true'){
		$sqlAcknowledge = mysqli_query($link, "INSERT INTO ModuleHelpers (helperID,ttID,aproved) VALUES((SELECT hID FROM Helpers WHERE usr='".$_SESSION['mysesi']."'),(SELECT ttID FROM Requests WHERE rID=".$_POST['rID']."),'true');") or die(mysqli_error($link));
	}
}

/* while($row=mysqli_fetch_assoc($sqlCheckRequests)){
	if($xx>0){ $sqlUpdateRequests.=" OR "; }
	echo '<li id="'.$row['rID'].'" class="request ui-widget-content">For '.$row['mName'].' - From: '.$row['usrFrom']."</li>";
	$sqlUpdateRequests.="rID='".$row['rID']."'";
	$xx++;
} */

?>