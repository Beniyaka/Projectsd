<?php 
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<style type="text/css">
	
	#joinLecturerToModule { width: 450px; }
	#joinModuleData { width: 300px; }

</style>

<?php
	$sqlFirst = '<script type="text/javascript" >$(document).ready(function(){';
	//$sqlFirst .= '$(function() {	';
	$sqlTagNames = 'var availableTags = [';
	$sqlTagIDs = 'var courseIDs = [';
	
	$sqlTerms = mysqli_query($link, "SELECT mID, mCode, mName FROM Modules");
	
	$xxx = 0;
	while($row2=mysqli_fetch_assoc($sqlTerms)){
		if($xxx>0){ $sqlTagNames.=','; $sqlTagIDs.=','; }
		$sqlTagNames .= '"'.$row2['mCode'].' - '.$row2['mName'].'"';
		$sqlTagIDs .= '"'.$row2['mID'].'"';
		$xxx .= 1;
	}
			
	$sqlTagNames .= '];';
	$sqlTagIDs .= '];';
	$sqlEnd .=' $( "#joinModuleData" ).autocomplete({ source: availableTags }); ';
	
	echo $sqlFirst.$sqlTagNames.$sqlTagIDs.$sqlEnd;
?>

// <script type="text/javascript" >

// $(document).ready(function(){
	
	$('#joinModule').click(function() {
		var pass=0;
		
		$(".error").html("");				
		
		if( $("#leaveModuleData").val()=="" || $("#leaveModuleData").val()==null ){ 
			$("#leaveModuleError").html("Please select a module to join by typing its name.");
			pass=1;
		}else if( jQuery.inArray($("#leaveModuleData").val(),availableTags)==-1){ 
			$("#leaveModuleError").html("The module you have requested is not available, please check your information and try again or add your module using the \"add module\" function.<br />");
			pass=1;
		}
		
		
		if(pass==0){
			$.post('./Content/leaveModule.php', {"moduleID" : courseIDs[availableTags.indexOf($("#leaveModuleData").val())] }, function(data) {
				alert(data);
			});
		}
	});
	
	
	
});

</script>


	<div id="leaveLecturerToModule" class="module">
		<label>Leave Module</label><br>
		<span id="leaveModuleError" class="error"></span>
		<input type="" id="leaveModuleData" name="moduleID" class="ui-widget"/>
		<button type="button" id="leaveModule" class="ui-widget"> Leave Module</button><br />
	</div>

