<?php

	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	
	define('INCLUDE_CHECK',true);
	$requireStuff = (isset($_POST['conn'])) ? $_POST['conn']:'../connect.php' ;
	require $requireStuff;
	$eish = mysqli_query($link,"SELECT * FROM users WHERE usr = '".$_POST['me']."'");
$sqlUsers = mysqli_fetch_array($eish);
$me = $sqlUsers['accType'];

	if(!isset($_POST['mID'])){ $_POST['mID']=$_GET['mID']; } 
	$_POST['mID']=mysqli_real_escape_string($link, $_POST['mID']);

	$sqlModule = mysqli_query($link, "SELECT M.mID, M.mCode, M.mName, M.mNotes, T.term, Y.tYearStart, Y.tYearEnd FROM Modules M, Terms T, TermYears Y WHERE M.mterm=T.termID AND T.termYearID=Y.tYearID AND M.mID=".$_POST['mID']." LIMIT 1");
	
	if($row2=mysqli_fetch_assoc($sqlModule)){
		
		echo '<div id="moduleDescriptor" class="moduleDescriptor">'.$row2['tYearStart']."-".$row2['tYearEnd'].": Semester ".$row2['term'].'<br /><span style="display:none;" class="modID" >'.$_POST['mID'].'</span><table><tr>';
		echo '<th id="moduleName" class="moduleName heading" colspan="2">'.$row2['mName'].'</th>';
		echo '<th id="moduleCode" class="moduleCode heading">'.$row2['mCode'].'</th>';
		echo '</tr>';
		echo '<tr><td id="moduleSkills"><span class="subheading">Skills</span><ul>';

		$sqlModuleSkills = mysqli_query($link, "SELECT S.skillName FROM ModuleSkillsRequired M, Skills S WHERE S.skillID=M.skillID AND M.moduleID=".$_POST['mID']) or die(mysqli_error($link));
		if(mysqli_affected_rows($link)<1) echo '<li>None.</li>';
		while($row3=mysqli_fetch_assoc($sqlModuleSkills)){
			echo '<li>'.$row3['skillName'].'</li>';
		}
		echo '</ul></td><td id="moduleLevels"><span class="subheading">Level(s)</span><ul>';
		
		$sqlModuleLevels = mysqli_query($link, "SELECT L.mLevel FROM ModuleLevels M, ModuleLevelNames L WHERE M.moduleID=".$_POST['mID']." AND L.mLevelID=M.mLevel");
		if(mysqli_affected_rows($link)<1) echo '<li>None.</li>';
		while($row3=mysqli_fetch_assoc($sqlModuleLevels)){
			echo '<li>'.$row3['mLevel'].'</li>';
		}
		echo '</ul></td><td><div id="moduleLecturers"><span class="subheading">Lecturers</span><ul>';
		
		$sqlModuleLecturers = mysqli_query($link, "SELECT L.usr, L.lFirstName, L.lSurname, U.email FROM ModuleLecturers M, Lecturers L, Users U WHERE U.usr=L.usr AND M.lecturerID=L.lecturerID AND M.mID=".$_POST['mID']);
		if(mysqli_affected_rows($link)<1) echo '<li>None.</li>';
		while($row3=mysqli_fetch_assoc($sqlModuleLecturers)){
			echo '<li id="'.$row3['usr'].'"><a href="mailto:'.$row3['email'].'">'. $row3['lFirstName'].' '.$row3['lSurname'].'</a></li>';
		}
		echo '</ul></div><br /><div id="moduleHelpers"><span class="subheading">Helpers</span><ul>';

		$sqlModuleHelpers = mysqli_query($link, "SELECT H.usr, H.hFirstName, H.hSurname, U.email FROM ModuleHelpers M, Helpers H, Users U, Timetable T WHERE U.usr=H.usr AND M.helperID=H.hID AND M.ttID=T.ttID AND T.mID=".$_POST['mID']." AND M.aproved='true' GROUP BY U.usr") or die(mysqli_error($link));
		if(mysqli_affected_rows($link)<1) echo '<li>None.</li>';
		while($row3=mysqli_fetch_assoc($sqlModuleHelpers)){
			echo '<li id="'.$row3['usr'].'"><a href="mailto:'.$row3['email'].'">'.$row3['hFirstName'].' '.$row3['hSurname'].'</a></li>';
		}
		echo '</ul></div></td></tr>';
		echo '<tr><td colspan="3">';
		
		$sqlModuleTimeTable = mysqli_query($link, "SELECT ttID, ttDay, ttLocation, (SELECT TIME_FORMAT(ttStartTime, '%H:%i')) AS ttStartTime, (SELECT TIME_FORMAT(ttEndTime, '%H:%i')) AS ttEndTime FROM Timetable WHERE mID=".$_POST['mID']) or die(mysqli_error($link));
		if(mysqli_affected_rows($link)<1) echo '<li>None.</li>';
		while($row3=mysqli_fetch_assoc($sqlModuleTimeTable)){
			$sqlGetTTWeeks = mysqli_query($link, "SELECT MW.week FROM ModuleWeeks MW, Timetable T WHERE MW.ttID=T.ttID AND T.ttID=".$row3['ttID']." ORDER BY MW.week") or die(mysqli_error($link));
			$weeks="";
			while($rowWeeks=mysqli_fetch_assoc($sqlGetTTWeeks)){
				$weeks.=$rowWeeks['week'].",";
			}
			$weeks.=".";
			echo '<li id="'.$row3['ttID'].'"><span class="subheading">'.$row3['ttDay'].'</span>  <span style="font-weight: normal;">('.$row3['ttLocation'].')  '.$row3['ttStartTime'].' - '.$row3['ttEndTime'].' <span style="font-style:italic; font-size:0.8em;">[Weeks: '.$weeks.']</span></span>';
			if($me=="Helper"){
				$checkJoined=mysqli_query($link, "SELECT COUNT(T.mID) AS counted FROM Timetable T, ModuleHelpers MH WHERE T.ttID=MH.ttID AND MH.helperID=(SELECT hID FROM Helpers WHERE usr='".$_SESSION['mysesi']."') AND T.ttID=".$row3['ttID']) or die(mysqli_error($link));
				$checkJoined= mysqli_fetch_assoc($checkJoined);
				if($checkJoined['counted']==0){
					echo '<button type="button" class="helperJoin" id="'.$row3['ttID'].'" style="font-size: 0.6em; z-index:100;">Join</button>';
				}else{
					echo '<button type="button" class="helperLeave" id="'.$row3['ttID'].'" style="font-size: 0.6em;z-index: 100;">Leave</button>';
				}
			}
			echo '</li>';
		}
		
		
		
		echo '</td></tr></table>';
		
		if($row2['mNotes']!="" && $row2['mNotes']!=null) echo ' <h4 style="display: inline; font-size: 0.8em; vertical-align: top;">Notes:</h4> <span style=" vertical-align: top; display: inline-block; width: 400px; font-size: 0.8em; font-weight: normal;">'.$row2['mNotes'].'</span>';
		
		$sqlHours = mysqli_fetch_assoc(mysqli_query($link,'select SUM(HOUR(TIMEDIFF(T.ttEndTime,T.ttStartTime))*T.ttNoHelpers*(SELECT COUNT(week) FROM ModuleWeeks MW WHERE T.ttID=MW.ttID)) AS helperHours from Timetable T WHERE T.mID='.$_POST['mID'].';')) or die(mysqli_error($link));
		if($me=="Administrator"){ echo '<div style="display: inline-block;float:right; border: 1px solid black; border-top: 0px; padding: 5px;">Helper Hours: '.$sqlHours['helperHours']."</div>"; }
		
		echo '</div>';
	}

?>