<style type="text/css">
	.ok { background-color: #D3EEAB; }
	.no { background-color: #edabac; }
</style>

<script type="text/javascript" >

$("#submitNews").click(function(){
	var pass=0;
	$(".error").html("");	
	$(".ok").removeClass("ok");
	$(".no").removeClass("no");
	
	if($("#nTitle").val()==null || $("#nTitle").val()==""){
		$("#nTitle").parent().addClass("no");
		pass=1;
	}else $("#nTitle").parent().addClass("yes");
	
	if($("#nContent").val()==null || $("#nContent").val()==""){
		$("#nContent").parent().addClass("no");
		pass=1;
	}else $("#nContent").parent().addClass("yes");
	
	if(pass==0){
		$.post("./Content/news.php",$("#newsForm").serialize(),function(data){
			$("#viewResultN").html(data);
		});
	}
});

</script>

<h1>Send News to Lecturers and Helpers</h1><br>
<div id="viewResultN"></div>
<form id="newsForm" action="/">


<label for="peopleTo">To</label> &nbsp;&nbsp;
<select name="peopleTo">
	<option value="Lecturer">Lecturer</option>
	<option value="Helper">Helper</option>
	<option value="both">both</option>
</select><br><br>

<label for="title">Title </label>
	<span><input name="title" id="nTitle" type="text" /></span><br><br>

<label for="content">Content</label><br>
	<span style="display: inline-block; padding: 5px;"><textarea name="content" id="nContent" rows="5" cols="30"></textarea></span><br><br>

<button type="button" id="submitNews">Submit News</button>

</form>
