<?php 
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
$lLoginSession =  mysqli_real_escape_string($link, md5($_GET['session']));
$sqlLoginSession = mysqli_query($link, "SELECT id,usr,account_type,email FROM login_session WHERE pass='".$lLoginSession."'");
$row = mysqli_fetch_assoc($sqlLoginSession);
if($row['account_type']=='Lecturer'){	
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>MyLab Registration</title>

	<style type="text/css">
	
		html { font-size: 1em; }
		label { font-size: 1em; font-weight: bold; }
		form { width: 420px; }
		#submit { font-size:1em; padding: 5px 20px; }
	input[type=password]{
		width: 100px;
	}
		.error { color: red; }
		.module { border: 3px inset #F6F6F6; background: #F6F6F6; border-radius: 4px; padding: 10px; }
		
		#confirmLecturerMain { width: 200px; }
		
	</style>
	
	
	<script type="text/javascript" >
$(function(){
	
	$('#submit').live("click",function() {
		var pass=0;
		
		$(".error").html("");		
		
		if( ($("#firstName").val()=="" || $("#firstName").val()==null) || ($("#lastName").val()=="" || $("#lastName").val()==null)){ 
			$("#nameError").html("Please fill out both name boxes.");
			pass=1;
		}
		if( ($("#password").val()=="" || $("#password").val()==null)){ 
			$("#passwordError").html("Please enter a password.");
			pass=1;
		}
		if( isNaN($("#internalPhone").val()) && ($("#internalPhone").val()=="" || $("#internalPhone").val()==null)){ 
			$("#phoneError").html("Can only contain numbers.");
			pass=1;
		}
		
		
		if(pass==0){
			$.post('./confirmLecturer.php', $("#lecturerForm").serialize(), function(data) {
				alert(data+"You have completed your registration.\nPlease wait for an administrator to approve your account.");
				document.location.href="./index.php";
			});
		}
	});		
});		
	</script>


</head>
<body>

<form id="lecturerForm">
	<input type="hidden" value="Lecturer" name="accType" />
	<?php echo '<input type="hidden" value="'.$row['usr'].'" name="username" />'; ?>
	<?php echo '<input type="hidden" value="'.$row['email'].'" name="email" />'; ?>
	<div class="module" id="confirmLecturerMain">
		Forename<span style="color: red;">*</span><br />	<input id="firstName" name="firstName" type="text" style="width: 100px;"/><br />
		Surname<span style="color: red;">*</span><br />	<input id="lastName" name="lastName" type="text" style="width: 100px;"/>
		<span id="nameError" class="error"></span><br />
	
		<label for="password">Choose Password</label><br />*</span><br />	</label>
			<input type="password" name="password" id="password" /><span id="passwordError" class="error"></span><br />
	
		Internal HW Phone Number <br /> <input id="internalPhone" name="internalPhone" type="text" style="width: 100px;" />
			<span id="phoneError" class="error"></span><br />
	</div>
	
	<button id="submit" name="submit" value="submit" type="button">Save & Continue</button>
</form>

</body>
</html>
<?php
}
else echo'<script>window.location.assign("../login.php")</script>';
?>