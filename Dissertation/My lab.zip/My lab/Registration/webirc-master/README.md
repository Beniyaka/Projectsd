webirc
======

A Web IRC client
