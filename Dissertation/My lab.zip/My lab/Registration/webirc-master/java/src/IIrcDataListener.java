
public interface IIrcDataListener {
	public void handleIrcDataEvent(IrcDataObject dataobj);
}
