import java.util.EventObject;

public class IrcDataEvent extends EventObject {

	private static final long serialVersionUID = 7828347316717329848L;

	public IrcDataEvent( Object arg0 ) {
		super( arg0 );
	}

}
