<link rel="stylesheet" type="text/css" href="../Ressources/CSS/main.css" />
<link rel="stylesheet" type="text/css" href="../login_panel/css/slide.css" media="screen" />
<!-- Including the Lobster font from Google's Font Directory -->
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lobster" />
<link rel="stylesheet" type="text/css" href="../Ressources/CSS/jquery-ui-1.8.18.custom.css" media="screen" />
<!-- <link rel="stylesheet" type="text/css" href="../Ressources/CSS/jquery-ui-1.8.17.custom.css" media="print" /> -->

<style type="text/css">
	
		.container label { font-size: 1em; font-weight: bold; }
		/*.container form { width: 420px; }*/
		#submit { font-size:1em; padding: 5px 20px; }
		
		#main .error { color: red; }
		#main .module { border: 3px inset #F6F6F6; background: #F6F6F6; border-radius: 4px; padding: 10px; }
		.tabs a { padding: 0px; color: #555555; }
		.tabs a { padding: 0px; }
		.tabs a { margin: 0px; padding: 0px; }
		.tabs a { 
			-moz-border-radius:0px 0px 0px 0px;
			-khtml-border-radius: 0px 0px 0px 0px;
			-webkit-border-radius: 0px 0px 0px 0px;
			border-radius: 0px 0px 0px 0px; 
			behavior: url(Ressources/PIE/PIE.php);
		}
		
		.tabs a:first-child { 
			border-radius: 6px 0px 0px 6px;
			-moz-border-radius:6px 0px 0px 6px;
			-khtml-border-radius: 6px 0px 0px 6px;
			-webkit-border-radius: 6px 0px 0px 6px;
		}
		.tabs a:last-child { 
			border-radius: 0px 6px 6px 0px; 
			-moz-border-radius:0px 6px 6px 0px;
			-khtml-border-radius: 0px 6px 6px 0px;
			-webkit-border-radius: 0px 6px 6px 0px;
		}
		
		.tabs a div { 
			display: inline-block;
			vertical-align: middle;
		}
		.tabs a { display: inline-block; vertical-align: middle; overflow: visible; }
		
		.tabs { color: #555555; }
		
		#settings div { 
			background: transparent url('./Ressources/IMG/Control Panel.png') no-repeat center center;
			background-size: 25px 25px;
			overflow: hidden;
			padding-left: 12px;
			padding-right: 12px;
			text-indent: -9999px;
		}
		
		#msgs div { 
			background: transparent url('./Ressources/IMG/Envelope.png') no-repeat center center;
			background-size: 31px 30px;
			overflow: hidden;
			padding-left: 11px;
			padding-right: 11px;
			text-indent: -9999px;
		}
		
		#home div{
			background: transparent url('./Ressources/IMG/home.png') no-repeat center center;
			background-size: 25px 20px;
			overflow: hidden;
			padding-left: 13px;
			padding-right: 6px;
			text-indent: -9999px;
		}
		
		#circle {
			display: inline-block; 
			vertical-align: middle; 
			color: white; 
			padding: 1px; padding-left: 2px; padding-right: 2px; 
			border: 1px solid white;
		 	border-radius: 30px; 
		 	background-color: red; 
		 	text-align: center; 
		 	font-weight: bold; 
		 	font-size: 12px; 
		 	position: absolute; 
		 	right: -5px; 
		 	bottom:-3px; 
		 	z-index: 1; 
		 	behavior: url(Ressources/PIE/PIE.php);
		}
		
	</style>



<script type='text/javascript' src='../Ressources/JS/jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../Ressources/JS/jquery-ui-1.8.18.custom.min.js'></script>
<!-- PNG FIX for IE6 -->
<!-- http://24ways.org/2007/supersleight-transparent-png-in-ie6 -->
<!--[if lte IE 6]>
	<script type="text/javascript" src="../login_panel/js/pngfix/supersleight-min.js"></script>
<![endif]-->
    
<script src="../login_panel/js/slide.js" type="text/javascript"></script>