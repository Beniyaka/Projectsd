<?php 
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>MyLab Registration</title>
	<!-- <script src="../Ressources/JS/Uploader/jquery.ui.widget.js"></script> -->
   <script src="../Ressources/JS/Uploader/jquery.iframe-transport.js"></script>
	<script src="../Ressources/JS/Uploader/jquery.fileupload.js"></script>
	
	<style type="text/css">
		label { font-size: 1em; font-weight: bold; }
		.error { color: red; }
	</style>

<?php	
	$sql = mysqli_query($link, "SELECT courseLevelType, courseLevelID FROM CourseLevels");
	echo'<script type="text/javascript" >';
	echo 'var addCourse = "<select name=\"degreeType[]\" size=\"0\">';
	while($row2 = mysqli_fetch_assoc($sql)){
	echo '<option value=\"'.$row2['courseLevelID'].'\">'.$row2['courseLevelType'].'</option>';
	}
	echo '</select>"';
	echo '</script>';
?>


<script type="text/javascript" >


$(document).ready(function(){
	
	var prependCount = 0;
	$("#degrees").prepend(addCourse);
	var degreeHTML = $("#degrees").html();
	$("#degrees").html("<div id=\"degree"+prependCount+"\">"+degreeHTML+"</div>");
	 
	 
	 
	$("#addDegree").click(function(){
		$("#degrees").prepend("<div id=\"degree"+prependCount+"\">"+degreeHTML+"</div>");
		prependCount++;
	});
	 
	 
	$("#rmvDegree").click(function(){
		$("#degree"+prependCount).remove();
			prependCount--;
	});	 	 
	 
	$('#submit').click(function() {
		var pass=0;
		
		$(".error").html("");		
		
		if( ($("#firstName").val()=="" || $("#firstName").val()==null) || ($("#lastName").val()=="" || $("#lastName").val()==null)){ 
			$("#nameError").html("Please fill out both name boxes.");
			pass=1;
		}
		if( ($("#password").val()=="" || $("#password").val()==null)){ 
			$("#passwordError").html("Please enter a password.");
			pass=1;
		}
		if( isNaN($("#phone").val()) ){ 
			$("#phoneError").html("Can only contain numbers.");
			pass=1;
		}
		if( ($("#degreeName").val()=="" || $("#degreeName").val()==null) || ($("#university").val()=="" || $("#university").val()==null)){ 
			$("#uniError").html("Please fill out all the boxes of degree type");
			pass=1;
		}
		if( ($("#supp").val()=="" || $("#supp").val()==null)){ 
			$("#suppError").html("Please Choose a Supporting Statement.");
			pass=1;
		}
		if( ($("#cvH").val()=="" || $("#cvH").val()==null)){ 
			$("#cvError").html("Please Choose a CV.");
			pass=1;
		}
		
		
		// Check that at least one skill is chosen
		var is_checked = 0;
		$(".skills").each(function(index){ 
			if(this.checked){	is_checked ++;	}
		});
		if(is_checked==0){
			pass=1;
			$("#skillError").html("Please select at least one skill from below.");
		}
		
		
		if(pass==0){
			$.post('./confirmHelper.php', $("#helperForm").serialize(), function(data) {
				alert(data+"You have completed your registration.\nPlease wait for an administrator to approve your account.");
				document.location.href="./index.php";
			});
		}
	});
	
	$('#cv').fileupload({
   	dataType: 'json',
   	url: '../userUploadedFiles/cvs/index.php',
      done: function (e, data) {
   		$.each(data.result, function (index, file) {
   			$('#cvH').val(file.name);
   			$('#cvInfo').html(file.name);
         });
      }
	});
	
	$('#suppStatement').fileupload({
   	dataType: 'json',
   	url: '../userUploadedFiles/supportingStatements/index.php',
      done: function (e, data) {
   		$.each(data.result, function (index, file) {
         	$('#supp').val(file.name);
         	$('#suppStatementInfo').html(file.name);
         });
      }
	});
	
});

</script>



</head>
<body>
<div style="float:right;">
		<!--	<input id="fileupload" type="file" name="files[]" multiple> -->
		<label for="suppStatement">Upload Supporting Statement<span style="color: red;">*</span> </label><br />
			<input id="suppStatement" name="files[]" type="file" style="width: 95px; overflow:hidden;" multiple><br />
			<span id="suppError" class="error"></span>
			<div id="suppStatementInfo" style="color: blue; width: 150px; overflow:hidden; text-overflow: ellipsis; white-space:nowrap;">..</div><br />
		<label for="cv">Upload CV<span style="color: red;">*</span></label><br />
			<input id="cv" name="files[]" type="file" style="width: 95px; overflow:hidden;" multiple><br />
			<span id="cvError" class="error"></span>
			<div id="cvInfo" style="color: blue;  width: 150px; overflow:hidden; text-overflow: ellipsis; white-space:nowrap;">..</div>
			<br />
</div>

<div>
	<form method="post" enctype="multipart/form-data" id="helperForm" name="helperForm">
		<input type="hidden" id="supp" name="suppStatement" />
		<input type="hidden" id="cvH" name="cv" />
		<input type="hidden" value="Helper" name="accType" />
		<?php echo '<input type="hidden" value="'.$sqlUsers['usr'].'" name="username" />'; ?>
		<?php echo '<input type="hidden"  value="'.$sqlUsers['email'].'" name="email" />'; ?>
		
		<label for="firstName">Forename<span style="color: red;">*</span>	</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<label for="lastName">Surname<span style="color: red;">*</span>	</label><br />
			<input id="firstName" name="firstName" type="text" style="width: 100px;"/>&nbsp;
			<input id="lastName" name="lastName" type="text" style="width: 100px;"/><span id="nameError" class="error"></span><br /><br />
			
			
		<label for="password">Choose Password <span style="color: red;">*</span></label><br />
			<input type="password" name="password" id="password" /><span id="passwordError" class="error"></span><br /><br />
			
		<label for="phone">Enter phone number</label><br />
			<input type="text" name="phone" id="phone" /><span id="phoneError" class="error"></span><br /><br />			
	
			
		<label for="degreeType">Degree(s) held<span style="color: red;">*</span> <br /></label> 
		<button id="addDegree" type="button">Add another</button>
		<button id="rmvDegree" type="button">Remove last</button>
		
		<div id="degrees">
			<br />
			<input id="degreeName" name="degreeName[]" type="text" title="degree name" style="width:220px;" value="Degree Name" /><br />
			<input id="university" name="university[]" type="text" title="University" style="width:220px;" value="Institution Name" /><span id="uniError" class="error"></span>
			<br /><br />
		</div>
			
<!--		<label>Certificate(s) held </label><br />
			<input id="certName" name="certName" type="text" title="certificate name" style="width:220px;" value="Certificate Name" /><br />
			<input id="certInstitution" name="certInstitution" type="text" title="Institution" style="width:220px;" value="Institution Name" /><span id="certError" class="error"></span>
			<br /><br />
-->		 
		<label style="font-size: 2em;"> Skills<span style="color: red;">*</span></label><span id="skillError" class="error"></span>
			<?php
				getSkillsTable($link);
			?>
			<br /><br />
		<div style="position:relative; width:100%"><button id="submit" name="submit" value="submit" type="button" style=" width: 100px; margin-left:auto; margin-right:auto;">Save & Continue</button></div>
	</form>
</div>
</body>
</html>