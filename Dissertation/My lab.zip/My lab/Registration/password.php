<link rel="shortcut icon" href="./Ressources/IMG/logo.ico" type="image/x-icon"/>
<script>
	$('#submit').click(function()
{
    $.ajax({
        url: "./email.php",
        type:'POST',
        data:
        {
            email: "iyakabeni@yahoo.com",
            message: "test"
        },
        success: function(msg)
        {
            alert('Email Sent');
        }               
    });
});
</script>
<?php
define('INCLUDE_CHECK',true);
require './connect.php';
require './functions.php';
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <a><img class="me" src="./Ressources/IMG/testt.jpg"/><a class="just"><img src="./Ressources/IMG/logo.png"/></a><a href="./login.php"><button class="button">Welcome</button></a></a>  
  <title>Password Reset</title>
<link rel="stylesheet" href="/Ressources/CSS/main.css"/>

    <?php include("./baseInclude.php"); ?>
   	<?php		
	echo '<script type="text/javascript" >$(window).load(function(){ 
	setTimeout(function() {
  	$("#middle").css("visibility","visible");
  	$("#loading").hide();
	},500);
});</script>';
	?>
<script type="text/javascript" >
$(function() {
	$(".tabs a:last-child").css("border-radius","0px 6px 6px 0px");
	$(".tabs a:first-child").css("border-radius"," 6px 0px 0px 6px");
	$( "a", ".tabs" ).button();
});
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
function be(){
	$( "#push" ).css({
    borderStyle: "inset",
    visibility: "hidden"
  });
    $( "#test" ).slideDown( 1000, function() {
    $( this )
      .filter( ".middle" )
        .css( "background", "yellow" )
        .focus();
    $( "#login" ).hide();
  });

		
	}
function ben(){
	$( "#push" ).css({
    borderStyle: "inset",
    visibility: "hidden"
  });
    $( "#reset" ).slideDown( 1000, function() {
    $( this )
      .filter( ".middle" )
        .css( "background", "yellow" )
        .focus();
    $( "#login" ).hide();
    $("#test").hide();
  });

		
	}

</script>
</head>
<body onload="startTime()">
<div id="header">
<div id="txt"></div><h1 id="text">Lab Helper System</h1>
</div>
<div id="section" class="containers">
<div id="login">
<form method="post" class="login">
       		 <p><input type="password" name="password" id="password" placeholder="Password" autocomplete="off"></p>
       		 <p><input type="password" name="password2" id="password2" placeholder="Confirm Password" autocomplete="off"></p>
       				<p class="submit"><input type="submit" name="submit" id="submit" value="Reset"></p>
		<input type="hidden" name="Nscmd" value="Nlogin" />
	</form>
</div>
</body>
</html>