<?php 

if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');

$lLoginSession =  mysqli_real_escape_string($link, md5($_GET['session']));
$sqlLoginSession = mysqli_query($link, "SELECT id,usr,account_type,email FROM login_session WHERE pass='".$lLoginSession."'");

$row = mysqli_fetch_assoc($sqlLoginSession);

?>

<?php
	if($row['account_type']=='Lecturer'){
		include("./confirmLecturerForm.php");
	} elseif($row['account_type']=='Helper') {
		include("./confirmHelperForm.php");
	} else {
		echo "Your link has either expired or incomplete information was given<br> please try registering again";
	}
?>