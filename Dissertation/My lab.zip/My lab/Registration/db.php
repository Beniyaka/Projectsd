<?php 
define('INCLUDE_CHECK',true);

require '../connect.php';
require '../functions.php';

$conn = mysqli_connect('localhost', 'root', '','mylab');
//save_file_upload("../".$suppStDir,$_FILES["suppStatement"]);
//save_file_upload("../".$CVdir,$_FILES["cv"]);

//$sqlUsers = mysqli_prepare($link, "INSERT INTO Users(usr,pswd,email,accType,approvedUser) VALUES(?,?,?,?,?)");
//mysqli_stmt_bind_param($sqlUsers, 'sssss', $hUsername, md5($_POST['password']), $_POST['email'], $_POST['accType'],'false');

$hUsername = $conn -> query("SELECT usr FROM login_session WHERE usr ='{$_SESSION['pass']}'");
$passs = "Wonder12";
$acctype = "Helper";
$approve = "false";
if(	 $conn -> query("INSERT INTO users(usr,pswdd,accType,approvedUser) VALUES('$hUsername', '$pass', '$acctype','$approve')")){
	echo("Wonder");
}
else
echo "Error";
						
						
$sqlHelpers = mysqli_prepare($link, "INSERT INTO Helpers(usr, hFirstName ,hSurname, hPhone, hSupportingStatement, hCV) VALUES (?,?,?,?,?,?)");
mysqli_stmt_bind_param($sqlHelpers, 'sssdss', $hUsername, $_POST['firstName'], $_POST['lastName'], $_POST['phone'], $hSupportingStatement, $hCV);

$hSupportingStatement = $domain_name.$suppStDir.$_POST['suppStatement'];
$hCV = $domain_name.$CVdir.$_POST['cv'];				

		
$sqlDegree = "INSERT INTO HelperDegrees (helperID, courseLevelID, courseLevelName, courseLevelInstitution) VALUES ";
for($i=0; $i<sizeof($_POST['degreeType']); $i++){
	if($i>0){ $sqlDegree.=",";}
     $sqlDegree .= "((SELECT hID FROM Helpers WHERE usr='".$hUsername."') ,".mysqli_real_escape_string($link, $_POST['degreeType'][$i]).",'".mysqli_real_escape_string($link, $_POST['degreeName'][$i])."','".mysqli_real_escape_string($link, $_POST['university'][$i])."')";
}	
		
		
		
		
							
$sqlSkills = "INSERT INTO HelperSkills VALUES ";
for($i=0; $i<sizeof($_POST['skills']); $i++){
	if($i>0){ $sqlSkills.=",";}
     $sqlSkills .= "((SELECT hID FROM Helpers WHERE usr = '".$hUsername."') ,".mysqli_real_escape_string($link, $_POST['skills'][$i]).")";
}

			
$sqlDeleteSession = mysqli_prepare($link, "DELETE FROM login_session WHERE usr = ? ");
mysqli_stmt_bind_param($sqlDeleteSession, 's', $hUsername);
	
							
if(mysqli_stmt_execute($sqlUsers)){
	mysqli_stmt_close($sqlUsers);
	if(mysqli_stmt_execute($sqlHelpers)){
		mysqli_stmt_close($sqlHelpers);
		if(mysqli_query($link, $sqlDegree)){
				mysqli_query($link, $sqlSkills);
				
				mysqli_stmt_execute($sqlDeleteSession) or die(mysqli_errno($link));
				mysqli_stmt_close($sqlDeleteSession);
				
					send_mail(	'no-reply@mylab.macs.hw.ac.uk',
					$_POST['email'],
					'MyLab Registration done - info',
					'Your registration has been successful, Please keep your password safe.
User Name: '.$_POST['username'].'
password chosen: '.$_POST['password'].'
And email will be sent once an Administrator has approved you as a user.
Thank you for using MyLab!
');

		}
	}
}
?>