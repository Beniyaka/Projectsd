<?php 

define('INCLUDE_CHECK',true);

require '../connect.php';
require '../functions.php';
$pass = md5($_POST['password']);
$email = $_POST['email'];
$acctype =  $_POST['accType'];
$approve = "false";
$firstname = $_POST['firstName'];
$lastname = $_POST['lastName'];
$phone = $_POST['internalPhone'];

$sqlUsers = mysqli_prepare($link, "INSERT INTO Users(usr,pswd,email,accType,approvedUser) VALUES(?,?,?,?,?)");
mysqli_stmt_bind_param($sqlUsers, 'sssss', $lUsername, $pass, $email,$acctype, $approve);
$lUsername = mysqli_real_escape_string($link, $_POST['username']);


$sqlLecturers = mysqli_prepare($link, "INSERT INTO Lecturers(usr, lFirstName ,lSurname, lPhone) VALUES (?,?,?,?)");
mysqli_stmt_bind_param($sqlLecturers, 'sssd', $lUsername, $firstname, $lastname, $phone);

$sqlDeleteSession = mysqli_prepare($link, "DELETE FROM login_session WHERE usr = ? ");
mysqli_stmt_bind_param($sqlDeleteSession, 's', $lUsername);


if(mysqli_stmt_execute($sqlUsers)){
	if(mysqli_stmt_execute($sqlLecturers)){
			mysqli_stmt_execute($sqlDeleteSession) or die(mysqli_error());
			
			$msgSender = 'no-reply@mylab.macs.hw.ac.uk';
			$to = $_POST['email'];
			$subject = 'MyLab Registration done - info';
			$message = 'MyLab Registration done - info'.
			'Your registration has been successful, Please keep your password safe.
User Name: '.$_POST['username'].'
password chosen: '.$_POST['password'].'
An email will be sent to you once an Administrator has aproved you as a user.
Thank you for using MyLab! 
';
			$retval = mail($to,$subject,$message);
		if($retval == TRUE){
			echo '<script>alert(" An email has been sent to '.$_POST['email'].'. Thank you for using the Lab Helper System")</script>';	

}
	}
}


?>