<?php
define('INCLUDE_CHECK',true);
require './connect.php';
require './functions.php';

?>

<a><img class="me" src="./Ressources/IMG/testt.jpg"/><a class="just"><img src="./Ressources/IMG/logo.png"/></a><a href="./login.php"><button class="button">Welcome</button></a></a>
<?php
session_start();

if(isset($_POST['register'])){
     $err = array();
	
	if(strlen($_POST['username'])<4 || strlen($_POST['username'])>32)
	{
		echo"<script>alert('Your username must be between 3 and 32 characters!')</script>";
	}
	
	elseif(preg_match('/[^a-z0-9\-\_\.]+/i',$_POST['username']))
	{
		echo"<script>alert('Your username contains invalid characters!')</script>";
	}
	
	elseif(!checkEmail($_POST['email']))
	{
		echo"<script>alert('Your email is not valid!')</script>";
	}
	
	elseif(preg_match('/[^a-z0-9\.]+/i',$_POST['accountType'])){
		echo"<script>alert('Please select an account type!')</script>";
	}
	
	else
	{
		// If there are no errors
		
		$pass = substr(md5($_SERVER['REMOTE_ADDR'].microtime().rand(1,100000)),0,6);
		// Generate a random password
		
		$_POST['email'] = mysqli_real_escape_string($link, $_POST['email']);
		$_POST['username'] = mysqli_real_escape_string($link, $_POST['username']);
		// Escape the input data
		
		
		mysqli_query($link, "	INSERT INTO login_session(usr,pass,account_type,email,regIP,dt)
						VALUES(
						
							'".$_POST['username']."',
							'".md5($pass)."',
							'".$_POST['accountType']."',
							'".$_POST['email']."',
							'".$_SERVER['REMOTE_ADDR']."',
							NOW()
							
						)");
		
		if(mysqli_affected_rows($link)==1)
		{
			$to = $_POST['email'];
	 		$subject = "MyLab Registration - Registration Link";
	 		$message = "Please follow the following link to complete your registration:
	 		
						$domain_name Registration/?pg=continueReg&session=$pass ";

$from = "registration@mylab.macs.hw.ac.uk";

		$retval = mail($to,$subject,$message);
		if($retval == TRUE){
			echo '<script>alert(" An email has been sent to '.$_POST['email'].'. Thank you for using the Lab Helper System")</script>';	
			}
			}
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <?php include("./baseInclude.php"); ?>
   	<?php		
	echo '<script type="text/javascript" >$(window).load(function(){ 
	setTimeout(function() {
  	$("#middle").css("visibility","visible");
  	$("#loading").hide();
	},500);
});</script>';
	?>

<script type="text/javascript" >
$(function() {
	$(".tabs a:last-child").css("border-radius","0px 6px 6px 0px");
	$(".tabs a:first-child").css("border-radius"," 6px 0px 0px 6px");
	$( "a", ".tabs" ).button();
});
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
function be(){
	$( "#push" ).css({
    borderStyle: "inset",
    visibility: "hidden"
  });
    $( "#test" ).slideDown( 1000, function() {
    $( this )
      .filter( ".middle" )
        .css( "background", "yellow" )
        .focus();
    $( "#login" ).hide();
  });

		
	}

</script>

</head>


<!DOCTYPE html>
<html>
<head>
<title>Lab Helper System</title>
<link rel="stylesheet" href="/Ressources/CSS/main.css"/>
</head>
<body onload="startTime()">
<div id="header">
<div id="txt"></div><h1 id="text">Lab Helper System</h1>
</div>

<div id="nav3">
<li><a href="">Reset Password</a></li>
<li><a href="">Contact Administrator</a></li>
</div>


<div id="section" class="containers">
<form method="post" action="" class="login">
		<br /><select name="accountType" size="0" class="field" required autofocus>
						<option value="--Account Type--" >-- Account Type --</option>
						<option value="Helper">Helper</option>
 	 					<option value="Lecturer">Lecturer</option>
		 </select>
		<p><input type="text" name="email" id="email"  placeholder="Email" autocomplete="off" required></p>
       		 <p><input type="text" name="username" id="username" placeholder="Username" autocomplete="off" required></p>
       				<p class="submit"><input type="submit" name="register" value="Register"></p>
		<input type="hidden" name="Nscmd" value="Nlogin" />
	</form>
</div>

<div id="footer">
<h3>This website was developed by <a href="http://ibktech.tk/en/Our-Team/#wb_element_instance149" style="text-decoration:none;"><span style="font-style:italic; font: 16px/1 Lobster,Arial,sans-serif;"> Beni Iyaka </span>.</a></h3>
</div>

</body>
</html>
