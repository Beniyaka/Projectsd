<?php 
	//if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
	
	define('INCLUDE_CHECK',true);
	require '../connect.php';
	
	$sqlListHelperUsers = "SELECT usr, email, accType FROM Users ORDER BY accType;";
	$sqlListLecturerUsers = "SELECT usr, ";
	
	
	$result = mysqli_query($link, $sqlListHelperUsers);
	
	
	if(mysqli_errno($link)){
		echo "There was an error\n\n\"".mysqli_error($link)."\"";
	}else{
		echo "<table id=\"userTable\">";
		echo "<tr>";
		echo "<th>User Name</th>";
		echo "<th>Email</th>";
		echo "<th>Account Type</th>";
		echo "</tr>";
		while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row['usr']."</td>";
			echo "<td>".$row['email']."</td>";
			echo "<td>".$row['accType']."</td>";
			echo "</tr>";
			
		}
		echo "</table>";

	}	
	
	
	mysqli_close($link);
	
?>