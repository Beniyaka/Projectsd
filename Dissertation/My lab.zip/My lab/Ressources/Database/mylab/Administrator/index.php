<?php

define('INCLUDE_CHECK',true);
require '../connect.php';
require '../functions.php';

session_name('mylabLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();

if( !($_SESSION['usr'])){
	die('<meta HTTP-EQUIV="REFRESH" content="0; url='.$domain_name.'">');
}elseif(!($_SESSION['accType']=="Administrator")){
	die(include('../Content/badPermission.php'));
}

?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>MyLab Administrator</title>

<?php include("./baseInclude.php"); ?>


<style type="text/css">
	#userAdmin { font-size: 1em; width: 620px; border: 2px outset silver; border-radius: 4px; padding: 20px; }
	.AdminTitle { font-size: 2em; font-weight: bold; color: blue; }
	.instruction { font-size: 1em; }
	.error { color: red; }
	
	#actionsOnUsers {  width: 550px; border: 2px inset #F6F6F6; border-radius: 4px; background: #F6F6F6; padding: 10px; }
	#seeUser {  width: 550px; border: 2px inset #F6F6F6; border-radius: 4px; background: #F6F6F6; padding: 10px; }
	
	#userList { max-width: 500px; overflow: auto; }
	
	table { border: 1px solid black; border-collapse: collapse; }
	th { border: 1px solid black; font-size: 1em; font-weight: bold; padding: 5px; }
	td { border: 1px solid black; font-size: 1em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; padding: 5px;}
</style>

<script type="text/javascript" >

$(document).ready(function(){
	
	$("#purgeUsers").click(function(){
		$.post("./purgeUsers.php", function(data) {
			alert(data);
		});
	});
	
	$("#deleteUser").click(function(){
		var userToDelete = $("#deleteUserName").val();
		$.post("./deleteUser.php", {"deleteUserName" : userToDelete}, function(data) {
			alert(data);
			$("#deleteUserName").val("");
		});
	});
	
	$("#listAllUsers").click(function(){
		$.post("./listAllUsers.php", function(data) {
			$("#userList").html(data);
		});
	});
	

});

</script>

</head>
<body>
	<div id="userAdmin">
		<span class="AdminTitle">User Administration</span><br /><br />
		
		<div id="actionsOnUsers">
			<span class="error">Warning! this will delete all users </span>
			<button id="purgeUsers" name="purgeUsers" value="purgeUsers" type="button">Purge Users</button><br /><br />
		
			<span class="instruction">Enter user name to delete</span>
			<input id="deleteUserName" name="deleteUserName" type="text" />
				<button id="deleteUser" name="deleteUser" value="deleteUser" type="button">Delete User</button><br /> <br />
		</div>
		<br /><br /><br />
		<div id="seeUser">	
			<button id="listAllUsers" name="listAllUsers" value="listAllUsers" type="button">List All Users</button><br /><br />
			<div id="userList"></div>
		</div>
	</div>
	
</body>
</html>
