<link rel="stylesheet" type="text/css" href="../Ressources/CSS/jquery-ui-1.8.17.custom.css" media="screen" />
<script type='text/javascript' src='../Ressources/JS/jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../Ressources/JS/jquery-ui-1.8.17.custom.min.js'></script>
