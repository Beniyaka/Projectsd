<?php

if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');

function checkEmail($str)
{
	return preg_match("/^[\.A-z0-9_\-\+]+((@hw.ac.uk)|(@macs.hw.ac.uk)){1}$/", $str);
}


function send_mail($from,$to,$subject,$body)
{
	$headers = '';
	$headers .= "From: $from\n";
	$headers .= "Reply-to: $from\n";
	$headers .= "Return-Path: $from\n";
	$headers .= "Message-ID: <" . md5(uniqid(time())) . "@" . $_SERVER['SERVER_NAME'] . ">\n";
	$headers .= "MIME-Version: 1.0\n";
	$headers .= "Date: " . date('r', time()) . "\n";

	if(mail($to,$subject,$body,$headers)){
		return true;
	}else return false;
}

function save_file_upload($folderPath,$theFile){
$theFile["name"]=$_POST['username']."-".date("Y.m.d H:m:s")."-".$theFile["name"];
if ($theFile["size"] < 2000000)
	  {
	  if ($theFile["error"] > 0)
	    {
	    echo "Return Code: " . $theFile["error"] . "<br />";
	    return 0;
	    }
	  else
	    {
	    //echo "Upload: " . $theFile["name"] . "<br />";
	    //echo "Type: " . $theFile["type"] . "<br />";
	    //echo "Size: " . ($theFile["size"] / 1024) . " Kb<br />";
	    //echo "Temp file: " . $theFile["tmp_name"] . "<br />";
	
	    if (file_exists($folderPath . $theFile["name"]))
	      {
	      echo $theFile["name"] . " already exists. ";
	      return 0;
	      }
	    else
	      {
	      return move_uploaded_file($theFile["tmp_name"],
	      $folderPath . $theFile["name"]);
	      }
	    }
	  }
	else
	  {
	  echo "Invalid file";
	  return 0;
	  }
	return 1;
	  
}

function getSkillsTable($link, $edit){
		if($edit!="" && $edit!=null && $edit!=-1){
			$sqlGetMSkills = mysqli_query($link, "SELECT S.skillID FROM ModuleSkillsRequired S WHERE moduleID=".$edit) or die(mysqli_error($link));
			while($rowS=mysqli_fetch_assoc($sqlGetMSkills)){
				$getS[]=$rowS['skillID'];
			}
		}
		echo '<table style="border: 2px solid blue; border-radius: 4px;">';	
		$sql2 = mysqli_query($link, "SELECT S.skillName, S.skillID, T.typeName FROM Skills S, SkillType T WHERE S.skillType=T.typeID ORDER BY S.skillType");
		$xx = 0;
		$skillType="";
		while($row2 = mysqli_fetch_assoc($sql2)){
			if($skillType!=$row2['typeName'] && $xx!=0){
				echo '</tr></table><br><label>'.$row2['typeName'].'</label><br><table style="border: 2px solid blue; border-radius: 4px;">';
				$xx=1;
			}
			if($xx==0){ $xx=1; echo '<br><label>'.$row2['typeName'].'</label><br>'; }
			$skillType = $row2['typeName'];
			$skill = $row2['skillName'];
			$skillID=$row2['skillID'];
			$var = 4;
			if($skillType=="Concept")$var=2;
			if(($xx % $var)== 1){ 
				echo '<tr>'; }
				
			// if edit mode check corresponding skills
			$ee=""; if($edit>-1){if(in_array($skillID,$getS)){ $ee="checked=\"yes\""; } }
			echo '<td><input type="checkbox" name="skills[]" class="skills" '.$ee.' value="'.$skillID.'" /> '.$skill.' </td>';
			if(($xx % $var	)== 0){
				echo '</tr>'; }
				$xx=$xx+1;
		}
		echo '</table>';	
}

function startAndCheckSession($sessionCheckType){
	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();

	if( !($_SESSION['usr']) && !($_SESSION['accType']==$sessionCheckType)){
		die("You do not have the necessary priviledges to access this webpage");
	}
}
?>