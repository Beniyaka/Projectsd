<?php

if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');

$db_host		= 'localhost';
$db_user		= 'root';
$db_pass		= '';
$db_database	= 'mylab'; 

$domain_name = 'http://localhost/mylab/';

$email_domains[0] = '@hw.ac.uk';
$email_domains[1] = '@macs.hw.ac.uk';

$CVdir = "userUploadedFiles/cvs/files/";
$suppStDir = "userUploadedFiles/supportingStatements/files";

$link = mysqli_connect($db_host,$db_user,$db_pass,$db_database) or die('Unable to establish a DB connection');

mysqli_query($link, "SET names UTF8");

/* Database config */
/*
$db_host		= 'localhost';
$db_user		= 'drewbos1_session';
$db_pass		= 'UserName&PasswordChecker5]';
$db_database	= 'drewbos1_mylab'; 
*/

/* End config */

// $domain_name = 'http://drewboswell.net/mylab/';
//scp /home/drew/Dropbox/Uni/Dissertation/Database/Dissertation.sql acb8@jove.macs.hw.ac.uk:/u1/cs4/acb8/public_html/mylab/
//scp . acb8@athena.macs.hw.ac.uk:/var/www/html/macs/cs/mylab/test/
// find . -type f -name "*.*~" -exec rm -f {} \;

?>
