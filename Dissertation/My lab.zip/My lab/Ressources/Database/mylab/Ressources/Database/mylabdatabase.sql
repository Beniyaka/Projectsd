DROP TABLE News;
DROP TABLE Requests;
DROP TABLE ReqTypes;
DROP TABLE AllocateHelpers;
DROP TABLE AllocateStatus;
DROP TABLE ModuleWeeks;
DROP TABLE ModuleHelpers;
DROP TABLE Timetable;
DROP TABLE Weekdays;
DROP TABLE ModuleLecturers;
DROP TABLE ModuleSkillsRequired;
DROP TABLE ModuleLevels;
DROP TABLE Modules;
DROP TABLE ModuleLevelNames;
DROP TABLE Terms;
DROP TABLE TermYears;
DROP TABLE Lecturers;
DROP TABLE HelperSkills;
DROP TABLE Skills;
DROP TABLE SkillType;
DROP TABLE HelperDegrees;
DROP TABLE Helpers;
DROP TABLE Users;
DROP TABLE CourseLevels;
DROP TABLE `subscribers`;
DROP TABLE `login_session`;
DROP TABLE AccountTypes;

-- ---------------------------
-- Login Session -------------
-- ---------------------------

CREATE TABLE AccountTypes(
	accTypeID INT(1) AUTO_INCREMENT PRIMARY KEY,
	accTypeName VARCHAR(20) NOT NULL UNIQUE
)ENGINE=INNODB;


CREATE TABLE `login_session` (
  `id` int(11) NOT NULL auto_increment,
  `usr` varchar(32) collate utf8_unicode_ci NOT NULL default '',
  `pass` varchar(32) collate utf8_unicode_ci NOT NULL default '',
  `account_type` varchar(14) NOT NULL,
  `email` varchar(255) collate utf8_unicode_ci NOT NULL default '' UNIQUE,
  `regIP` varchar(15) collate utf8_unicode_ci NOT NULL default '',
  `dt` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `usr` (`usr`),
  FOREIGN KEY (`account_type`) REFERENCES AccountTypes(`accTypeName`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=INNODB;

-- ---------------------------
-- Subscribers---------------
-- ---------------------------

CREATE TABLE `subscribers` (
`email` VARCHAR( 255 ) NOT NULL UNIQUE ,
`subscribed_at` DATETIME NOT NULL
)ENGINE=INNODB;

-- --------------------------
-- MyLab main info ----------
-- --------------------------

CREATE TABLE CourseLevels(
	courseLevelID INT(2) PRIMARY KEY AUTO_INCREMENT,
	courseLevelType VARCHAR(50) NOT NULL UNIQUE
)ENGINE=INNODB;

CREATE TABLE Users (
	`usr` varchar(32),
	`pswd` varchar(32) collate utf8_unicode_ci NOT NULL default '',
	`email` VARCHAR(100) NOT NULL UNIQUE,
	`accType` VARCHAR(14) NOT NULL,
	`approvedUser` ENUM('true','false') DEFAULT 'false' NOT NULL,
	`activeUser` ENUM('true','false') DEFAULT 'true' NOT NULL,
	`dateAdded` TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
	PRIMARY KEY  (`usr`),
	FOREIGN KEY (`accType`) REFERENCES AccountTypes(`accTypeName`) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE Helpers (
	hID INT(8) PRIMARY KEY AUTO_INCREMENT,
	usr varchar(32) NOT NULL,
	hFirstName VARCHAR(50) NOT NULL,
	hSurname VARCHAR(50) NOT NULL,
	hPhone INT(12),
	hAprovedTutor INT(1),
	hAprovedEndDate DATE,
	hAttendedCourse INT(1),
	hPeerObsDone INT(1),
	hSupportingStatement VARCHAR(200) NOT NULL,
	hCV VARCHAR(200) NOT NULL,
	attendedCourseCertificateDate DATE,
	actionToBeTaken VARCHAR(500),
	FOREIGN KEY (usr) REFERENCES Users (usr) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE HelperDegrees (
	dID INT(8) PRIMARY KEY AUTO_INCREMENT,
	helperID INT(8) NOT NULL,
	courseLevelID INT(2) NOT NULL,
	courseLevelName VARCHAR(100) NOT NULL,
	courseLevelInstitution VARCHAR(100) NOT NULL,
	FOREIGN KEY (helperID) REFERENCES Helpers(hID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (courseLevelID) REFERENCES CourseLevels(courseLevelID) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE SkillType (
	typeID INT(2) PRIMARY KEY AUTO_INCREMENT,
	typeName VARCHAR(200) NOT NULL,
	UNIQUE (typeID, typeName)
)ENGINE=INNODB;

CREATE TABLE Skills (
	skillID INT(5) PRIMARY KEY AUTO_INCREMENT,
	skillType INT(2) NOT NULL,
	skillName VARCHAR(50) NOT NULL,
	dateAdded TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (skillType) REFERENCES SkillType(typeID) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE HelperSkills(
	helperID INT(8) NOT NULL,
	skillID INT(5) NOT NULL,
	FOREIGN KEY (helperID) REFERENCES Helpers(hID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (skillID) REFERENCES Skills(skillID) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE Lecturers(
	lecturerID INT(6) PRIMARY KEY AUTO_INCREMENT,
	usr varchar(32) NOT NULL,
	lFirstName VARCHAR(50) NOT NULL,
	lSurname VARCHAR(50) NOT NULL,
	lPhone INT(6),
	FOREIGN KEY (usr) REFERENCES Users (usr) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE TermYears (
	tYearID INT(5) PRIMARY KEY AUTO_INCREMENT,
	tYearStart INT(4) NOT NULL,
	tYearEnd INT(4) NOT NULL
)ENGINE=INNODB;

CREATE TABLE Terms (
	termID INT(6) PRIMARY KEY AUTO_INCREMENT,
	termYearID INT(5) NOT NULL,
	term INT(1) NOT NULL,
	helperRate FLOAT(5,2) NOT NULL,
	FOREIGN KEY (termYearID) REFERENCES TermYears(tYearID) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE ModuleLevelNames(
	mLevelID INT(2) PRIMARY KEY AUTO_INCREMENT,
	mLevel VARCHAR(20) NOT NULL UNIQUE
)ENGINE=INNODB;

CREATE TABLE Modules(
	mID INT(6) PRIMARY KEY AUTO_INCREMENT,
	mCode VARCHAR(20) NOT NULL,
	mName VARCHAR(150) NOT NULL,
	mTerm INT(6) NOT NULL,
	mNotes VARCHAR(250),
	dateAdded TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (mTerm) REFERENCES Terms(termID) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE(mCode,mTerm)
)ENGINE=INNODB;

CREATE TABLE ModuleLevels(
	mLevelID INT(7) PRIMARY KEY AUTO_INCREMENT,
	moduleID INT(6) NOT NULL,
	mLevel INT(2) NOT NULL,
	FOREIGN KEY (moduleID) REFERENCES Modules(mID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (mLevel) REFERENCES ModuleLevelNames(mLevelID) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE ModuleSkillsRequired (
	requiredID INT(6) PRIMARY KEY AUTO_INCREMENT,
	moduleID INT(6) NOT NULL,
	skillID INT(5) NOT NULL,
	dateAdded TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (moduleID) REFERENCES Modules(mID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (skillID) REFERENCES Skills(skillID) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE ModuleLecturers(
	mlecID INT(6) PRIMARY KEY AUTO_INCREMENT,
	lecturerID INT(6) NOT NULL,
	mID INT(6) NOT NULL,
	dateAdded TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (lecturerID) REFERENCES Lecturers(lecturerID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (mID) REFERENCES Modules(mID) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE (lecturerID, mID)
)ENGINE=INNODB;

CREATE TABLE Weekdays (
	dayID INT(1) PRIMARY KEY AUTO_INCREMENT,
	dayName VARCHAR(10) NOT NULL UNIQUE
)ENGINE=INNODB;

CREATE TABLE Timetable (
	ttID INT(10) PRIMARY KEY AUTO_INCREMENT,
	mID INT(6) NOT NULL,
	ttDay VARCHAR(10) NOT NULL,
	ttLocation VARCHAR(30) NOT NULL,
	ttStartTime TIME NOT NULL,
	ttEndTime TIME NOT NULL,
	ttNoHelpers INT(2),
	ttNotes VARCHAR(400),
	FOREIGN KEY (mID) REFERENCES Modules(mID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (ttDay) REFERENCES Weekdays(dayName) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE ModuleHelpers(
	mhelpID INT(6) PRIMARY KEY AUTO_INCREMENT,
	helperID INT(8) NOT NULL,
	ttID INT(6) NOT NULL,
	aproved ENUM('true','false') NOT NULL,
	dateAdded TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (helperID) REFERENCES Helpers(hID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (ttID) REFERENCES Timetable(ttID) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE (helperID, ttID)
)ENGINE=INNODB;


CREATE TABLE ModuleWeeks (
	wID INT(10) PRIMARY KEY AUTO_INCREMENT,
	ttID INT(6) NOT NULL,
	week INT(2) NOT NULL,
	FOREIGN KEY (ttID) REFERENCES Timetable(ttID) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE AllocateStatus (
	statusID INT(1) PRIMARY KEY AUTO_INCREMENT,
	statusName VARCHAR(20) NOT NULL
)ENGINE=INNODB;

CREATE TABLE AllocateHelpers (
	AllocateID INT(6) PRIMARY KEY AUTO_INCREMENT,
	ttID INT(10) NOT NULL,
	helperID INT(8) NOT NULL,
	suggested INT(1),
	helperChoice INT(1),
	statusID INT(1),
	FOREIGN KEY (ttID) REFERENCES Timetable(ttID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (helperID) REFERENCES Helpers(hID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (statusID) REFERENCES AllocateStatus(statusID) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE ReqTypes (
	reqTypeID INT(2) PRIMARY KEY AUTO_INCREMENT,
	reqTypeName VARCHAR(32) NOT NULL UNIQUE
)ENGINE=INNODB;

CREATE TABLE Requests (
	rID INT(6) PRIMARY KEY AUTO_INCREMENT,
	usrTo VARCHAR(32),
	usrFrom VARCHAR(32),
	reqDestType INT(2),
	ttID INT(6) NOT NULL,
	seen ENUM('true','false'),
	acknowledged ENUM('true','false'),
	FOREIGN KEY (usrTo) REFERENCES Users(usr) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (usrFrom) REFERENCES Users(usr) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (ttID) REFERENCES Timetable(ttID) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (reqDestType) REFERENCES ReqTypes(reqTypeID) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB;

CREATE TABLE News (
	newsID INT(6) PRIMARY KEY AUTO_INCREMENT,
	title VARCHAR(100) NOT NULL,
	content VARCHAR(750) NOT NULL,
	receiver ENUM('Helper','Lecturer','both') NOT NULL,
	dateAdded TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
)ENGINE=INNODB;



-- INSERTS ----------------------------------------

INSERT INTO SkillType (typeName) VALUES ('Language');
INSERT INTO SkillType (typeName) VALUES ('Concept');
INSERT INTO SkillType (typeName) VALUES ('Tool/Package');

INSERT INTO AccountTypes (accTypeName) VALUES ('Helper'),('Lecturer'),('Administrator');

INSERT INTO Skills (skillType, skillName) VALUES (1,'Java');
INSERT INTO Skills (skillType, skillName) VALUES (1,'SML');
INSERT INTO Skills (skillType, skillName) VALUES (1,'.NET');
INSERT INTO Skills (skillType, skillName) VALUES (1,'C++');
INSERT INTO Skills (skillType, skillName) VALUES (2,'Formal Specification');
INSERT INTO Skills (skillType, skillName) VALUES (2,'Z specification');
INSERT INTO Skills (skillType, skillName) VALUES (3,'Eclipse');
INSERT INTO Skills (skillType, skillName) VALUES (3,'Emacs');
INSERT INTO Skills (skillType, skillName) VALUES (3,'Photoshop');
INSERT INTO Skills (skillType, skillName) VALUES (3,'');

INSERT INTO CourseLevels (courseLevelType) VALUES ('BSc.');
INSERT INTO CourseLevels (courseLevelType) VALUES ('MSc.');
INSERT INTO CourseLevels (courseLevelType) VALUES ('MEng.');
INSERT INTO CourseLevels (courseLevelType) VALUES ('PhD.');
INSERT INTO CourseLevels (courseLevelType) VALUES ('Teaching Fellow');
INSERT INTO CourseLevels (courseLevelType) VALUES ('Teaching Assistant (Up to 10hrs)');
INSERT INTO CourseLevels (courseLevelType) VALUES ('PhD. & Teaching Assistant');
INSERT INTO CourseLevels (courseLevelType) VALUES ('RA');

INSERT INTO ModuleLevelNames (mLevel) VALUES ('1 UG');
INSERT INTO ModuleLevelNames (mLevel) VALUES ('2 UG');
INSERT INTO ModuleLevelNames (mLevel) VALUES ('3 UG');
INSERT INTO ModuleLevelNames (mlevel) VALUES ('4 UG');
INSERT INTO ModuleLevelNames (mLevel) VALUES ('MSc.');
INSERT INTO ModuleLevelNames (mlevel) VALUES ('PhD.');

INSERT INTO TermYears (tYearStart, tYearEnd) VALUES (2008,2009);
INSERT INTO TermYears (tYearStart, tYearEnd) VALUES (2009,2010);
INSERT INTO TermYears (tYearStart, tYearEnd) VALUES (2010,2011);
INSERT INTO TermYears (tYearStart, tYearEnd) VALUES (2011,2012);

INSERT INTO Terms (termYearID, term, helperRate) VALUES (1,1,5.50);
INSERT INTO Terms (termYearID, term, helperRate) VALUES (1,2,5.69);
INSERT INTO Terms (termYearID, term, helperRate) VALUES (2,1,5.87);
INSERT INTO Terms (termYearID, term, helperRate) VALUES (2,2,5.87);
INSERT INTO Terms (termYearID, term, helperRate) VALUES (3,1,6.12);
INSERT INTO Terms (termYearID, term, helperRate) VALUES (3,2,5.67);
INSERT INTO Terms (termYearID, term, helperRate) VALUES (4,1,6.45);
INSERT INTO Terms (termYearID, term, helperRate) VALUES (4,2,6.45);

INSERT INTO Weekdays (dayName) VALUES ('Monday');
INSERT INTO Weekdays (dayName) VALUES ('Tuesday');
INSERT INTO Weekdays (dayName) VALUES ('Wednesday');
INSERT INTO Weekdays (dayName) VALUES ('Thursday');
INSERT INTO Weekdays (dayName) VALUES ('Friday');
INSERT INTO Weekdays (dayName) VALUES ('Saturday');
INSERT INTO Weekdays (dayName) VALUES ('Sunday');

INSERT INTO AllocateStatus (statusName) VALUES ('Confirmed');
INSERT INTO AllocateStatus (statusName) VALUES ('Declined');

