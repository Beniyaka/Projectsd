$(window).load(function(){ 
	setTimeout(function() {
  	$("#middle").css("visibility","visible");
  	$("#loading").hide();
	},500);
});

