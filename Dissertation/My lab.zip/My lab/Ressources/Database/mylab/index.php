<?php
define('INCLUDE_CHECK',true);
require './connect.php';
require './functions.php';

// Starting the session
session_name('mylabLogin');
session_set_cookie_params(2*7*24*60*60);
// Making the cookie live for 2 weeks
session_start();

if(isset($_SESSION['usr']) && !isset($_COOKIE['mylabRemember']) && !isset($_SESSION['rememberMe']))
{
	// If you are logged in, but you don't have the mylabRemember cookie (browser restart)
	// and you have not checked the rememberMe checkbox:

	$_SESSION = array();
	session_destroy();
	
	// Destroy the session
}


if(isset($_GET['logoff']))
{
	$_SESSION = array();
	session_destroy();
	
	header("Location: ./");
	exit;
}

if($_POST['submit']=='Login')
{
	// Checking whether the Login form has been submitted
	
	$err = array();
	// Will hold our errors
	
	
	if(!$_POST['username'] || !$_POST['password'])
		$err[] = 'All the fields must be filled in!';
	
	if(!count($err))
	{
		$_POST['username'] = mysqli_real_escape_string($link, $_POST['username']);
		$_POST['password'] = mysqli_real_escape_string($link, $_POST['password']);
		$_POST['rememberMe'] = (int)$_POST['rememberMe'];
		
		// Escaping all input data

		$row = mysqli_fetch_assoc(mysqli_query($link, "SELECT usr, accType FROM Users WHERE usr='{$_POST['username']}' AND pswd='".md5($_POST['password'])."' AND approvedUser='true' AND activeUser='true'"));
		
		if(isset($row['usr']))
		{
			// If everything is OK login
			
			$_SESSION['usr']=$row['usr'];
			//$_SESSION['id'] = $row['id'];
			$_SESSION['rememberMe'] = $_POST['rememberMe'];
			$_SESSION['accType'] = $row['accType'];
			
			// Store some data in the session
			
			setcookie('mylabRemember',$_POST['rememberMe']);
		}
		else $err[]='Wrong username and/or password!';
	}
	
	if($err)
	$_SESSION['msg']['login-err'] = implode('<br />',$err);
	// Save the error messages in the session

	header("Location: ./");
	exit;
}
else if($_POST['submit']=='Register')
{
	// If the Register form has been submitted
	
	$err = array();
	
	if(strlen($_POST['username'])<4 || strlen($_POST['username'])>32)
	{
		$err[]='Your username must be between 3 and 32 characters!';
	}
	
	if(preg_match('/[^a-z0-9\-\_\.]+/i',$_POST['username']))
	{
		$err[]='Your username contains invalid characters!';
	}
	
	if(!checkEmail($_POST['email']))
	{
		$err[]='Your email is not valid!';
	}
	
	if(preg_match('/[^a-z0-9\.]+/i',$_POST['accountType'])){
		$err[]='Please select an account type!';
	}
	
	if(!count($err))
	{
		// If there are no errors
		
		$pass = substr(md5($_SERVER['REMOTE_ADDR'].microtime().rand(1,100000)),0,6);
		// Generate a random password
		
		$_POST['email'] = mysqli_real_escape_string($link, $_POST['email']);
		$_POST['username'] = mysqli_real_escape_string($link, $_POST['username']);
		// Escape the input data
		
		
		mysqli_query($link, "	INSERT INTO login_session(usr,pass,account_type,email,regIP,dt)
						VALUES(
						
							'".$_POST['username']."',
							'".md5($pass)."',
							'".$_POST['accountType']."',
							'".$_POST['email']."',
							'".$_SERVER['REMOTE_ADDR']."',
							NOW()
							
						)");
		
		if(mysqli_affected_rows($link)==1)
		{
			send_mail(	'registration@mylab.macs.hw.ac.uk',
						$_POST['email'],
						'MyLab Registration - Register Link',
						'Please follow the following link to complete your registration: 
'.$domain_name.'Registration/?pg=continueReg&session='.$pass.' press me!
If you are a helper you will be asked for a CV and a supporting statement as well as a new password for you account.');

			$_SESSION['msg']['reg-success']='We sent you an email with a link to continue your registration.';
		}
		else $err[]='This username and/or email address is already taken!';
	}

	if(count($err))
	{
		$_SESSION['msg']['reg-err'] = implode('<br />',$err);
	}	
	
	header("Location: ./");
	exit;
}

$script = '';

if(isset($_SESSION['msg']))
{
	// The script below shows the sliding panel on page load
	
	$script = '
	<script type="text/javascript">
	
		$(function(){
		
			$("div#panel").show();
			$("#toggle a").toggle();
		});
	
	</script>';
	
}

/*
if( !($_SESSION['usr'])){
	die('<meta HTTP-EQUIV="REFRESH" content="0; url='.$domain_name.'">');
}elseif(!($_SESSION['accType']=="Lecturer") && !($_SESSION['accType']=="Helper")){
	die(include('./Content/badPermission.php'));
}
*/
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <?php include("./baseInclude.php"); ?>
    
    <?php echo $script; ?>
	
	<?php //echo '<script type="text/javascript" >alert('.$_SESSION['accType'].');</script>'; ?>
	<?php
		if($_SESSION['accType']=='Helper') { 
			$sql = mysqli_query($link, "SELECT COUNT(rID) as seen FROM Requests WHERE usrTo='".$_SESSION['usr']."' AND acknowledged IS NULL LIMIT 1") or die(mysqli_error($link));
			$sql2 = mysqli_query($link, "SELECT COUNT(rID) as seen FROM Requests WHERE usrFrom='".$_SESSION['usr']."' AND acknowledged IS NOT NULL AND seen='false' LIMIT 1") or die(mysqli_error($link));
			$sql3 = mysqli_query($link, "SELECT COUNT(M.mID) AS counted
										FROM Helpers H, Modules M, Terms T 
										WHERE T.termID=M.mTerm AND T.termID=(SELECT MAX(TT.termID) FROM Terms TT) AND
										H.usr NOT IN (SELECT R.usrFrom FROM Requests R, Timetable T WHERE R.ttID=T.ttID AND T.mID=M.mID AND H.usr=R.usrFrom) 
											AND H.usr NOT IN (SELECT R.usrTo FROM Requests R, Timetable T WHERE R.ttID=T.ttID AND T.mID=M.mID AND H.usr=R.usrTo) 
											AND H.usr NOT IN (SELECT HH.usr FROM ModuleHelpers HM, Helpers HH, Timetable TT WHERE HM.ttID=TT.ttID AND TT.mID=M.mID AND H.hID=HM.helperID AND HH.hID=HM.helperID) 
											AND H.usr='".$_SESSION['usr']."' 
											AND (((SELECT COUNT(HS.skillID) FROM HelperSkills HS, ModuleSkillsRequired S
												  WHERE HS.helperID=H.hID AND HS.skillID = S.skillID AND S.moduleID=M.mID )
												  /
												  (SELECT COUNT(*) FROM ModuleSkillsRequired S WHERE S.moduleID=M.mID )
												  )*100)>=50
										ORDER BY (SELECT COUNT(*) FROM HelperSkills HS, ModuleSkillsRequired S 
												WHERE HS.helperID=H.hID AND HS.skillID = S.skillID AND S.moduleID=M.mID) DESC") or die(mysqli_error($link));
		
		
		}elseif($_SESSION['accType']=='Lecturer') {
			//$sql = mysqli_query($link, "SELECT COUNT(seen) as seen FROM Requests WHERE usrTo='".$_SESSION['usr']."' AND acknowledged='false' LIMIT 1") or die(mysqli_error($link));
				$sql = mysqli_query($link, "SELECT COUNT(R.rID) as seen 
														FROM Requests R, Modules M, ModuleLecturers ML, Lecturers L, Timetable T 
														WHERE R.ttID=T.ttID AND T.mID=M.mID AND ML.lecturerID=L.lecturerID AND ML.mID=T.mID AND T.ttID=R.ttID AND L.usr='".$_SESSION['usr']."' AND R.acknowledged IS NULL AND R.usrTo IS NULL") 
														or die(mysqli_error($link));
				$sql2 = mysqli_query($link, "SELECT COUNT(R.rID) as seen 
														FROM Requests R, Modules M, ModuleLecturers ML, Lecturers L, Timetable T 
														WHERE R.ttID=T.ttID AND T.mID=M.mID AND ML.lecturerID=L.lecturerID AND ML.mID=T.mID AND T.ttID=R.ttID AND L.usr='".$_SESSION['usr']."' AND R.acknowledged IS NOT NULL AND R.seen='false' AND R.usrTo IS NOT NULL") 
														or die(mysqli_error($link));
				$sql3=0;
		}elseif($_SESSION['accType']=='Administrator'){
			$sql=mysqli_query($link, "SELECT COUNT(*) AS seen FROM Users WHERE approvedUser='false'") or die(mysqli_error($link));
			$sql2=0;
			$sql3=0;
		}
		if($_SESSION['accType']){
			$row=mysqli_fetch_assoc($sql);
			$row2=($sql2!=0)?mysqli_fetch_assoc($sql2):0;
			$row3 = ($sql3!=0)?mysqli_fetch_assoc($sql3):0;
			$msgCount = 0 + $row['seen'] + $row2['seen']+(($row3!=0)?$row3['counted']:0);
			echo '<script>
		$(function() {
			$("#circle").hide();
			$("#circle").html('.$msgCount.');
			if('.$msgCount.'>0){
				$("#circle").show();
			}
		});
		</script>';
		
		}
		
	echo '<script type="text/javascript" >$(window).load(function(){ 
	setTimeout(function() {
  	$("#middle").css("visibility","visible");
  	$("#loading").hide();
	},500);
});</script>';
	?>

<script type="text/javascript" >
$(function() {
	$(".tabs a:last-child").css("border-radius","0px 6px 6px 0px");
	$(".tabs a:first-child").css("border-radius"," 6px 0px 0px 6px");
	$( "a", ".tabs" ).button();
});
</script>

</head>

<body>




<!-- Panel -->
<div id="toppanel" class="noPrint">
	<div id="panel">
		<div class="content clearfix">
			<div class="left">
				<h1>MyLab Helper Allocation System</h1>
				<h2>Register or login from here</h2>		
				<p class="grey">Great amazing text that is so useful and riveting to the senses</p>
				<h2>More useful info here.</h2>
				<p class="grey">This website is being build by <a href="http://drewboswell.net/" >Andrew Boswell</a>, yes, I know, I'm amazing.</p>
			</div>
            
            
            <?php
			
			if(!$_SESSION['usr']):
			
			?>
            
			<div class="left">
				<!-- Login Form -->
				<form class="clearfix" action="" method="post">
					<h1>Member Login</h1>
                    
                    <?php
						
						if($_SESSION['msg']['login-err'])
						{
							echo '<div class="err">'.$_SESSION['msg']['login-err'].'</div>';
							unset($_SESSION['msg']['login-err']);
						}
					?>
					
					<label class="grey" for="username">Username:</label>
					<input class="field" type="text" name="username" id="username" value="" size="23" />
					<label class="grey" for="password">Password:</label>
					<input class="field" type="password" name="password" id="password" size="23" />
	            	<label><input name="rememberMe" id="rememberMe" type="checkbox" checked="checked" value="1" /> &nbsp;Remember me</label>
        			<div class="clear"></div>
					<input type="submit" name="submit" value="Login" class="bt_login" />
				</form>
			</div>
			<div class="left right">			
				<!-- Register Form -->
				<form action="" method="post">
					<h1>Not a member yet? Sign Up!</h1>		
                    
                    <?php
						
						if($_SESSION['msg']['reg-err'])
						{
							echo '<div class="err">'.$_SESSION['msg']['reg-err'].'</div>';
							unset($_SESSION['msg']['reg-err']);
						}
						
						if($_SESSION['msg']['reg-success'])
						{
							echo '<div class="success">'.$_SESSION['msg']['reg-success'].'</div>';
							unset($_SESSION['msg']['reg-success']);
						}
					?>
               
               <select name="accountType" size="0" class="field">
						<option value="--Account Type--">-- Account Type --</option>
						<option value="Helper">Helper</option>
 	 					<option value="Lecturer">Lecturer</option>
					</select><br />
					
					<label class="grey" for="username">Username:</label>
					<input class="field" type="text" name="username" id="username" value="" size="23" />
					<label class="grey" for="email">Email:</label>
					<input class="field" type="text" name="email" id="email" size="23" />
					<label>A password will be e-mailed to you.</label>
					<input type="submit" name="submit" value="Register" class="bt_register" />
				</form>
			</div>
            
            <?php
			
			else:
			
			?>
            
            <div class="left">
            
            <h1>Members panel</h1>
            
            <p>You can put member-only data here</p>
            <a href="./Content/registered.php">View a special member page</a>
            <p>- or -</p>
            <a href="?logoff">Log off</a>
            
            </div>
            
            <div class="left right">
            </div>
            
            <?php
			endif;
			?>
		</div>
	</div> <!-- /login -->	

    <!-- The tab on top -->	
	<div class="tab">
		<ul class="login">
	    	<li class="left">&nbsp;</li>
	        <li>Hello <?php echo $_SESSION['usr'] ? $_SESSION['usr'] : 'Not signed in';?>!</li>
			<li class="sep">|</li>
			<li id="toggle">
				<a id="open" class="open" href="#"><?php echo $_SESSION['usr']?'Open Panel':'Log In | Register';?></a>
				<a id="close" class="close" style="display: none;" class="close" href="#">Close Panel</a>			
			</li>
	    	<li class="right">&nbsp;</li>
		</ul> 
	</div> <!-- / top -->
	
</div> <!--panel -->






<div id="main">
  	<div class="container noPrint">
  		<div class="tabs">
  		<?php
  		
  		if($_SESSION['usr']){
  			if($_SESSION['accType']=='Lecturer') { $yes=0; }
  			elseif($_SESSION['accType']=='Helper') { $yes=1; }
  			elseif($_SESSION['accType']=='Administrator'){ $yes=2; }
  			if($yes!=2) echo '<a href="./?pg=home" id="home"><div>H</div></a>';
  			if($yes==2) echo '<a href="./?pg=settings"  id="settings"><div>S</div></a>';
	  		if($yes!=2) echo '<a href="./?pg=myModules" >My Modules</a>';
			if($yes==0) echo '<a href="./?pg=addModuleForm"> New Module </a>';
			if($yes!=2) echo '<a href="./?pg=viewModuleForm" >All Modules</a>';
			if($yes==0) echo '<a href="./?pg=findHelpersForm" >Find Helpers</a>';
			if($yes==2) echo '<a href="./?pg=adminUsers" >Users</a>';
			if($yes==2) echo '<a href="./?pg=adminModules" >Modules</a>';
			if($yes==2) echo '<a href="./?pg=adminReports" >Reports</a>';
			echo '<a href="./?pg=viewRequests"  id="msgs"><div>M</div><span id="circle"></span> </a>';
			if($yes!=2) echo '<a href="./?pg=settings"  id="settings"><div>S</div></a>';
		}else{
			echo '<h1>MACS Lab Helper Allocation System</h1>
        <h2>Easy registration and management of Lecturer and Helper activities.</h2>';
		} 
			
		?>
		</div>
	</div>
    
	<div class="container">
		<div id="loading">
			<img src="./Ressources/IMG/load-circle.gif" alt="loading.." /> <br>
			Loading, please wait.. <br>
		</div> 
		<div id="middle" style="visibility:hidden;">
			<?php 
			if($_SESSION['usr']){
				if(isset($_GET['pg']) && $_GET['pg'] != "") {
   				$pg = $_GET['pg'];
    				if (file_exists('./Content/'.$pg.'.php')) {
    					include ('./Content/'.$pg.'.php');
    				}else
						include ('./Content/404.php');
				}
				else{
					if($yes!=2) include('./Content/home.php');
					else if($yes==2) include('./Content/settings.php');
				}
			}else {
				include('./Content/frontPage.php');
			}
			?>
		</div>
    </div>
    
	<div class="container tutorial-info noPrint">
  		This website was developed by <a href="http://drewboswell.net/" style="text-decoration:none;"><span style="font-style:italic; font: 16px/1 Lobster,Arial,sans-serif;"> Andrew Boswell </span>.</a>
 	</div>
</div>

</body>
</html>

