<?php 

if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');

$lLoginSession =  mysqli_real_escape_string($link, md5($_GET['session']));
$sqlLoginSession = mysqli_query($link, "SELECT id,usr,account_type,email FROM login_session WHERE pass='".$lLoginSession."'");

$row = mysqli_fetch_assoc($sqlLoginSession);

		if($row['usr'])
		{
			// If everything is OK login
			
			echo "Username: ".$row['usr']."<br>";
			echo "Account Type: ".$row['account_type']."<br>";
			echo "You are user #".$row['id']." to use this service.<br><br>";
		}
		else { echo "no work lol -- <meta http-equiv=\"Refresh\" content=\"3;url=../\" />"; }
			
?>

<?php
	if($row['account_type']=='Lecturer'){
		include("./confirmLecturerForm.php");
	} elseif($row['account_type']=='Helper') {
		include("./confirmHelperForm.php");
	} else {
		echo "Your link has either expired or incomplete information was given<br> please try registering again";
	}
?>