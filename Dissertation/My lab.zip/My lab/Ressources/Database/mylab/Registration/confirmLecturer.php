<?php 

define('INCLUDE_CHECK',true);

require '../connect.php';
require '../functions.php';

$sqlUsers = mysqli_prepare($link, "INSERT INTO Users(usr,pswd,email,accType,approvedUser) VALUES(?,?,?,?,?)");
mysqli_stmt_bind_param($sqlUsers, 'sssss', $lUsername, md5($_POST['password']), $_POST['email'], $_POST['accType'], 'false');
$lUsername = mysqli_real_escape_string($link, $_POST['username']);


$sqlLecturers = mysqli_prepare($link, "INSERT INTO Lecturers(usr, lFirstName ,lSurname, lPhone) VALUES (?,?,?,?)");
mysqli_stmt_bind_param($sqlLecturers, 'sssd', $lUsername, $_POST['firstName'], $_POST['lastName'], $_POST['internalPhone']);

$sqlDeleteSession = mysqli_prepare($link, "DELETE FROM login_session WHERE usr = ? ");
mysqli_stmt_bind_param($sqlDeleteSession, 's', $lUsername);


if(mysqli_stmt_execute($sqlUsers)){
	if(mysqli_stmt_execute($sqlLecturers)){
			mysqli_stmt_execute($sqlDeleteSession) or die(mysqli_error());
			
			$msgSender = 'no-reply@mylab.macs.hw.ac.uk';
			$msgReceiver = $_POST['email'];
			$msgSubject = 'MyLab Registration done - info';
			$msgBody = 'MyLab Registration done - info'.
			'Your registration has been successful, Please keep your password safe.
User Name: '.$_POST['username'].'
password chosen: '.$_POST['password'].'
An email will be sent to you once an Administrator has aproved you as a user.
Thank you for using MyLab! 
';
			if(send_mail($msgSender,$msgReceiver,$msgSubject,$msgBody)){
				echo "Registration complete! An email has been sent with your user name and password for safe keeping";	
			}
	}
}


?>