<?php
define('INCLUDE_CHECK',true);
require '../connect.php';
require '../functions.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <?php include("baseInclude.php"); ?>
    <link rel="stylesheet" type="text/css" href="../Ressources/CSS/main.css" media="screen" />
    
    <style type="text/css">
	
		html { font-size: 1em; }
		label { font-size: 1em; font-weight: bold; }
		form { width: 420px; }
		#submit { font-size:1em; padding: 5px 20px; }
	
		.error { color: red; }
		.module { border: 3px inset #F6F6F6; background: #F6F6F6; border-radius: 4px; padding: 10px; }
		
		#confirmLecturerMain { width: 200px; }
		
	</style>
    
</head>

<body>

<div id="main">
  <div class="container">
    <h1>Registering Users Only!</h1>
    <h2>This page is for people signing up to MyLab</h2>
    </div>
    
    <div class="container">
    
<?php 
					if(isset($_GET['pg']) && isset($_GET['session']) && $_GET['pg'] != "" && $_GET['session'] != "") {
   					$pg = $_GET['pg'];
    					if (file_exists('./'.$pg.'.php')) {
    						@include ('./'.$pg.'.php');
    					}else
						@include ('../Content/404.inc');
					}
					else
						@include ('../index.php');
?>

    </div>
    
  <div class="container tutorial-info">
  This website was developped by <a href="http://drewboswell.net/" style="text-decoration:none;"><span style="font-style:italic; font: 16px/1 Lobster,Arial,sans-serif;"> Andrew Boswell </span>.</a>
 </div>


</body>
</html>
