<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>jQuery File Upload Example</title>
</head>
<body>
<input id="fileupload" type="file" name="files[]" multiple>
<script type='text/javascript' src='./Ressources/JS/jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='./Ressources/JS/jquery-ui-1.8.17.custom.min.js'></script>
   <script src="./Ressources/JS/Uploader/jquery.iframe-transport.js"></script>
	<script src="./Ressources/JS/Uploader/jquery.fileupload.js"></script>
<script>
$(function () {
    $('#fileupload').fileupload({
        dataType: 'json',
        url: 'userUploadedFiles/cvs/index.php',
        done: function (e, data) {
            $.each(data.result, function (index, file) {
                $('<p/>').text(file.name).appendTo(document.body);
            });
        }
    });
});
</script>
</body> 
</html>

