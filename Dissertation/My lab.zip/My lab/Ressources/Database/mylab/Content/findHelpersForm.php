<?php 
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<title>Find Helpers for Modules - MyLab Helper Allocation</title>

<style type="text/css">
	#mainBit { min-height: 400px; }
	#selectable .ui-selecting { background: #FECA40; }
	#selectable .ui-selected { background: #F39814; color: white; }
	#selectable { list-style-type: none; margin: 0; padding: 0; width: 100%; position: relative; }
	#selectable li { margin: 3px; padding: 0.4em; width: 90px; display: inline-block; text-align: center; }
	
	#selectable2 .ui-selecting { background: #FECA40; }
	#selectable2 .ui-selected { background: #F39814; color: white; }
	#selectable2 { list-style-type: none; margin: 0; padding: 0; width: 100%; position: relative; }
	#selectable2 li { margin: 3px; padding: 0.4em; display: block; text-align: center; }
	
</style>

<script type="text/javascript" >

	$(".selectable").live("click",function(){
		 if ($(this).hasClass('ui-selected')) {
			$(this).removeClass('ui-selected');
    	} else {
      	$(this).addClass('ui-selected');
    	}
	});
	
	/** CHOOSE MODULE  */
	$("#chooseHelpers, #chooseModuleTimes, #moduleChosen").hide();
	
	$(".modulePick").live("click",function(){
		$("#moduleChosen").html($(this).attr("id"));
		$.post('./Content/getModuleTimes.php', { "mID": $(this).attr("id") }, function(data){
			$("#chooseModuleTimes").html(data);
			$("#chooseModule").hide("slide", { direction: "left" }, 500);
			$("#chooseModuleTimes").delay(500).show("slide", { direction: "right" }, 1000);
		});
		/*
		$.post('./Content/getAvailableHelpers.php', { "chosenModule": $(this).attr("id") }, function(data){
			$("#chooseHelpers").html(data);
			$("#chooseModule").hide("slide", { direction: "left" }, 500);
			$("#chooseHelpers").delay(500).show("slide", { direction: "right" }, 1000);
		});
		*/
	});
	/** END CHOOSE MODULE  */
	
	/** GET MODULE TIMES  */
	$("#back").live("click",function(){
		$("#chooseModuleTimes").hide("slide", { direction: "right" }, 500);
		$("#chooseModule").delay(500).show("slide", { direction: "left" }, 1000);
	});
	
	$(".chooseTime").live("click",function(){
		$("#ttChosen").html($(this).attr("id"));
		$.post('./Content/getAvailableHelpers.php', { "chosenModule": $('#moduleChosen').html(), "ttID":this.id }, function(data){
			$("#chooseHelpers").html(data);
			$("#chooseModuleTimes").hide("slide", { direction: "left" }, 500);
			$("#chooseHelpers").delay(500).show("slide", { direction: "right" }, 1000);
		});
	});
	/** END GET MODULE TIMES  */
	
	/** GET AVAILABLE HELPERS  */
	$("#backH").live("click",function(){
		$("#chooseHelpers").hide("slide", { direction: "right" }, 500);
		$("#chooseModule").delay(500).show("slide", { direction: "left" }, 1000);
	});
	
	$("#invite").live("click",function(){
		var usrArray = new Array();
		var xx = 0;
		$(".ui-selected").each(function(){
			usrArray[xx]=$(this).attr("id");
			xx++;
		});
		$.post('./Content/findHelpers.php', { 'ttID': $("#ttChosen").html(), 'usr[]': usrArray }, function(data){
			if(data==""){
				window.location.href = "./index.php";
			}
		});
	});
	/** END GET AVAILABLE HELPERS  */
</script>

	<div id="mainBit">

	<div id="chooseModule">
	<h1>Which Module do you want to find Helpers for?</h1>
	<br><br>	
	
	<br>
	<?php
	
	$tableS=", Terms TE "; 
	$specify = "AND M.mTerm=TE.termID AND TE.termID=(SELECT MAX(TEE.termID) FROM Terms TEE)";
	
	if($_SESSION['accType']=="Lecturer"){
		$sqlMyModules = mysqli_query($link, "SELECT M.mCode, M.mName, L.mID FROM ModuleLecturers L, Modules M $tableS WHERE (M.mID=L.mID AND L.lecturerID=(SELECT Z.lecturerID FROM Lecturers Z WHERE Z.usr='".$_SESSION['usr']."')) $specify") or die(mysqli_error($link));
	}elseif($_SESSION['accType']=="Helper"){
		$sqlMyModules = mysqli_query($link, "SELECT M.mID, M.mCode, M.mName, H.mID FROM ModuleHelpers H, Modules M $tableS WHERE (M.mID=L.mID AND H.lecturerID=(SELECT Z.hID FROM Helpers Z WHERE Z.usr='".$_SESSION['usr']."')) $specify") or die(mysqli_error($link));
	}	
	$_POST['conn'] = "../connect.php";
	if(mysqli_affected_rows($link)>0){
		while($row1=mysqli_fetch_array($sqlMyModules)){
			echo '<button type="button" class="modulePick" id="'.$row1['mID'].'"><h2>'.$row1['mCode'].' - '.$row1['mName'].'</h2></button><br>';
		}
	}else {
		echo '</div><div>None. Try adding a module using the <a href="./?pg=viewModuleForm">search page</a>.';
	}
	?>	
	</div>
	<div id="moduleChosen" style="display:none;"></div>
	<div id="ttChosen" style="display:none;"></div>
	<div id="chooseModuleTimes" style="display:none;"></div>
	<div id="chooseHelpers" style="display:none;"></div>
	
	</div>
