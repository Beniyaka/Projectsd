<?php
define('INCLUDE_CHECK',true);
require '../connect.php';
require '../functions.php';

session_name('mylabLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();

$answer = mysqli_real_escape_string($link, trim($_POST['answer']));

if($_SESSION['accType']=='Administrator'){
	if($answer=='true'){
		$sqlApproveUser = mysqli_query($link, "UPDATE Users SET approvedUser='".$answer."' WHERE usr='".$_POST['usr']."'") or die(mysqli_error($link));
	}else{
			$sqlApproveUser = mysqli_query($link, "DELETE FROM Users WHERE usr='".$_POST['usr']."'") or die(mysqli_error($link));
			if(!send_mail(	'no-reply@mylab.macs.hw.ac.uk',
						trim($_POST['email']),
						'MyLab Registration Rejected',
						'An administrator has rejected your application to use the MyLab system, please try again or contact the appropriate party.')){
			 echo "AAAAHH NO WORKY. MACS SERVER FAIL! LOLOLOOO";
			}
	}
}

?>