<?php
		if(!isset($_POST['usr'])){
			$_POST['usr']=$_SESSION['usr'];
			$_POST['accType']=$_SESSION['accType'];
		}
		
		if($_POST['accType']=='Lecturer'){
			$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y, Lecturers L, ModuleLecturers ML, Modules M WHERE T.termYearID=Y.tYearID AND L.usr='".$_POST['usr']."' AND ML.lecturerID=L.lecturerID AND ML.mID=M.mID AND M.mTerm=T.termID GROUP BY T.termID ORDER BY T.termID DESC");
		}elseif($_POST['accType']=='Helper'){
			$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y, Helpers H, ModuleHelpers MH, Modules M WHERE T.termYearID=Y.tYearID  AND H.usr='".$_POST['usr']."' AND MH.helperID=H.hID AND MH.mID=M.mID AND M.mTerm=T.termID GROUP BY T.termID ORDER BY T.termID DESC");
		}
		
		while($row=mysqli_fetch_assoc($sqlTerms)){
			if(!isset($first)) {
				$first = $row['termID'];
				$termName = $row['tYearStart']."-".$row['tYearEnd'].": Semester ".$row['term'];
			}
		}
	?>
	
<?php
	echo '<div class="userMod">'.$_POST['lastName'].', '.$_POST['firstName'].'<span class="email" >'.$_POST['email'].'</span></div><br><br>';
	$specify = "";
	$tableS = "";

	if(isset($_GET['years']) && $_GET['years']!="all"){ 
		$tableS=", Terms TE "; 
		$specify = "AND M.mTerm=TE.termID AND TE.termID=".$_GET['years'];
	}else{
		$tableS=", Terms TE "; 
		$specify = "AND M.mTerm=TE.termID AND TE.termID=".$first;
	}

	if($_POST['accType']=='Lecturer'){
	$sqlCheckRequests = mysqli_query($link, 'SELECT M.mID, M.mName, M.mCode, (SELECT TIME_FORMAT(T.ttStartTime, \'%H:%i\')) AS ttStartTime, 
		(SELECT TIME_FORMAT(T.ttEndTime, \'%H:%i\')) AS ttEndTime, T.ttLocation, T.ttDay, (SELECT GROUP_CONCAT(DISTINCT MW.week ORDER BY MW.week ASC SEPARATOR \',\') FROM ModuleWeeks MW WHERE MW.ttID=T.ttID AND T.mID=M.mID) AS ttweeks 
		FROM Modules M, ModuleLecturers ML, Timetable T, Lecturers L, Weekdays W '.$tableS.'
		WHERE W.dayName=T.ttDay AND T.mID=M.mID AND M.mID=ML.mID AND L.lecturerID=ML.lecturerID AND L.usr=\''.$_POST['usr'].'\' '.$specify.' 
		ORDER BY W.dayID, T.ttStartTime') or die(mysqli_error($link));
	}elseif($_POST['accType']=='Helper'){
		$sqlCheckRequests = mysqli_query($link, 'SELECT M.mID, M.mName, M.mCode, (SELECT TIME_FORMAT(T.ttStartTime, \'%H:%i\')) AS ttStartTime, 
		(SELECT TIME_FORMAT(T.ttEndTime, \'%H:%i\')) AS ttEndTime, T.ttLocation, T.ttDay, (SELECT GROUP_CONCAT(DISTINCT MW.week ORDER BY MW.week ASC SEPARATOR \',\') FROM ModuleWeeks MW WHERE MW.ttID=T.ttID AND T.mID=M.mID) AS ttweeks 
		FROM Modules M, ModuleHelpers MH, Timetable T, Helpers H, Weekdays W '.$tableS.' 
		WHERE W.dayName=T.ttDay AND T.mID=M.mID AND M.mID=MH.mID AND H.hID=MH.helperID AND H.usr=\''.$_POST['usr'].'\' AND MH.aproved=\'true\' '.$specify.' 
		ORDER BY W.dayID, T.ttStartTime') or die(mysqli_error($link));
	}
	
	$xx=0;

	echo '<table>';
	if(mysqli_affected_rows($link)>0){echo '<tr><th>Day</th><th>Module</th><th>Time</th><th>Room</th><th>Weeks</th></tr>';}
	
	$day = '';
	$name= '';
	$names=array();
	$code=array();
	$colorClass='';
	
	while($row=mysqli_fetch_assoc($sqlCheckRequests)){
		if($day!=$row['ttDay']){ 
			if($xx>0){ echo ''; }
			$day = $row['ttDay'];
			$colorClass=($colorClass=="even")?"odd":"even";
		}else {$day=""; }
		$name=$row['mName']; 
		
		$currCode='';
		$codeArray = explode(" ", $row['mName']);
		for($z=0; $z<sizeof($codeArray); $z++){ 
			$currCode .= substr($codeArray[$z],0,1); 
		}
		
		if(!in_array($name, $names)){ 
			$code []= $currCode;
			$names[]=$name;
		}
		
		// Work out weeks and concatenate
		$weeks=explode(",",$row['ttweeks']);
		$last=0; $lastChar="";
		for($w=0;$w<sizeof($weeks);$w++){
			if($w==0) {$row['ttweeks']=$weeks[$w];}
			else{
				$lastChar=$row['ttweeks'][strlen ($row['ttweeks'])-1];
				$row['ttweeks'].=($weeks[$w]-$last!=1)?(($lastChar=='-')?$last:'').','.(($w==sizeof($weeks)-1)?'':$weeks[$w]):(($lastChar=='-')?'':'-');
				$lastChar=substr($row['ttweeks'],sizeof($row['ttweeks']),1);
				if($w==sizeof($weeks)-1){
					$row['ttweeks'].=(($lastChar=='-')?''.$weeks[$w]:'');
				}
			}
			$last=$weeks[$w];
		}
		
		if($xx>0){ $sqlUpdateRequests.=" OR ";}
		echo '<tr id="'.$row['mCode'].'" class="'.$colorClass.'" ><td><img src="../Ressources/IMG/Print/eeeeee.png"/>'.$day.'</td><td><img src="../Ressources/IMG/Print/eeeeee.png"/>'.$currCode.'</td><td><img src="../Ressources/IMG/Print/eeeeee.png"/>'.$row['ttStartTime']."-".$row['ttEndTime'].'</td><td><img src="../Ressources/IMG/Print/eeeeee.png"/>'.$row['ttLocation'].'</td><td style="white-space:nowrap;"><img src="../Ressources/IMG/Print/eeeeee.png"/>'.$row['ttweeks'].',.</td></tr>';
		$xx++;
	}
	echo '</table>';
	for($xxx=0; $xxx<sizeof($names); $xxx++){
		echo '<br>'.$code[$xxx].' = '.$names[$xxx];
	}
	
	unset($weeks);
	unset($code);
	unset($names);
	unset($colorClass);
	unset($day);
	unset($name);
	
	if($xx==0){ echo "<h3>No timetable info</h3>"; }
?>