<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>MyLab Settings</title>

<style type="text/css">
	#settingsMenu button { height: 120px; width: 120px; font-size: 1.2em; margin: 10px; float: left; text-align: center; behavior: url(Ressources/PIE/PIE.php); }
	button img { height: 55px; width: auto; }
	
</style>

<script>
	$(function() {
		$( "button", "#settingsMenu" ).button();
		$( "button", "#settingsMenu" ).click(function() { 
			$("#settingsMenu").hide("slide", { direction: "left" }, 500);
			$("#"+$(this).attr("class").split(" ")[0]).delay(500).show("slide", { direction: "right" }, 1000);
		});
	});
</script>

</head>
<body>

<div id="settingsMenu">
	<?php 
		/* (1)EDIT PASSWORD - (2)EDIT DETAILS - (3)DISABLE ACCOUNT */
		/*1*/ if($yes==2) echo '<button type="button" class="addNews ui-widget-content"><img src="./Ressources/IMG/news.png" />Edit News</button> ';
		/*2*/ echo '<button type="button" class="changePassword ui-widget-content"><img src="./Ressources/IMG/password.png" />Change Password</button> ';
		/*3*/ if($yes!=2) echo '<button type="button" class="editDetails ui-widget-content"><img src="./Ressources/IMG/pen.png" />Edit Details</button> ';
		/*4*/ if($yes!=2) echo '<button type="button" class="disableAccount ui-widget-content"><img src="./Ressources/IMG/skull.and.crossbones.png" />Disable Account</button> ';

		/*6*/ if($yes==2) echo '<button type="button" class="backupData ui-widget-content"><img src="./Ressources/IMG/backup.png" />Back-up Database</button> ';
		/*7*/ if($yes==2) echo '<button type="button" class="restoreData ui-widget-content"><img src="./Ressources/IMG/restore.png" />Restore Database</button> ';
		/*8*/ if($yes==2) echo '<button type="button" class="editRates ui-widget-content"><img src="./Ressources/IMG/currency_black_pound.png" />Edit Rates</button> ';
		/*9*/ if($yes==2) echo '<button type="button" class="editSemester ui-widget-content"><img src="./Ressources/IMG/add.png" />Add Semester</button> ';
	?>
	<div style="clear: both;"></div>
</div>

<div id="addNews" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/newsForm.php'); ?></div>
<div id="changePassword" class="chosenSetting" style="display: none;"><?php include('./Content/settingsChangePasswordForm.php'); ?></div>
<div id="editDetails" class="chosenSetting" style="display: none;"><?php if($yes!=2) include('./Content/settingsChangeDetailsForm.php'); ?></div>
<div id="disableAccount" class="chosenSetting" style="display: none;"><?php if($yes!=2) include('./Content/settingsDisableAccountForm.php'); ?></div>
<div id="permittedEmails" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsPermittedEmailsForm.php'); ?></div>
<div id="backupData" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsBackupForm.php'); ?></div>
<div id="restoreData" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsRestoreForm.php'); ?></div>
<div id="editRates" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsEditRatesForm.php'); ?></div>
<div id="editSemester" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./Content/settingsEditSemesterForm.php'); ?></div>

</body>
</html>