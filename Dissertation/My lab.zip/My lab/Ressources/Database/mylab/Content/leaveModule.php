<?php

session_name('mylabLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();

define('INCLUDE_CHECK',true);

require '../connect.php';

if($_SESSION['accType']=="Lecturer"){
	$sqlLeaveModule = "DELETE FROM ModuleLecturers WHERE (lecturerID=(SELECT lecturerID FROM Lecturers WHERE usr='".$_SESSION['usr']."')) AND (mID=".$_POST['moduleID'].")";
}elseif($_SESSION['accType']=="Helper"){
	$sqlLeaveModule = "DELETE FROM ModuleHelpers WHERE (helperID=(SELECT hID FROM Helpers WHERE usr='".$_SESSION['usr']."')) AND (ttID=".$_POST['ttID'].")";
}
mysqli_query($link, $sqlLeaveModule) or die("Error: ".mysqli_error($link));

echo '<span class="success">You have successfully left the module.</span>';
?>