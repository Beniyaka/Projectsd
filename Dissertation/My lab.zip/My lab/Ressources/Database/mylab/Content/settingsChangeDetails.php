<?php
	// Starting the session
	session_name('mylabLogin');
	session_start();

	define('INCLUDE_CHECK',true);
	require('../connect.php');
	
	if($_SESSION['accType']=="Helper"){
		mysqli_query($link, "UPDATE Helpers SET hFirstName='".$_POST['firstName']."', hSurname='".$_POST['lastName']."', hPhone='".$_POST['phone']."' WHERE usr='".$_SESSION['usr']."'") or die(mysqli_error($link));
	}elseif($_SESSION['accType']=="Lecturer"){
		mysqli_query($link, "UPDATE Lecturers SET lFirstName='".$_POST['firstName']."', lSurname='".$_POST['lastName']."', lPhone='".$_POST['phone']."' WHERE usr='".$_SESSION['usr']."'") or die(mysqli_error($link));
	}

if(mysqli_affected_rows($link)==1){
	echo '<span class="success">You have successfully changed your Details.</span>
			<meta HTTP-EQUIV="REFRESH" content="3; url=./?pg=settings"/>';
}else{
	echo '<span class="error">Details change failed, please try again.</span>';
}


?>