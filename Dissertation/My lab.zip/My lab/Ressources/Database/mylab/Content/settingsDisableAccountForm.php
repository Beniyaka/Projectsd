<?php
	if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>
<title>Disable Account - MyLab Helper Allocation</title>

<style type="text/css">
	#disable button { height: 120px; font-size: 1.2em; margin: 10px; text-align: center; display: block; width: 98%; }
</style>

<script type="text/javascript" >
		
		$( "button", "#disable" ).button();
		$( "#disableForm" ).submit(function(event) { 
			event.preventDefault();
			if(confirm('Are you really sure?')){
				$.post("./Content/settingsDisableAccount.php", $("#disableForm").serialize() , function(data){
					if(data=="" || data==null){ $("#disableResponse").removeClass("err").addClass("success").html("your account has been disable, once you log out that's it!"+'<meta HTTP-EQUIV="REFRESH" content="2; url=./?pg=settings"/>');
					}else 
					$("#disableResponse").removeClass("success").addClass("err").html(data);
				});
			}else alert('A wise decision!')
			return false;
		});

</script>

<div id="disable">
	<h1> Be extremely sure about this, once you disable there is probably no going back! </h1><br>
	<span id="disableResponse"></span><br>
	<form action="/" id="disableForm" >
		<?php echo '<input type="hidden" value="'.$_SESSION['usr'].'" name="usr" />'; ?>
		<input type="hidden" name="killConf" value="true" />
		
		<button id="disableIt" type="submit">Click Me to disable your account</button>
	</form>
</div>