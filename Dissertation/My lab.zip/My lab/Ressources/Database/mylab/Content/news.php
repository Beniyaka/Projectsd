<?php 

	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	
	if(isset($_SESSION['usr'])){
	
		define('INCLUDE_CHECK',true);
		require '../connect.php' ;
	
		$title = mysqli_real_escape_string($link, $_POST['title']);
		$content = mysqli_real_escape_string($link, $_POST['content']);
		$receiver = mysqli_real_escape_string($link, $_POST['peopleTo']);
	
		$sqlNews = mysqli_query($link, "INSERT INTO News (title, content, receiver) VALUES ('".$title."','".$content."','".$receiver."') ") or die(mysqli_error($link));
		if(mysqli_affected_rows($link)==1){
			echo '<span class="success">You have successfully Added News.</span>
					<meta HTTP-EQUIV="REFRESH" content="3; url=./?pg=settings"/>';
		}else{
			echo '<span class="error">Add new News failed, please try again.</span>';
		}
	}

?>