<?php
define('INCLUDE_CHECK',true);

require './connect.php';
?>

<title>My Modules - MyLab Helper Allocation</title>

<style type="text/css">
	
	#viewLecturerToModule { width: 450px; }
	#viewModuleData { width: 300px; }
	
	#moduleDescriptor { width: 600px; }
	table { border: 1px solid black; padding: 20px; border-collapse: collapse; }
	table th { border: 1px solid black; background-color: #dedede; }
	table td { border: 1px solid black; padding: 10px; vertical-align: top; }
	ul { list-style-type: none; font-weight: normal; font-size: 1em; }
	
	#selectYear { float: right; display: block; margin-right: 30px;}
	
	@media print{
		.headline, .section { page-break-inside: avoid;}
		.section { page-break-after: always; }
	}


</style>



<script type="text/javascript" >

$(document).ready(function(){

	$(".helperJoin").parent().remove();
	
	$( "#accordion" ).accordion({
		active: false,
		collapsible: true,
		header: "h3",
		
	});
	
	$('.leaveModule').click(function() {
		var pass=0;
		
		if(pass==0){
			$.post('./Content/leaveModule.php', {"moduleID" : $(this).parent().find(".modID").html() }, function(data) {
				location.reload();
			});
		}
	});
	
	$('.helperLeave').click(function() {
		var pass=0;
		if(pass==0){
			$.post('./Content/leaveModule.php', {"ttID" : $(this).attr("id") }, function(data) {
				location.reload();
			});
		}
	});
	
	$('.findHelpers').click(function() {
		var pass=0;
		
		if(pass==0){
			$.post('./Content/findHelpersForm.php', {"moduleID" : $(this).parent().find(".modID").html() }, function(data) {
				location.reload();
			});
		}
	});
	
	// actions taken upon clicking the expand all (collapse all) link 
	$('#accordion #expand').click( function() { 
        var currHTML = $('#accordion #expand').html(); 
        if (currHTML=="Expand All") { 
				$('#accordion .section').slideDown();
            $('#accordion #expand').html("Collapse All");
        } 
        else { 
        		$('#accordion .section').slideUp();
            $('#accordion #expand').html("Expand All");
        } 
	});

	$("#printModules").click(function(){
		if($('#accordion #expand').html()=="Expand All"){
			$('#accordion #expand').click();
			setTimeout(function() {
				window.print();
			}, 2000 );
		}else window.print();
	});
	
});

</script>

	<form id="selectYear" action="./" method="GET">
		<select name="years" id="years" onchange="this.form.submit()">
			<?php
				if($_SESSION['accType']=='Lecturer'){
					$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y, Lecturers L, ModuleLecturers ML, Modules M WHERE T.termYearID=Y.tYearID  AND L.usr='".$_SESSION['usr']."' AND ML.lecturerID=L.lecturerID AND ML.mID=M.mID AND M.mTerm=T.termID GROUP BY T.termID ORDER BY T.termID DESC") or die(mysqli_error($link));
				}elseif($_SESSION['accType']=='Helper'){
					$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y, Helpers H, ModuleHelpers MH, Modules M, Timetable TT WHERE T.termYearID=Y.tYearID  AND H.usr='".$_SESSION['usr']."' AND MH.helperID=H.hID AND MH.ttID=TT.ttID AND TT.mID=M.mID AND M.mTerm=T.termID GROUP BY T.termID ORDER BY T.termID DESC") or die(mysqli_error($link));
				}
				
				
				while($row=mysqli_fetch_assoc($sqlTerms)){
					if(!isset($first)) $first = $row['termID'];
					echo '<option value="'.$row['termID'].'" '.(($_GET['years']==$row['termID'])?"selected=\"selected\"":"").' >'.$row['tYearStart']."-".$row['tYearEnd'].": Semester ".$row['term'].'</option>';
				}
			?>
		</select>
		<?php echo '<input type="hidden" name="pg" value="'.$_GET['pg'].'"/>'; ?>
	</form>

	<div class="heading"><h1>My Modules</h1></div><br>
		
	<button type="button" class="noPrint" id="printModules">Print</button>		
	<div id="accordion">
	<div id="expand" style="text-align:right">Expand All</div>
	<?php
	
	$specify = "";
	$tableS = "";

	if(isset($_GET['years']) && $_GET['years']!="all"){ 
		$tableS=", Terms TE "; 
		$specify = "AND M.mTerm=TE.termID AND TE.termID=".$_GET['years'];
	}else{
		$tableS=", Terms TE "; 
		$specify = "AND M.mTerm=TE.termID AND TE.termID=".$first;
	}
	
	if($_SESSION['accType']=="Lecturer"){
		$sqlMyModules = mysqli_query($link, "SELECT M.mCode, M.mName, L.mID FROM ModuleLecturers L, Modules M $tableS WHERE (M.mID=L.mID AND L.lecturerID=(SELECT Z.lecturerID FROM Lecturers Z WHERE Z.usr='".$_SESSION['usr']."')) $specify") or die(mysqli_error($link));
	}elseif($_SESSION['accType']=="Helper"){
		$sqlMyModules = mysqli_query($link, "SELECT M.mCode, M.mName, M.mID FROM ModuleHelpers H, Modules M, Timetable T $tableS WHERE (H.ttID=T.ttID AND T.mID=M.mID AND H.aproved='true' AND H.helperID=(SELECT Z.hID FROM Helpers Z WHERE Z.usr='".$_SESSION['usr']."')) $specify GROUP BY M.mID") or die(mysqli_error($link));
	}
	$_POST['conn'] = "./connect.php";
	if(mysqli_affected_rows($link)>0){
		while($row1=mysqli_fetch_array($sqlMyModules)){
			echo '<h3 class="headline"><a href="#">'.$row1['mCode'].' - '.$row1['mName'].'</a></h3>';
			echo '<div class="section">';
			$_POST['mID']=$row1['mID'];
			include("./Content/viewModule.php");
			if($_SESSION['accType']=='Lecturer') {
				echo '<br /><button type="button" class="leaveModule" class="ui-widget"> Leave </button>';
				echo ' <a href="./?pg=findHelpersForm"><button type="button" class="findHelpers" class="ui-widget"> Find Helpers </button></a>';
				echo ' <a href="./?pg=addModuleForm&mID='.$_POST['mID'].'"><button type="button" class="editModule" class="ui-widget"> Edit </button></a>';
			}
			echo '<br /></div>';
		}
	}else {
		echo '</div><div>None. Try adding a module using the <a href="./?pg=viewModuleForm">search page</a>.';
	}
	?>	
	
	</div><br>

