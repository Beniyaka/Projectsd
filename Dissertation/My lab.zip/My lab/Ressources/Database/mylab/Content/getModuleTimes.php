<?php

	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	
	define('INCLUDE_CHECK',true);
	$requireStuff = (isset($_POST['conn'])) ? $_POST['conn']:'../connect.php' ;
	require $requireStuff;

	$sql = mysqli_query($link, "SELECT ttID, ttDay, ttStartTime, ttEndTime FROM Timetable T WHERE ttNoHelpers>(select COUNT(*) FROM ModuleHelpers MH WHERE MH.ttID=T.ttID) AND mID=".$_POST['mID']) or die(mysqli_error($link));
	echo '	<h1>What Times are your labs or tutorials?</h1>
	<br><br><br><ol id="selectable">';
	while($row=mysqli_fetch_assoc($sql)){
		echo "<li class=\"chooseTime ui-widget-content\" id=".$row['ttID'].">".$row['ttDay']." ".$row['ttStartTime']."-".$row['ttEndTime']."</li>";
	}
	echo'</ol>';
	echo'<br><br><button type="button" id="back">Back</button><button type="button" id="next">Next</button>';
	
?>