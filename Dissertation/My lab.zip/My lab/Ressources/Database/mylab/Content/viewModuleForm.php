<?php 
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<title>Module Details - MyLab Helper Allocation</title>

<style type="text/css">
	
	#viewLecturerToModule { width: 450px; }
	#viewModuleData { width: 300px; }
	
	#moduleDescriptor { width: 600px; }
	table { border: 1px solid black; padding: 20px; border-collapse: collapse; }
	table th { border: 1px solid black; background-color: #dedede; }
	table td { border: 1px solid black; padding: 10px; vertical-align: top; }
	ul { list-style-type: none; }
	
	.heading { font-size: 1.5em; font-weight: bold; }
	.subheading { font-size: 1em; font-weight: bold; } 

</style>

<?php
	$sqlFirst = '<script type="text/javascript" > var username="'.$_SESSION['usr'].'"; 
	function buttons(){
	if($("#"+username).html()=="" || $("#"+username).html()==null ){ $("#joinModule").removeAttr("disabled"); $("#leaveModule").attr("disabled","disabled"); }
	else { $("#joinModule").attr("disabled","disabled"); $("#leaveModule").removeAttr("disabled");}
} $(function(){
';//$(document).ready(function(){
	//$sqlFirst .= '$(function() {	';
	$sqlTagNames = ' var availableTags = [';
	$sqlTagIDs = 'var courseIDs = [';
	
	$sqlTerms = mysqli_query($link, "SELECT M.mID, M.mCode, M.mName, T.term, TY.tYearStart, TY.tYearEnd FROM Modules M, Terms T, TermYears TY WHERE M.mTerm=T.termID AND T.termYearID=TY.tYearID ORDER BY T.termID DESC");
	
	$xxx = 0;
	while($row2=mysqli_fetch_assoc($sqlTerms)){
		if($xxx>0){ $sqlTagNames.=','; $sqlTagIDs.=','; }
		$sqlTagNames .= '"'.$row2['mCode'].' - '.$row2['mName'].' ('.$row2['tYearStart'].'-'.$row2['tYearEnd'].' Sem. '.$row2['term'].')"';
		$sqlTagIDs .= '"'.$row2['mID'].'"';
		$xxx .= 1;
	}
			
	$sqlTagNames .= '];';
	$sqlTagIDs .= ']; ';
	$sqlEnd .=' $( "#viewModuleData" ).autocomplete({ source: availableTags }); ';
	
	echo $sqlFirst.$sqlTagIDs.$sqlTagNames.$sqlEnd;
?>

// <script type="text/javascript" >

// $(document).ready(function(){
	
	$('#viewModule').click(function() {
		var pass=0;
		$("#viewResult").html("");	

		$(".error").html("");				
		
		if( $("#viewModuleData").val()=="" || $("#viewModuleData").val()==null ){ 
			$("#viewModuleError").html("Please select a module to join by typing its name.");
			pass=1;
		}else if( jQuery.inArray($("#viewModuleData").val(),availableTags)==-1){
			$("#viewModuleError").html("The module you have requested is not available, please check your information and try again or add your module using the \"add module\" function.<br />");
			pass=1;
		}
		
		if(pass==0){
			$.post('./Content/viewModule.php', {"mID" : courseIDs[availableTags.indexOf($("#viewModuleData").val())] }, function(data) {
				$("#viewResult").html(data);
				buttons();
			});
		}
	});
	
	$("#viewModuleData").keypress(function(e){
            code= (e.keyCode ? e.keyCode : e.which);
            if (code == 13) $('#viewModule').click();
	});
	
	$('#joinModule').click(function() {
		var pass=0;

		
		if(pass==0){
			$.post('./Content/joinModule.php', {"moduleID" : courseIDs[availableTags.indexOf($("#viewModuleData").val())] }, function(data) {
				$.post('./Content/viewModule.php', {"mID" : courseIDs[availableTags.indexOf($("#viewModuleData").val())] }, function(data2) {
					$("#viewResult").html(data+"<br><br>"+data2+"<br>");
					buttons();
				});
			});
		}
	});
	
	$('.helperJoin').live("click",function() {
		var pass=0;
		if(pass==0){
			$.post('./Content/joinModule.php', {"ttID" : $(this).attr("id") }, function(data) {
				$.post('./Content/viewModule.php', {"mID" : courseIDs[availableTags.indexOf($("#viewModuleData").val())] }, function(data2) {
					$("#viewResult").html(data+"<br><br>"+data2+"<br>");
					buttons();
				});
			});
		}
	});
	
	$('.helperLeave').live("click", function() {
		var pass=0;
		if(pass==0){
			$.post('./Content/leaveModule.php', {"ttID" : $(this).attr("id") }, function(data) {
				$.post('./Content/viewModule.php', {"mID" : courseIDs[availableTags.indexOf($("#viewModuleData").val())] }, function(data2) {
					$("#viewResult").html(data+"<br><br>"+data2+"<br>");
					buttons();
				});
			});
		}
	});
	
	$('#leaveModule').click(function() {
		var pass=0;

		
		if(pass==0){
			$.post('./Content/leaveModule.php', {"moduleID" : courseIDs[availableTags.indexOf($("#viewModuleData").val())] }, function(data) {
				$.post('./Content/viewModule.php', {"mID" : courseIDs[availableTags.indexOf($("#viewModuleData").val())] }, function(data2) {
					$("#viewResult").html(data+"<br><br>"+data2+"<br>");
					buttons();
				});
			});
		}
	});
	
});

</script>	
	<div id="viewLecturerToModule" class="module">
		<label>View Module Details</label><br>
		<span id="viewModuleError" class="error"></span>
		<input type="text" id="viewModuleData" name="mID" class="ui-widget"/>
		<button type="button" id="viewModule" class="ui-widget"> View Module</button><br />
	</div>
	<br />
	<div id="viewResult">
	</div><br />
	<?php
	
	if($_SESSION["accType"]=="Lecturer"){
		echo '<button type="button" disabled="disabled" id="joinModule" class="ui-widget"> Join </button> 
		<button type="button" disabled="disabled" id="leaveModule" class="ui-widget"> Leave </button><br />';
	}
	?>
