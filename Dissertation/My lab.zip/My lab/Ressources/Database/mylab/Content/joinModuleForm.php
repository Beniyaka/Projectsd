<?php 
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<style type="text/css">
	
	#joinLecturerToModule { width: 450px; }
	#joinModuleData { width: 300px; }

</style>

<?php
	$sqlFirst = '<script type="text/javascript" >$(document).ready(function(){';
	//$sqlFirst .= '$(function() {	';
	$sqlTagNames = 'var availableTags = [';
	$sqlTagIDs = 'var courseIDs = [';
	
	$sqlTerms = mysqli_query($link, "SELECT mID, mCode, mName FROM Modules");
	
	$xxx = 0;
	while($row2=mysqli_fetch_assoc($sqlTerms)){
		if($xxx>0){ $sqlTagNames.=','; $sqlTagIDs.=','; }
		$sqlTagNames .= '"'.$row2['mCode'].' - '.$row2['mName'].'"';
		$sqlTagIDs .= '"'.$row2['mID'].'"';
		$xxx .= 1;
	}
			
	$sqlTagNames .= '];';
	$sqlTagIDs .= '];';
	$sqlEnd .=' $( "#joinModuleData" ).autocomplete({ source: availableTags }); ';
	
	echo $sqlFirst.$sqlTagNames.$sqlTagIDs.$sqlEnd;
?>

// <script type="text/javascript" >

// $(document).ready(function(){
	
	$('#joinModule').click(function() {
		var pass=0;
		
		$(".error").html("");				
		
		if( $("#joinModuleData").val()=="" || $("#joinModuleData").val()==null ){ 
			$("#joinModuleError").html("Please select a module to join by typing its name.");
			pass=1;
		}else if( jQuery.inArray($("#joinModuleData").val(),availableTags)==-1){ 
			$("#joinModuleError").html("The module you have requested is not available, please check your information and try again or add your module using the \"add module\" function.<br />");
			pass=1;
		}
		
		
		if(pass==0){
			$.post('./Content/joinModule.php', {"moduleID" : courseIDs[availableTags.indexOf($("#joinModuleData").val())] }, function(data) {
				alert(data);
			});
		}
	});
	
	
	
});

</script>

	<div id="joinLecturerToModule" class="module">
		<label>Join Module</label><br>
		<span id="joinModuleError" class="error"></span>
		<input type="" id="joinModuleData" name="moduleID" class="ui-widget"/>
		<button type="button" id="joinModule" class="ui-widget"> Join Module</button><br />
	</div>

