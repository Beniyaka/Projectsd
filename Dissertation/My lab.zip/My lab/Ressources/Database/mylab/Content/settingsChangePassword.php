<?php
	// Starting the session
	session_name('mylabLogin');
	session_start();

	define('INCLUDE_CHECK',true);
	require('../connect.php');
	$oldPass=md5($_POST['oldPass']);
	$newPass=md5($_POST['newPass1']);


mysqli_query($link, "UPDATE Users SET pswd='".$newPass."' WHERE usr='".$_SESSION['usr']."' AND pswd='".$oldPass."'") or die(mysqli_error($link));

if(mysqli_affected_rows($link)==1){
	echo '<span class="success">You have successfully changed your password.</span>
			<meta HTTP-EQUIV="REFRESH" content="3; url=./?pg=settings"/>';
}else{
	echo '<span class="error">Password change failed, please try again.</span>';
}

?>