<?php

session_name('mylabLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();

define('INCLUDE_CHECK',true);

require '../connect.php';
if($_SESSION['accType']=="Helper"){
	if(!isset($_POST['no'])){
		$sqlJoinModule = "INSERT INTO ModuleHelpers(helperID,ttID,aproved) VALUES((SELECT hID FROM Helpers WHERE usr='".$_SESSION['usr']."'),".$_POST['ttID'].",'false');"; 
		$sqlRequests = "INSERT INTO `Requests`(`usrFrom`, `ttID`, `seen`) VALUES ('".$_SESSION['usr']."',".$_POST['ttID'].",'false');";
		mysqli_query($link, $sqlJoinModule) or die("Error: ".mysqli_error($link));
		mysqli_query($link, $sqlRequests) or die("Error: ".mysqli_error($link));
		echo '<span class="success">You have successfully requested to join the module.</span>';
	}else{
		$sqlRequests = "INSERT INTO `Requests`(`usrFrom`, `mID`, `seen`,`acknowledged`) VALUES ('".$_SESSION['usr']."',".$_POST['moduleID'].",'true','true');";
		mysqli_query($link, $sqlRequests) or die("Error: ".mysqli_error($link));
	}
}elseif($_SESSION['accType']=="Lecturer"){
	$sqlJoinModule = "INSERT INTO ModuleLecturers(lecturerID,mID) VALUES((SELECT lecturerID FROM Lecturers WHERE usr='".$_SESSION['usr']."'),".$_POST['moduleID'].")";
	mysqli_query($link, $sqlJoinModule) or die("Error: ".mysqli_error($link));
	echo '<span class="success">You have successfully joined the module.</span>';
}


?>