<link rel="shortcut icon" href="./Ressources/IMG/logo.ico" type="image/x-icon"/>
<?php
session_start();
define('INCLUDE_CHECK',true);
require './connect.php';
require './functions.php';
if (!isset($_SESSION['mysesi'])){
  echo "<script>window.location.assign('./login.php')</script>";
}
$row = mysqli_fetch_assoc(mysqli_query($link, "SELECT accType FROM Users WHERE usr='{$_SESSION['mysesi']}'"));
$me = $row['accType'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head >
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="900;url=logoff.php"/>
    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="/Ressources/CSS/main.css" rel="stylesheet"/>
  <title>Lab Helper System</title>
<link rel="stylesheet" href="/Ressources/CSS/main.css"/>

    <?php include("./baseInclude.php"); ?>
   	<?php		
	echo '';
		if($me=='Helper') { 
			$sql = mysqli_query($link, "SELECT COUNT(rID) as seen FROM Requests WHERE usrTo='".$_SESSION['mysesi']."' AND acknowledged IS NULL LIMIT 1") or die(mysqli_error($link));
			$sql2 = mysqli_query($link, "SELECT COUNT(rID) as seen FROM Requests WHERE usrFrom='".$_SESSION['mysesi']."' AND acknowledged IS NOT NULL AND seen='false' LIMIT 1") or die(mysqli_error($link));
			$sql3 = mysqli_query($link, "SELECT COUNT(M.mID) AS counted
										FROM Helpers H, Modules M, Terms T 
										WHERE T.termID=M.mTerm AND T.termID=(SELECT MAX(TT.termID) FROM Terms TT) AND
										H.usr NOT IN (SELECT R.usrFrom FROM Requests R, Timetable T WHERE R.ttID=T.ttID AND T.mID=M.mID AND H.usr=R.usrFrom) 
											AND H.usr NOT IN (SELECT R.usrTo FROM Requests R, Timetable T WHERE R.ttID=T.ttID AND T.mID=M.mID AND H.usr=R.usrTo) 
											AND H.usr NOT IN (SELECT HH.usr FROM ModuleHelpers HM, Helpers HH, Timetable TT WHERE HM.ttID=TT.ttID AND TT.mID=M.mID AND H.hID=HM.helperID AND HH.hID=HM.helperID) 
											AND H.usr='".$_SESSION['mysesi']."' 
											AND (((SELECT COUNT(HS.skillID) FROM HelperSkills HS, ModuleSkillsRequired S
												  WHERE HS.helperID=H.hID AND HS.skillID = S.skillID AND S.moduleID=M.mID )
												  /
												  (SELECT COUNT(*) FROM ModuleSkillsRequired S WHERE S.moduleID=M.mID )
												  )*100)>=50
										ORDER BY (SELECT COUNT(*) FROM HelperSkills HS, ModuleSkillsRequired S 
												WHERE HS.helperID=H.hID AND HS.skillID = S.skillID AND S.moduleID=M.mID) DESC") or die(mysqli_error($link));
		
		
		}
elseif($me=='Lecturer') {
			//$sql = mysqli_query($link, "SELECT COUNT(seen) as seen FROM Requests WHERE usrTo='".$_SESSION['mysesi']."' AND acknowledged='false' LIMIT 1") or die(mysqli_error($link));
				$sql = mysqli_query($link, "SELECT COUNT(R.rID) as seen 
														FROM Requests R, Modules M, ModuleLecturers ML, Lecturers L, Timetable T 
														WHERE R.ttID=T.ttID AND T.mID=M.mID AND ML.lecturerID=L.lecturerID AND ML.mID=T.mID AND T.ttID=R.ttID AND L.usr='".$_SESSION['mysesi']."' AND R.acknowledged IS NULL AND R.usrTo IS NULL") 
														or die(mysqli_error($link));
				$sql2 = mysqli_query($link, "SELECT COUNT(R.rID) as seen 
														FROM Requests R, Modules M, ModuleLecturers ML, Lecturers L, Timetable T 
														WHERE R.ttID=T.ttID AND T.mID=M.mID AND ML.lecturerID=L.lecturerID AND ML.mID=T.mID AND T.ttID=R.ttID AND L.usr='".$_SESSION['mysesi']."' AND R.acknowledged IS NOT NULL AND R.seen='false' AND R.usrTo IS NOT NULL") 
														or die(mysqli_error($link));
				$sql3=0;
		}
elseif($me=='Administrator'){
			$sql=mysqli_query($link, "SELECT COUNT(*) AS seen FROM Users WHERE approvedUser='false'") or die(mysqli_error($link));
			$sql2=0;
			$sql3=0;
		}
		if($me){
			$row=mysqli_fetch_assoc($sql);
			$row2=($sql2!=0)?mysqli_fetch_assoc($sql2):0;
			$row3 = ($sql3!=0)?mysqli_fetch_assoc($sql3):0;
			$msgCount = 0 + $row['seen'] + $row2['seen']+(($row3!=0)?$row3['counted']:0);
			echo '<script>
		$(function() {
			$("#circle").hide();
			$("#circle").html('.$msgCount.');
			if('.$msgCount.'>0){
				$("#circle").show();
			}
		});
		</script>';
		
		}
		
?>
</head>
<body onload="startTime()">

    <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		<div id="header">
		<img class="me" src="./Ressources/IMG/testt.jpg"/><img id="logo" src="./Ressources/IMG/logo.png"/><input type="button" value="Welcome" class="button" onclick="location.href='./home.php';" /><a id="img" href="?pg=viewRequests"><img class="img1" src="./Ressources/IMG/req.jpg"/><span id="circle"></span></a>
<div id="txt"></div><h1 id="text">Lab Helper System</h1>
</div>
		</div>
	</div>
<div class="row">
		<div class="col-md-12">
		<div id="nav3">
  <?php
  		
  		if($_SESSION['mysesi']){
  			if($me=='Lecturer') { $yes=0; }
  			elseif($me=='Helper') { $yes=1; }
  			elseif($me=='Administrator'){ $yes=2; }
  			if($yes!=2) echo '<li><a href="?pg=home" id="home">Home</a></li>';
  			if($yes==2) echo '<li><a href="?pg=settings"  id="settings">Settings</a></li>';
	  		if($yes!=2) echo '<li><a href="?pg=myModules" >My Modules</a></li>';
			if($yes==0) echo '<li><a href="?pg=addModuleForm"> New Module </a></li>';
			if($yes!=2) echo '<li><a href="?pg=viewModuleForm" >All Modules</a></li>';
			if($yes==0) echo '<li><a href="?pg=findHelpersForm" >Find Helpers</a></li>';
			if($yes==2) echo '<li><a href="?pg=adminUsers" >Users</a></li>';
			if($yes==2) echo '<li><a href="?pg=adminModules" >Modules</a></li>';
			if($yes==2) echo '<li><a href="?pg=adminReports" >Reports</a></li>';
			//echo '<li><a href="?pg=viewRequests"  id="msgs">Requests<span id="circle"></span> </a></li>'; 
			if($yes!=2) echo '<li><a href="?pg=settings"  id="settings">Settings</a></li>';
			echo '<li><a href="./logoff.php"><div>Logout</div></a></li>';
		}	
		?>
</div>
<div id="nav2">
	<h1>News</h1>
	<div id="news1">
		<?php 

			if($me=='Lecturer'){
				$sqlCheckNews = mysqli_query($link, 'SELECT title, content FROM News WHERE receiver=\'Lecturer\' OR receiver=\'both\' ORDER BY dateAdded DESC LIMIT 1') or die(mysqli_error($link));
				if(mysqli_affected_rows($link)==1){
				$row=mysqli_fetch_assoc($sqlCheckNews);
				echo '<h3>'.$row['title'].'</h3><br>';
				echo '<span class="newsFlash">'.$row['content'].'</span>';
				
			}else echo '<h2>None.</h2>';
			}
elseif($me=='Helper'){
				$sqlCheckNews = mysqli_query($link, 'SELECT title, content FROM News WHERE receiver=\'Helper\' OR receiver=\'both\' ORDER BY dateAdded DESC LIMIT 1') or die(mysqli_error($link));
				if(mysqli_affected_rows($link)==1){
				$row=mysqli_fetch_assoc($sqlCheckNews);
				echo '<h3>'.$row['title'].'</h3><br>';
				echo '<span class="newsFlash">'.$row['content'].'</span>';
				
			}else echo '<h2>None.</h2>';
			}
		?>
	</div>
</div>

<div class="containerss">

<div class="home">

			<div id="loading"  align="center">
			<img src="./Ressources/IMG/load-circle.gif" alt="loading.." /> <br>
			Loading, please wait.. <br>
		</div> 
		<div id="middle" style="visibility:hidden;">
			<?php 
			if($_SESSION['mysesi']){
				if(isset($_GET['pg']) && $_GET['pg'] != "") {
   				$pg = $_GET['pg'];
    				if (file_exists('./Content/'.$pg.'.php')) {
    					include ('./Content/'.$pg.'.php');
    				}else
						include ('./Content/404.php');
				}
				else{
					if($yes!=2) include('./Content/home.php');
					else if($yes==2) include('./Content/settings.php');
				}
			}else {
				include('./Content/frontPage.php');
			}
			?>
			</div>
</div>
</div>
<div id="footer">
<h3>This website was developed by <a href="http://ibktech.tk/en/Our-Team/#wb_element_instance149" style="text-decoration:none;"><span style="font-style:italic; font: 16px/1 Lobster,Arial,sans-serif;"> Beni Iyaka </span>.</a></h3>
</div>
</div>
</div>
</div>
	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
    <script type="text/javascript" >
$(function() {
	$(".tabs a:last-child").css("border-radius","0px 6px 6px 0px");
	$(".tabs a:first-child").css("border-radius"," 6px 0px 0px 6px");
	$( "a", ".tabs" ).button();
});
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
$(window).load(function(){ 
	setTimeout(function() {
  	$("#middle").css("visibility","visible");
  	$("#loading").hide();
	},500);
});
</script>
</body>
</html>
