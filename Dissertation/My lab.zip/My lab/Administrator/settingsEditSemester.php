<?php
	// Starting the session
	session_name('mylabLogin');
	session_start();
	
if($_SESSION['accType']=="Administrator"){
	define('INCLUDE_CHECK',true);
	require('../connect.php');
	$start=mysqli_real_escape_string($link,$_POST['tYearStart']);	
	$end=mysqli_real_escape_string($link,$_POST['tYearEnd']);
	$term=mysqli_real_escape_string($link,$_POST['term']);
	$rate=mysqli_real_escape_string($link,$_POST['helperRate']);
	
	if(!isset($_POST['yearID'])){	
		$lol=mysqli_query($link, "INSERT INTO TermYears(tYearStart,tYearEnd) VALUES (".$start.",".$end.")") or die(mysqli_error($link));
		$yearID=mysqli_insert_id($link);
	}else $yearID=mysqli_real_escape_string($link,$_POST['yearID']);
	
	mysqli_query($link, "INSERT INTO Terms(termYearID,term,helperRate) VALUES (".$yearID.",".$term.",'".$rate."')") or die(mysqli_error($link));
	if(mysqli_affected_rows($link)==1){
		echo '<span class="success">You have successfully updated the Semester.</span>
				<meta HTTP-EQUIV="REFRESH" content="3; url=./?pg=settings"/>';
	}else{
		echo '<span class="error">Semester update failed, please try again.</span>';
	}
}

?>