<?php 


		define('INCLUDE_CHECK',true);
		require '../connect.php' ;
	
		$title = mysqli_real_escape_string($link, $_POST['title']);
		$content = mysqli_real_escape_string($link, $_POST['content']);
		$receiver = mysqli_real_escape_string($link, $_POST['peopleTo']);
	
		$sqlNews = mysqli_query($link, "INSERT INTO News (title, content, receiver) VALUES ('".$title."','".$content."','".$receiver."') ") or die(mysqli_error($link));
		if(mysqli_affected_rows($link)==1){
			echo '<span class="success">You have successfully Added News.</span>
					<script>alert("./Adminindex.php")</script>';
		}else{
			echo '<span class="error">Add new News failed, please try again.</span>';
		}

?>