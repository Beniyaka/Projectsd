<?php 
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<title>Administrator Home - MyLab Helper Allocation</title>

<style type="text/css">
	
		td { padding-left: 10px; padding-right: 10px; }
		#fullTT { float: left; width: 300px; }
		#today { float: right; width: 200px; border: 1px solid #ddd; border-radius: 8px; background-color: #eee; }
		
</style>


<div id="fullTT">

<h1>Home admin area. Maybe some buttons coming soon or I can get rid of this.</h1>

</div>

<div style="clear: both;"> </div>
