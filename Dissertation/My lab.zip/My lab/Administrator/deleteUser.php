<?php 
	//if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
	
	define('INCLUDE_CHECK',true);
	require '../connect.php';
	
	$userName = mysqli_real_escape_string($link, $_POST['deleteUserName']);
	
	$sqlKillUser = "DELETE FROM HelperSkills WHERE helperID = (SELECT hID FROM Helpers WHERE usr='".$userName."'); ";
	$sqlKillUser .= "DELETE FROM HelperDegrees WHERE helperID = (SELECT hID FROM Helpers WHERE usr='".$userName."'); ";
	$sqlKillUser .= "DELETE FROM Helpers WHERE usr='".$userName."'; ";
	$sqlKillUser .= "DELETE FROM Lecturers WHERE usr='".$userName."'; ";
	$sqlKillUser .= "DELETE FROM Users WHERE usr='".$userName."'; ";
	
	
	mysqli_multi_query($link, $sqlKillUser);
	
	if(mysqli_errno($link)){
		echo "There was an error\n\n\"".mysqli_error($link)."\"";
	}elseif(mysqli_affected_rows($link)==0){
		echo "User '".$userName." deleted.";
	}
	mysqli_close($link);
	
?>