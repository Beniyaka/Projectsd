<?php 
	//if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
	
	define('INCLUDE_CHECK',true);
	require '../connect.php';
	
	$sqlPurgeUsers = "TRUNCATE TABLE HelperSkills; ";
	$sqlPurgeUsers .= "TRUNCATE TABLE HelperDegrees; ";
	$sqlPurgeUsers .= "TRUNCATE TABLE Helpers; ";
	$sqlPurgeUsers .= "TRUNCATE TABLE Lecturers; ";
	$sqlPurgeUsers .= "TRUNCATE TABLE Users; ";
	
	
	mysqli_multi_query($link, $sqlPurgeUsers) or die(mysqli_error());
	
	
	if(mysqli_errno($link)){
		echo "There was an error\n\n\"".mysqli_error($link)."\"";
	}elseif(mysqli_affected_rows($link)==0){
		echo "Users deleted.";
	}else{
		echo "Users deleted.\n\nRows affected: ".mysqli_affected_rows($link);
	}	
	
	
	mysqli_close($link);
	
?>