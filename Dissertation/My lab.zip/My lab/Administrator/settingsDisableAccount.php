<?php
	define('INCLUDE_CHECK',true);
	require '../connect.php';

	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();

	if(isset($_SESSION['usr']) && ( $_SESSION['usr']==$_POST['usr'] || $_SESSION['accType']=='Administrator' ) && $_POST['killConf']=='true'){
		$sqlDisableAccount = mysqli_query($link, "UPDATE Users SET activeUser='false'	WHERE usr='".mysqli_real_escape_string($link, $_POST['usr'])."'") or die(mysqli_error($link));
		if(mysqli_affected_rows($link)!=1) echo "Something went terribly wrong :S";
		
	}else echo "you're not supposed to be here, you nearly disabled your own account!!";

?>