<?php 
	if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<title>Change Password - MyLab Helper Allocation</title>

<style type="text/css">

	form span { padding: 10px; }
	.ok { background-color: #D3EEAB; }
	.no { background-color: #edabac; }
	form span input { font-size: 1.2em;  }
	#submitForm { font-size: 1em; padding: 3px; }

</style>


<script type="text/javascript" >

	$.post('./Content/settingsEditRates.php',{ "getRate":$("#yearsR").val() }, function(data) {
		$("#newRate").val(data);
	});

	$("#yearsR").change(function(){
		$.post('./Content/settingsEditRates.php',{ "getRate":$("#yearsR").val() }, function(data) {
			$("#newRate").val(data);
		});
	});

	$( "#newRateForm" ).submit(function(event) {
		event.preventDefault();
		$("#viewResult").html("");
		var pass=0;
		
		$(".error").html("");	
		$(".ok").removeClass("ok");
		$(".no").removeClass("no");
		var regex=/^([0-9]{1,2})(.)([0-9]){0,2}$/;
		
		if( !($("#newRate").val()).match(regex) ){ 
			$("#newRate").parent().addClass("no");
			$("#newRateErrorR").html("Please enter a number in the format: '12.45'.");
			pass=1;
		}else {
			$("#newRate").parent().addClass("ok");
		}
		
		if(pass==0){
			$.post('./Content/settingsEditRates.php', $("#newRateForm").serialize(), function(data) {
					$("#viewResultR").append(data);
			});
		}
		
	});
	


</script>

<div id="viewResultR"></div>

<form id="newRateForm" action="/">
	<select name="years" id="yearsR">
	<?php
		$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y WHERE T.termYearID=Y.tYearID GROUP BY T.termID ORDER BY T.termID DESC");
				
		while($row=mysqli_fetch_assoc($sqlTerms)){
			echo '<option value="'.$row['termID'].'" >'.$row['tYearStart']."-".$row['tYearEnd'].": Semester ".$row['term'].'</option>';
		}
		if(!isset($chosen)) $chosen=$first;
	?>
	</select><br /><br />
	<label for="oldPass">New Rate</label> 
		<span>£<input type="text" name="newRate" id="newRate" class="input" maxlength="5" style="width: 60px;"/><span id="newRateError" class="error"></span></span><br /><br />
	<input name="submitForm" value="Update Rate" class="input" type="submit"/>
</form>
