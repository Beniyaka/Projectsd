<?php

define('INCLUDE_CHECK',true);
require '../connect.php';
require '../functions.php';

session_start();

if (!isset($_SESSION['mysesi']))
{
  echo "<script>window.location.assign('../login.php')</script>";
}
$eish = mysqli_query($link,"SELECT * FROM users WHERE usr = '".$_SESSION['mysesi']."'");
$sqlUsers = mysqli_fetch_array($eish);
$me = $sqlUsers['accType'];
$names = $_SESSION['mysesi'];
if($me=='Lecturer') { $yes=0; }
elseif($me=='Helper') { $yes=1; }
elseif($me=='Administrator'){ $yes=2; }
?>


<style>

</style>
<div style="background-color: black"><a><h3 align="center"><?php echo $names ?></h3></a></div>
<a><img class="me" src="../Ressources/IMG/testt.jpg"/><a class="just"><img src="../Ressources/IMG/logo.png"/></a></a>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>MyLab Administrator</title>

<?php include("./baseInclude.php"); ?>


<style type="text/css">
.gridheader, .gridheaderbig, .gridheaderleft, .gridheaderright
{    
    padding: 4px 4px 4px 4px;
    background:  #003399 repeat-x;
    text-align: center;
    font-weight: bold;
    text-decoration: none;
    color: khaki;
}
.gridheaderleft
{
    text-align: left;
}
.gridheaderright
{
    text-align: right;
}
.gridheaderbig
{    
    font-size: 135%;
}
.boxcontenttext{
	    padding: 4px 4px 4px 4px;
}
button img { height: 55px; width: auto; }

	#userAdmin { font-size: 1em; width: 620px; border: 2px outset silver; border-radius: 4px; padding: 20px; }
	.AdminTitle { font-size: 2em; font-weight: bold; color: blue; }
	.instruction { font-size: 1em; }
	.error { color: red; }
	
	#actionsOnUsers {  width: 550px; border: 2px inset #F6F6F6; border-radius: 4px; background: #F6F6F6; padding: 10px; }
	#seeUser {  width: 550px; border: 2px inset #F6F6F6; border-radius: 4px; background: #F6F6F6; padding: 10px; }
	
	#userList { max-width: 500px; overflow: auto; }
	
	table { border: 1px solid black; border-collapse: collapse; }
	th { border: 1px solid black; font-size: 1em; font-weight: bold; padding: 5px; }
	td { border: 1px solid black; font-size: 1em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; padding: 5px;}
	.mei{
		position: absolute; top: 70%; right: 0%;
	}
	.mei1{
		position: absolute; top: 15%; right:7%;
	}
</style>

<script type="text/javascript" >

$(document).ready(function(){
	
	$("#purgeUsers").click(function(){
		$.post("./purgeUsers.php", function(data) {
			alert(data);
		});
	});
	
	$("#deleteUser").click(function(){
		var userToDelete = $("#deleteUserName").val();
		$.post("./deleteUser.php", {"deleteUserName" : userToDelete}, function(data) {
			alert(data);
			$("#deleteUserName").val("");
		});
	});
	
	
	
	$("#moduless").click(function(){
		$.post("./adminModules.php", function(data) {
					$("#modules").html(data);
					$("#modules").toggle();
		});
	});
	$("#back").click(function(){
		$.post("../Content/settingsBackupForm.php", function(data) {
					$("#backs").html(data);
					$("#backs").toggle();
		});
	});

});

</script>

</head>
<div class="roundbox boxshadow" style="width: 550px; border: solid 2px steelblue">              
    		<div id="backsd">
    		<?php include ('../Content/viewRequests.php'); ?>	
    		</div>

    <div class="gridheaderleft">Users</div>
    <div class="boxcontenttext">
           
        <span class="instruction">Enter user name to delete</span>
			<input id="deleteUserName" name="deleteUserName" type="text" /><button id="deleteUser" name="deleteUser" value="deleteUser" type="button"><img src="../Ressources/IMG/Actions-list-remove-user-icon.png"><br />Delete User</button> <br /><br /><br />
			<span class="error">Warning! this will delete all users </span>
			<button id="purgeUsers" name="purgeUsers" value="purgeUsers" type="button"><img src="../Ressources/IMG/delete_all_participants.png"><br/> Purge Users</button><br /><br />
        </div>
        
    <div class="gridheaderleft">Database</div>

</div>
<body>


</body>
<div class="mei1" style="width: 700px ">
	<?php
	include './settings.php';
	?>
</div>
</html>
