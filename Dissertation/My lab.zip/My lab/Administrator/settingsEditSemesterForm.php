<?php 
	if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<title>Change Password - MyLab Helper Allocation</title>

<style type="text/css">

	form span { padding: 10px; }
	.ok { background-color: #D3EEAB; }
	.no { background-color: #edabac; }
	form span input { font-size: 1.2em;  }
	#submitForm { font-size: 1em; padding: 3px; }

</style>


<script type="text/javascript" >

	$( "#newSemForm" ).submit(function(event) {
		event.preventDefault();
		$("#viewResultS").html("");
		var pass=0;

		if(pass==0){
			$.post('./Content/settingsEditSemester.php', $("#newSemForm").serialize(), function(data) {
					$("#viewResultS").append(data);
			});
		}
		
	});
	


</script>

<div id="viewResultS"></div>

<form id="newSemForm" action="/">
	<?php
		$sqlTerms = mysqli_query($link, "SELECT Y.tYearID, T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y WHERE T.termYearID=Y.tYearID AND Y.tYearEnd=(select MAX(tYearEnd) from TermYears) AND T.term=(select MAX(term) from Terms where termYearID=T.termYearID)");
		echo '<h1>New Semester: </h1>';
		while($row=mysqli_fetch_assoc($sqlTerms)){
			echo (($row['term']==1)?'<input type="hidden" name="yearID" value="'.($row['tYearID']).'"/>':"");
			echo 'Years <input style="width: 4em" type="text" readonly="readonly" value="'.(($row['term']==1)?$row['tYearStart']:$row['tYearStart']+1).'" name="tYearStart"/>';
			echo '-<input style="width: 4em" type="text" readonly="readonly" value="'.(($row['term']==1)?$row['tYearEnd']:$row['tYearEnd']+1).'" name="tYearEnd"/>';
			echo ' Semester :<input style="width: 1em" type="text" readonly="readonly" value="'.(($row['term']==1)?2:1).'" name="term"/>';
		}
	?>
	<br /><br />
	<input name="submitForm" value="Create New Semester" class="input" type="submit"/>
</form>
