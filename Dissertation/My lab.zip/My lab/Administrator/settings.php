<?php
if (!isset($yes))
{
  echo "<script>window.location.assign('../login.php')</script>";
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <?php include("./baseInclude.php"); ?>
    
<script type="text/javascript" >
$(function() {
	$(".tabs a:last-child").css("border-radius","0px 6px 6px 0px");
	$(".tabs a:first-child").css("border-radius"," 6px 0px 0px 6px");
	$( "a", ".tabs" ).button();
});
</script>

</head>

<div id="main">
	<div class="container">
		<div id="middle">
<title>MyLab Settings</title>

<style type="text/css">
	#settingsMenu button { height: 120px; width: 120px; font-size: 1.2em; margin: 10px; float: left; text-align: center; behavior: url(Ressources/PIE/PIE.php); }
	#settingsMenu1 button { height: 120px; width: 120px; font-size: 1.2em; margin: 10px; float: left; text-align: center; behavior: url(Ressources/PIE/PIE.php); }
		#settingsMenu2 button { height: 120px; width: 120px; font-size: 1.2em; margin: 10px; float: left; text-align: center; behavior: url(Ressources/PIE/PIE.php); }

		#settingsMenu3 button { height: 120px; width: 120px; font-size: 1.2em; margin: 10px; float: left; text-align: center; behavior: url(Ressources/PIE/PIE.php); }
				#settingsMenu4 button { height: 120px; width: 120px; font-size: 1.2em; margin: 10px; float: left; text-align: center; behavior: url(Ressources/PIE/PIE.php); }
	button img { height: 55px; width: auto; }
	.gridheader, .gridheaderbig, .gridheaderleft, .gridheaderright
{    
    padding: 4px 4px 4px 4px;
    background:  #003399 repeat-x;
    text-align: center;
    font-weight: bold;
    text-decoration: none;
    color: khaki;
}
</style>

<script>
	$(function() {
		$( "button", "#settingsMenu" ).button();
		$( "button", "#settingsMenu" ).click(function() { 
			$("#settingsMenu").hide("slide", { direction: "left" }, 500);
			$("#settingsMenu1").show("slide", { direction: "left" }, 500);
			$("#settingsMenu2").show("slide", { direction: "left" }, 500);
			$("#settingsMenu3").show("slide", { direction: "left" }, 500);
			$("#settingsMenu4").show("slide",{direction:"left"},500);
			$("#editRates").hide("slide", { direction: "left" }, 500);
			$("#listusers").hide("slide", { direction: "left" }, 500);
			$("#addNews").hide("slide", { direction: "left" }, 500);
			$("#changePassword").hide("slide", { direction: "left" }, 500);
			$("#disableAccount").hide("slide", { direction: "left" }, 500);
			$("#editSemester").hide("slide", { direction: "left" }, 500);
			$("#editDetails").hide("slide", { direction: "left" }, 500);
			$("#"+$(this).attr("class").split(" ")[0]).delay(500).show("slide", { direction: "right" }, 1000);
		});
	});
	$(function() {
		$( "button", "#settingsMenu1" ).button();
		$( "button", "#settingsMenu1" ).click(function() { 
			$("#settingsMenu1").hide("slide", { direction: "left" }, 500);
			$("#settingsMenu").show("slide", { direction: "left" }, 500);
			$("#settingsMenu2").show("slide", { direction: "left" }, 500);
			$("#settingsMenu3").show("slide", { direction: "left" }, 500);
			$("#settingsMenu4").show("slide", { direction: "left" }, 500);
			$("#restoreData").hide("slide", { direction: "left" }, 500);
			$("#backupData").hide("slide", { direction: "left" }, 500);
			$("#editRates").hide("slide", { direction: "left" }, 500);
			$("#addNews").hide("slide", { direction: "left" }, 500);
			$("#changePassword").hide("slide", { direction: "left" }, 500);
			$("#disableAccount").hide("slide", { direction: "left" }, 500);
			$("#editSemester").hide("slide", { direction: "left" }, 500);
			$("#editDetails").hide("slide", { direction: "left" }, 500);
			$("#"+$(this).attr("class").split(" ")[0]).delay(500).show("slide", { direction: "right" }, 1000);
		});
	});
	$(function() {
		$( "button", "#settingsMenu2" ).button();
		$( "button", "#settingsMenu2" ).click(function() { 
			$("#settingsMenu2").hide("slide", { direction: "left" }, 500);
			$("#settingsMenu").show("slide", { direction: "left" }, 500);
			$("#settingsMenu1").show("slide", { direction: "left" }, 500);
			$("#settingsMenu3").show("slide", { direction: "left" }, 500);
			$("#settingsMenu4").show("slide", { direction: "left" }, 500);
			$("#restoreData").hide("slide", { direction: "left" }, 500);
			$("#backupData").hide("slide", { direction: "left" }, 500);
			$("#addNews").hide("slide", { direction: "left" }, 500);
			$("#changePassword").hide("slide", { direction: "left" }, 500);
			$("#disableAccount").hide("slide", { direction: "left" }, 500);
			$("#editSemester").hide("slide", { direction: "left" }, 500);
			$("#editDetails").hide("slide", { direction: "right" }, 500);
			$("#listusers").hide("slide", { direction: "left" }, 500);
			$("#"+$(this).attr("class").split(" ")[0]).delay(500).show("slide", { direction: "right" }, 1000);
		});
	});
	$(function() {
		$( "button", "#settingsMenu3" ).button();
		$( "#moduless", "#settingsMenu3" ).click(function() { 
		window.location.assign('./adminModules.php?ben=25412562');
			});
			$( "#request", "#settingsMenu3" ).click(function() { 
		window.location.assign('./viewRequests.php');
			});
		});
			$(function() {
		$( "button", "#settingsMenu4" ).button();
		$( "button", "#settingsMenu4" ).click(function() { 
		$("#settingsMenu4").hide("slide", { direction: "left" }, 500);
			$("#settingsMenu").show("slide", { direction: "left" }, 500);
			$("#settingsMenu1").show("slide", { direction: "left" }, 500);
			$("#settingsMenu3").show("slide", { direction: "left" }, 500);
			$("#settingsMenu2").show("slide", { direction: "left" }, 500);
			$("#restoreData").hide("slide", { direction: "left" }, 500);
			$("#backupData").hide("slide", { direction: "left" }, 500);
			$("#editRates").hide("slide", { direction: "left" }, 500);
			$("#listusers").hide("slide", { direction: "left" }, 500);
			$("#"+$(this).attr("class").split(" ")[0]).delay(500).show("slide", { direction: "right" }, 1000);
		});
	});

</script>

<body>

<div id="settingsMenu">
	<?php 		/* (1)EDIT PASSWORD - (2)EDIT DETAILS - (3)DISABLE ACCOUNT */
    echo'<div class="gridheaderleft">Database</div>';
		/*6*/ if($yes==2) echo '<button type="button" class="backupData ui-widget-content"><img src="../Ressources/IMG/backup.png" />Back-up Database</button> ';
		/*7*/ if($yes==2) echo '<button type="button" class="restoreData ui-widget-content"><img src="../Ressources/IMG/restore.png" />Restore Database</button> ';
  
	?>
	
	<div style="clear: both;"></div>
</div>
<div id="settingsMenu1">
	<?php 		/* (1)EDIT PASSWORD - (2)EDIT DETAILS - (3)DISABLE ACCOUNT */
    echo'<div class="gridheaderleft">Users</div>';
		if($yes==2) echo'<button type="button" class="listusers ui-widget-content"><img src="../Ressources/IMG/list.png"/><br />List All Users</button>';
	?>	
	<div style="clear: both;"></div>
</div>
<div id="settingsMenu2">
	<?php 		/* (1)EDIT PASSWORD - (2)EDIT DETAILS - (3)DISABLE ACCOUNT */
    echo'<div class="gridheaderleft">Finance</div>';
if($yes==2) echo '<button type="button" class="editRates ui-widget-content"><img src="../Ressources/IMG/currency_black_pound.png" /><br/>Edit Rates</button> ';
	?>
	
	<div style="clear: both;"></div>
</div>
<div id="settingsMenu3">
	<?php 		/* (1)EDIT PASSWORD - (2)EDIT DETAILS - (3)DISABLE ACCOUNT */
    echo'<div class="gridheaderleft">Modules</div>';
if($yes==2) echo '<button id="moduless" name="modules" value="Admin modules" type="button"><img src="../Ressources/IMG/modules.jpg" /><br/>Modules</button> '; 
if($yes==2) echo '<button id="request" name="modules" value="Admin modules" type="button"><img src="../Ressources/IMG/modules.jpg" /><br/>Modules</button> ';  
	?>
	
	<div style="clear: both;"></div>
</div>
<div id="settingsMenu4">
	<?php 		/* (1)EDIT PASSWORD - (2)EDIT DETAILS - (3)DISABLE ACCOUNT */
    echo'<div class="gridheaderleft">General</div>';
if($yes==2) echo '<button type="button" class="addNews ui-widget-content"><img src="../Ressources/IMG/news.png" /><br/>Edit News</button> ';
		echo '<button type="button" class="changePassword ui-widget-content"><img src="../Ressources/IMG/password.png" />Change Password</button> ';
echo '<button type="button" class="editDetails ui-widget-content"><img src="../Ressources/IMG/pen.png" /><br/>Edit Details</button>';
				/*1*/ 
 echo '<button type="button" class="disableAccount ui-widget-content"><img src="../Ressources/IMG/skull.and.crossbones.png" /><br/>Disable Account</button> ';
if($yes==2) echo '<button type="button" class="editSemester ui-widget-content"><img src="../Ressources/IMG/add.png" /><br/>Add Semester</button><br/><br/>';
  
	?>
	
	<div style="clear: both;"></div>
</div>
<div id="addNews" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./newsForm.php'); ?></div>
<div id="changePassword" class="chosenSetting" style="display: none;"><?php include('./settingsChangePasswordForm.php'); ?></div>
<div id="editDetails" class="chosenSetting" style="display: none;"><?php  include('./settingsChangeDetailsForm.php'); ?></div>
<div id="disableAccount" class="chosenSetting" style="display: none;"><?php  include('./settingsDisableAccountForm.php'); ?></div>
<div id="permittedEmails" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./settingsPermittedEmailsForm.php'); ?></div>
<div id="backupData" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./settingsBackupForm.php'); ?></div>
<div id="restoreData" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./settingsRestoreForm.php'); ?></div>
<div id="editRates" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./settingsEditRatesForm.php'); ?></div>
<div id="editSemester" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./settingsEditSemesterForm.php'); ?></div>
<div id="listusers" class="chosenSetting" style="display: none;"><?php if($yes==2) include('./listAllUsers.php'); ?></div>
</div>
</div>
</div>
</body>
</html>
