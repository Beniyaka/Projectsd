<?php
if (isset($_POST['submit'])) {
		$oldPass="true";
	$newPass="false";


mysqli_query($link, "UPDATE Users SET activeUser='".$newPass."' WHERE usr='".$_SESSION['mysesi']."' AND activeUser='".$oldPass."'") or die(mysqli_error($link));

if(mysqli_affected_rows($link)==1){
	echo '<span class="success"><script>alert("You have successfully disabled your account..")</script></span>';
 echo "<script>window.location.assign('../index.php')</script>";
}else{
	echo '<span class="error">Something went wrong.</span>';
}
	}
if(isset($_POST['change'])){
	echo '<span class="success">Good choice..</span>';
 echo "<script>window.location.assign('./Adminindex.php')</script>";
 }
?>
<!DOCTYPE html>
<html>
<head>
<title>Change password</title>
</head>
<script type="text/javascript" >



	$( "#newPassForm" ).submit(function(event) {
		event.preventDefault();
		$("#viewResult").html("");
		var pass=0;
		
		$(".error").html("");	
		$(".ok").removeClass("ok");
		$(".no").removeClass("no");
		
		if( $("#oldPass").val()=="" || $("#oldPass").val()==null ){ 
			$("#oldPass").parent().addClass("no");
			$("#oldPassError").html("Please enter your old password");
			pass=1;
		}else {
			$("#oldPass").parent().addClass("ok");
		}

		if( $("#newPass1").val()=="" || $("#newPass1").val()==null ){ 
			$("#newPass1").parent().addClass("no");
			$("#newPass1Error").html("Please enter a new password");
			pass=1;
		}else if( $("#newPass1").val().length <6 ){ 
			$("#newPass1").parent().addClass("no");
			$("#newPass1Error").append("Password must be 6 characters or more.");
			pass=1;
		}else {
			$("#newPass1").parent().addClass("ok");
		}
		
		if( $("#newPass2").val()!=$("#newPass1").val() ){ 
			$("#newPass2").parent().addClass("no");
			$("#newPass2Error").html("must match previous entry");
			pass=1;
		}else {
			$("#newPass2").parent().addClass("ok");
		}
		
		if(pass==0){
			$.post('./Content/settingsChangePassword.php', $("#newPassForm").serialize(), function(data) {
					$("#viewResult").append(data);
			});
		}
		
	});
	


</script>
<body>
<div id="viewResult"></div>

<form id="newPassForm" method="post">
	<h1>You are about to disable your account.</h1>
<br /><h2>If you are sure about that, Click on the disable button</h2>
<br /><h2>If you are not sure about that, Click on the Changed of mind button</h2>	
	<input id="submitForm" name="submit" value="Disable account" class="input" type="submit"/>
	<input id="submitForm" name="change" value="Changed my mind" class="input" type="submit"/>
</form>
</body>
</html>