<title>Change Password - MyLab Helper Allocation</title>

<style type="text/css">

	form span { padding: 10px; }
	.ok { background-color: #D3EEAB; }
	.no { background-color: #edabac; }
	form span input { font-size: 1.2em;  }
	#submitForm { font-size: 1em; padding: 3px; }

</style>
<script type="text/javascript" >



	$( "#newPassForm" ).submit(function(event) {
		event.preventDefault();
		$("#viewResult").html("");
		var pass=0;
		
		$(".error").html("");	
		$(".ok").removeClass("ok");
		$(".no").removeClass("no");
		
		if( $("#oldPass").val()=="" || $("#oldPass").val()==null ){ 
			$("#oldPass").parent().addClass("no");
			$("#oldPassError").html("Please enter your old password");
			pass=1;
		}else {
			$("#oldPass").parent().addClass("ok");
		}

		if( $("#newPass1").val()=="" || $("#newPass1").val()==null ){ 
			$("#newPass1").parent().addClass("no");
			$("#newPass1Error").html("Please enter a new password");
			pass=1;
		}else if( $("#newPass1").val().length <6 ){ 
			$("#newPass1").parent().addClass("no");
			$("#newPass1Error").append("Password must be 6 characters or more.");
			pass=1;
		}else {
			$("#newPass1").parent().addClass("ok");
		}
		
		if( $("#newPass2").val()!=$("#newPass1").val() ){ 
			$("#newPass2").parent().addClass("no");
			$("#newPass2Error").html("must match previous entry");
			pass=1;
		}else {
			$("#newPass2").parent().addClass("ok");
		}
		
		if(pass==0){
			$.post('./settingsChangePassword.php', $("#newPassForm").serialize(), function(data) {
					$("#viewResult").append(data);
			});
		}
		
	});
	


</script>

<div id="viewResult"></div>

<form id="newPassForm" action="/">
	<label for="oldPass">Old Password</label><br />
		<span><input type="password" name="oldPass" id="oldPass" class="input" /><span id="oldPassError" class="error"></span></span><br /><br />
		<?php echo'<input name="nam" value="'.$names.'" hidden= "true"/>'?>
	<label for="newPass1">New Password</label><br />
		<span><input type="password" name="newPass1" id="newPass1" class="input" /><span id="newPass1Error" class="error"></span></span><br /><br />
	<label for="newPass2">Confirm New Password</label><br />
		<span><input type="password" name="newPass2" id="newPass2" class="input" /><span id="newPass2Error" class="error"></span></span><br /><br />
	<input id="submitForm" name="submitForm" value="Change Password" class="input" type="submit"/>
</form>
