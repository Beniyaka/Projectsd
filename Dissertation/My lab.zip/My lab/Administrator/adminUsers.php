<?php
$db_host		= 'localhost';
$db_user		= 'root';
$db_pass		= '';
$db_database	= 'mylab'; 

$domain_name = 'http://localhost/mylab/';

$email_domains[0] = '@hw.ac.uk';
$email_domains[1] = '@macs.hw.ac.uk';

$link = mysqli_connect($db_host,$db_user,$db_pass,$db_database) or die('Unable to establish a DB connection');
?>
<title>User List - Administrator - MyLab Helper Allocation</title>

<style type="text/css">

	#userTable { max-height: 600px; overflow: auto; display: inline-block; }
	#userModules { width: 275px; padding: 10px; display: none; }
	table { border-collapse: collapse; margin-right: auto; margin-left: auto;}
	td,th { margin:0px; padding: 3px 10px 3px 10px; }
	#userTable table tr:not(:first-child):hover { 
		background-color: #306fcc;
		color: #ffffff;
	}
</style>

<script type="text/javascript" >

$(function () {
	
		$( "#dialog:ui-dialog" ).dialog( "destroy" );
	
		$( "#userModules" ).dialog({
			autoOpen: false,
			resizable: false,
			height:"auto",
			width: "auto",
			modal: true,
			buttons: {
				OK: function() {
					$( this ).dialog( "close" );
				}
			}
		});
	
	
	$("tr").click(
		function () {
			//$('#userModules table').html('<img src="./Ressources/IMG/load-circle.gif" alt="loading.." />');
   		//$("#userModules").show();
   		$.post('./Content/adminUserModules.php', { 'usr':$(this).attr("id"), "mTerm":$("#years").val() }, function(data) {
				$('#userModules table').html(data);
				$( "#userModules" ).dialog( "open" );
			});
  		});
});

</script>

<form id="selectYear" action="./" method="GET">
		<select name="years" id="years" onchange="this.form.submit()" style="float:right;">
			<?php
				$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y, Modules M WHERE T.termYearID=Y.tYearID  AND M.mTerm=T.termID GROUP BY T.termID ORDER BY T.termID DESC");
				
				while($row=mysqli_fetch_assoc($sqlTerms)){
					if(!isset($first)) $first = $row['termID'];
					if($_GET['years']==$row['termID']) $chosen =$row['termID'];
					echo '<option value="'.$row['termID'].'" '.(($_GET['years']==$row['termID'])?"selected=\"selected\"":"").' >'.$row['tYearStart']."-".$row['tYearEnd'].": Semester ".$row['term'].'</option>';
				}
				if(!isset($chosen)) $chosen=$first;
			?>
		</select>
		<?php 
			$years='?years='.$chosen;
			echo '<button type="button" onclick="window.open(\'../Content/printTimetables.php'.$years.'\')" style="float:right;" >Print All User Info For selected Term</button>';
		?>
</form><br />

<div id="userModules">
	<h3>Modules</h3><br />
		<table>
		
		</table>
</div>



<div id="userTable">
<table>

<?php

$sqlUsers = mysqli_query($link, "SELECT U.usr, U.accType, IF(U.accType='Lecturer',L.lFirstName,H.hFirstName) AS firstName, IF(U.accType='Lecturer',L.lSurname,H.hSurname) AS lastName,
IF(U.accType='Helper',(SELECT COUNT(MH.ttID) FROM ModuleHelpers MH, Modules M, Timetable T WHERE MH.aproved='true' AND MH.helperID=H.hID AND M.mID=T.mID AND T.ttID=MH.ttID AND M.mTerm=".$chosen." GROUP BY MH.helperID, T.mID), 
(SELECT COUNT(ML.mID) FROM ModuleLecturers ML, Modules M WHERE ML.lecturerID=L.lecturerID AND M.mID=ML.mID AND M.mTerm=".$chosen." GROUP BY ML.lecturerID)) AS moduleCount 
 FROM Users U, Lecturers L, Helpers H, Modules MM WHERE U.accType!='Administrator' AND
 (IF(U.accType='Helper',(SELECT COUNT(MH.ttID) FROM ModuleHelpers MH, Modules M, Timetable T WHERE MH.aproved='true' AND MH.helperID=H.hID AND M.mID=T.mID AND T.ttID=MH.ttID AND M.mTerm=".$chosen." GROUP BY MH.helperID, T.mID), 
(SELECT COUNT(ML.mID) FROM ModuleLecturers ML, Modules M WHERE ML.lecturerID=L.lecturerID AND M.mID=ML.mID AND M.mTerm=".$chosen." GROUP BY ML.lecturerID)))>0
  AND (U.usr=H.usr OR U.usr=L.usr) GROUP BY U.usr ORDER BY U.accType") or die(mysqli_error($link));

echo '<tr><th>User</th><th>First Name</th><th>Surname</th><th>Account Type</th><th>Assigned To</th></tr>';

while($rowU = mysqli_fetch_assoc($sqlUsers)){
	echo '<tr id="'.$rowU['usr'].'" class="'.$rowU['accType'].'">';
	echo '<td>'.$rowU['usr'].'</td><td>'.$rowU['firstName'].'</td><td>'.$rowU['lastName'].'</td><td>'.$rowU['accType'].'</td><td>'.((isset($rowU['moduleCount']))?$rowU['moduleCount']:'0').'</td>';
	echo '</tr>';
}

?>
</table>
</div>

<div style="clear:both;"> </div>
