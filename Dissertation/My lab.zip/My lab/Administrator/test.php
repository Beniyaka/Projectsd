<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <?php include("./baseInclude.php"); ?>
    
<script type="text/javascript" >
$(function() {
	$(".tabs a:last-child").css("border-radius","0px 6px 6px 0px");
	$(".tabs a:first-child").css("border-radius"," 6px 0px 0px 6px");
	$( "a", ".tabs" ).button();
});
</script>

</head>

<body>


<div id="main">
	<div class="container">
		<div id="middle">
			<?php 
				include('../Content/settings.php');
			?>
		</div>
    </div>
    
	<div class="container tutorial-info noPrint">
  		This website was developed by <a href="http://drewboswell.net/" style="text-decoration:none;"><span style="font-style:italic; font: 16px/1 Lobster,Arial,sans-serif;"> Andrew Boswell </span>.</a>
 	</div>
</div>

</body>
</html>

