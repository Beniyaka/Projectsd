<?php
	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	
	if(isset($_POST['SQLDataName'])){
	
		define('INCLUDE_CHECK',true);
		require '../connect.php' ;
	
		$dumpfile = "./backups/".$_POST['SQLDataName'];
		system("mysql -h$db_host -u$db_user -p$db_pass $db_database < $dumpfile", $retVal);
	
		if($retVal==0){ 
			echo 'Database Restore Successful';
		}
	}
?>