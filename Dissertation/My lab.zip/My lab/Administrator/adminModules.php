<?php
define('INCLUDE_CHECK',true);
require '../connect.php';
require '../functions.php';
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <?php include("./baseInclude.php"); ?>
    
<script type="text/javascript" >
$(function() {
	$(".tabs a:last-child").css("border-radius","0px 6px 6px 0px");
	$(".tabs a:first-child").css("border-radius"," 6px 0px 0px 6px");
	$( "a", ".tabs" ).button();
});
</script>

</head>

<div id="main">
	<div class="container">
	
<title>Module List - Administrator - MyLab Helper Allocation</title>

<style type="text/css">
	#userTable table { border-collapse: collapse; margin-left: auto; margin-right: auto; }
	#userTable table td,th { margin:0px; padding: 3px 10px 3px 10px; }
	#userTable { max-height: 600px; overflow: auto; }
	#userTable table tr:not(:first-child):hover { 
		background-color: #306fcc;
		color: #ffffff;
		cursor: pointer;
	}
	
	#selectYear { float: right; display: block;}
	
	#moduleInfo { width: 600px; }
	#moduleInfo table { border: 1px solid black; padding: 20px; border-collapse: collapse; }
	#moduleInfo table th { border: 1px solid black; background-color: #dedede; }
	#moduleInfo table td { border: 1px solid black; padding: 10px; vertical-align: top; }
	#moduleInfo table td ul { list-style-type: none; }
	
	
</style>

<script type="text/javascript" >
	$(function(){
		$(".modules").click(function(){
			var moduleID=$(this).attr("id");
			$.post('./viewModule.php', {"mID" : moduleID }, function(data) {
				$("#moduleInfo").html(data+ '<a href="./?pg=addModuleForm&mID='+moduleID+'"><button type="button" class="editModule" class="ui-widget"> Edit </button></a>');
				$( "#moduleInfo" ).dialog( "open" );
			});
		});
		
		$( "#dialog:ui-dialog" ).dialog( "destroy" );
	
		$( "#moduleInfo" ).dialog({
			autoOpen: false,
			resizable: false,
			height:"auto",
			width: "auto",
			modal: true,
			buttons: {
				OK: function() {
					$( this ).dialog( "close" );
				}
			}
		});
	});
</script>

<form id="selectYear" method="GET">
	<select name="years" id="years" onchange="this.form.submit()">
		<?php
			echo '<option value="all" '.(($_GET['years']=="all")?"selected=\"selected\"":"").'>All</option>';
			$sqlTerms = mysqli_query($link, "SELECT T.termID, T.term, Y.tYearStart, Y.tYearEnd FROM Terms T, TermYears Y WHERE T.termYearID=Y.tYearID ORDER BY T.termID DESC");
			while($row=mysqli_fetch_assoc($sqlTerms)){
				echo '<option value="'.$row['termID'].'" '.(($_GET['years']==$row['termID'])?"selected=\"selected\"":"").' >'.$row['tYearStart']."-".$row['tYearEnd'].": Semester ".$row['term'].'</option>';
			}
		?>
	</select>
</form>

<div style="clear: both;"></div><br>

<div id="userTable">

<table>

<?php

$specify = "";

if(isset($_GET['years']) && $_GET['years']!="all"){ $specify = "AND T.termID=".$_GET['years']; }

$sqlUsers = mysqli_query($link, "SELECT M.mID, M.mCode, M.mName, ( SELECT COUNT(*) FROM ModuleHelpers MH, Timetable TT WHERE MH.ttID=TT.ttID AND TT.mID=M.mID) AS helpers, TY.tYearStart AS tyear, TY.tYearEnd AS tyear2, T.term AS tsem 
											FROM Modules M, Terms T, TermYears TY 
											WHERE M.mTerm=T.termID AND T.termYearID=TY.tYearID $specify 
											ORDER BY TY.tYearStart DESC, T.term DESC") or die(mysqli_error($link));

echo '<tr><th>Module Code</th><th>Module Name</th><th>Helpers</th><th>term</th></tr>';

while($rowU = mysqli_fetch_assoc($sqlUsers)){
	echo '<tr id="'.$rowU['mID'].'" class="modules">';
	echo '<td>'.$rowU['mCode'].'</td> <td>'.$rowU['mName'].'</td><td>'.$rowU['helpers'].'</td><td>'.$rowU['tyear'].'-'.$rowU['tyear2'].' sem '.$rowU['tsem'].'</td>';
	echo '</tr>';
}

if(mysqli_affected_rows($link)==0){ echo '<tr><td><h2>None.</h2></td></tr>'; }

?>
</table>
</div>
</div>
</div>

<div id="moduleInfo" style="display: none;" ></div>
