<?php
	
	if($_POST['backup']=='true'){
	
		define('INCLUDE_CHECK',true);
		require '../connect.php' ;
		
		$dumpfile = "./backups/".$db_database . "_" . date("Y-m-d_H-i-s") . ".sql";
		
		system("/usr/bin/mysqldump --opt --host=$db_host --user=$db_user --password=$db_pass $db_database > $dumpfile");
		// must look like "-- Dump completed on ..." 
		system("tail -1 $dumpfile");
	
	}

?>