<?php

	session_name('mylabLogin');
	session_set_cookie_params(2*7*24*60*60);
	session_start();
	
	define('INCLUDE_CHECK',true);
	require '../connect.php' ;

	$sqlUsers = mysqli_query($link, "SELECT M.mName 
												FROM Modules M, ModuleLecturers ML, ModuleHelpers MH, Users U, Lecturers L, Helpers H, Timetable T 
												WHERE ((M.mID=ML.mID AND L.lecturerID=ML.lecturerID AND U.usr=L.usr) OR (MH.ttID=T.ttID AND T.mID=M.mID AND H.hID=MH.helperID AND U.usr=H.usr)) 
														AND U.usr='".$_POST['usr']."' AND M.mTerm=".$_POST['mTerm']." GROUP BY M.mCode") or die(mysqli_error($link));
	
	if(mysqli_affected_rows($link)){
		while($rowU = mysqli_fetch_assoc($sqlUsers)){
			echo '<tr>';
			echo '<td>'.$rowU['mName'].'</td>';
			echo '</tr>';
		}
	}else echo '<h2>none</h2>';
?>