<?php 
	if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
?>

<title>Restore MyLab Database - MyLab Helper Allocation</title>

<style type="text/css">
	#restore div { font-size: 1.2em; margin: 10px; text-align: center; display: block; }
	
	table { border-collapse: collapse; margin-right: auto; margin-left: auto; }
	td,th { margin:0px; padding: 3px 20px 3px 20px; }
	#restoreTable { max-height: 600px; overflow: auto; }
	tr:not(:first-child):hover { 
		background-color: #306fcc;
		color: #ffffff;
		cursor: pointer;
	}
	
</style>

<script type="text/javascript" >
		
		//$( "div", "#restore" ).button();
		$( ".restore" ).click(function(event) { 
			event.preventDefault();
			var fileName = $(this).attr("id");
			$.post("./Content/adminRestore.php",{ 'SQLDataName': fileName }, function(data){
				if(data!="" && data!=null){ $("#restoreResponse").removeClass("err").addClass("success").html(data+'<meta HTTP-EQUIV="REFRESH" content="2; url=./?pg=settings"/>');
				}else 
				$("#restoreResponse").removeClass("success").addClass("err").html("There was an error restoring your database. Wait a bit and try again, if the problem persists please contact the administrator.");
			});
			return false;
		});

</script>

<div id="restore">
	
	<div id="restoreTable">
	<?php
		if ($entries = scandir('./Content/backups/', 1)) {
    		echo "Directory handle: $handle<br>";
    		echo "<h3>MyLab Backup File Entries</h3><br>";
    		echo "<span id=\"restoreResponse\"></span><br>";
    		
    		echo '<table><tr><th>Date</th><th>Time</th><th>File Name</th></tr>';
	
	    	for($z=0; $z<sizeof($entries); $z++) {
	    		$entry=$entries[$z];
	    	   if ($entry != "." && $entry != "..") {
		    	   	$parts = explode("_",$entry);
  	  		   	$date=$parts[1];
  	  		   	$times=explode("-",$parts[2]);
   	 	   	$time=$times[0].":".$times[1].":". str_replace( ".sql","",$times[2]);
   	         echo "<tr class=\"restore\" id=\"$entry\"><td>$date</td><td>$time</td><td>$entry</td></tr>";
   	     }
   	 	}
			echo '</table>';
   	 	closedir($handle);
		}
	?>
	</div>
</div>
