<?php 

if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');

$lLoginSession =  mysqli_real_escape_string($link, md5($_GET['pass']));
$sqlLoginSession = mysqli_query($link, "SELECT username,email,type FROM password WHERE password='".$lLoginSession."'");

$row = mysqli_fetch_assoc($sqlLoginSession);
?>

<?php
	if($row['type'] == 'reset'){
		include('./password.php');
	} else {
		echo "Your link has either expired or incomplete information was given<br> please try registering again";
	}
?>