<link rel="shortcut icon" href="../Ressources/IMG/logo.ico" type="image/x-icon"/>
<?php
define('INCLUDE_CHECK',true);
require '../connect.php';
require '../functions.php';
?>
<a><img class="me" src="../Ressources/IMG/testt.jpg"/><a class="just"><img src="../Ressources/IMG/logo.png"/></a><a href="./index.php"><button class="button">Welcome</button></a></a>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php include("baseInclude.php"); ?>
    <link rel="stylesheet" type="text/css" href="../Ressources/CSS/main.css" media="screen" />
    
<style type="text/css">
		
#txt{
	font-size: 14px;
	 position:absolute;
    right: 0;
}

.push{
	width: 50%;
	font-size: 14px;
	padding: 0 18px;
  height: 29px;
  font-size: 12px;
  font-weight: bold;
  color: #527881;
  text-shadow: 0 1px #e3f1f1;
  background: #cde5ef;
  border: 1px solid;
  border-color: #b4ccce #b3c0c8 #9eb9c2;
  border-radius: 16px;
  outline: 0;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  background-image: -webkit-linear-gradient(top, #edf5f8, #cde5ef);
  background-image: -moz-linear-gradient(top, #edf5f8, #cde5ef);
  background-image: -o-linear-gradient(top, #edf5f8, #cde5ef);
  background-image: linear-gradient(to bottom, #edf5f8, #cde5ef);
  -webkit-box-shadow: inset 0 1px white, 0 1px 2px rgba(0, 0, 0, 0.15);
  box-shadow: inset 0 1px white, 0 1px 2px rgba(0, 0, 0, 0.15);
}

#main {
  margin: 0 auto;
  padding: 5px 20px;
  width: 500px;
  background: white;
  border-radius: 3px;
  -webkit-box-shadow: 0 0 200px rgba(255, 255, 255, 0.5), 0 1px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0 0 200px rgba(255, 255, 255, 0.5), 0 1px 2px rgba(0, 0, 0, 0.3);
}
</style>
</head>
<script>
	function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
</script>

<body onload="startTime()">
<div id="header">
<div id="txt"></div><h1 id="text">Lab Helper System Password Reset</h1>
</div>
<div id="main">
<div class="container">

    
<?php 
					if(isset($_GET['pg']) && isset($_GET['pass']) && $_GET['pg'] != "" && $_GET['pass'] != "") {
   					$pg = $_GET['pg'];
    					if (file_exists('./'.$pg.'.php')) {
    						@include ('./'.$pg.'.php');
    					}else
						@include ('../Content/404.inc');
					}
					else
						echo "<script>window.location.assign('../login.php')</script>";
?>

    </div>
    </div>
</body>
<div id="footer">
<h3>This website was developed by <a href="http://ibktech.tk/en/Our-Team/#wb_element_instance149" style="text-decoration:none;"><span style="font-style:italic; font: 16px/1 Lobster,Arial,sans-serif;"> Beni Iyaka </span>.</a></h3>
</div>
</html>
