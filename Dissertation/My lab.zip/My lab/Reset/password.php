<?php 
if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');
if(isset($_POST['submit'])){
	
	$newPass=md5($_POST['password']);
	$username = $_POST['usr'];
	$email = $_POST['email'];


mysqli_query($link, "UPDATE Users SET pswd='".$newPass."' WHERE usr='".$username."'") or die(mysqli_error($link));
$sqlDeleteSession = mysqli_prepare($link, "DELETE FROM password WHERE usr = ? ");
mysqli_stmt_bind_param($sqlDeleteSession, 's', $username);
				
if(mysqli_affected_rows($link)==1){
	mysqli_stmt_execute($sqlDeleteSession) or die(mysqli_errno($link));
	mysqli_stmt_close($sqlDeleteSession);
	
	$message ="You hav successfully changed your password
				username = .$username.
				password = .$_POST['password'].";
						 
			$to = $_POST['email']; 
			$subject = 'MyLab Password Reset - Successfully reset the password';
		
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			$headers .= "Content-type: text/html\r\n";
			$headers = 'From: password@mylab.macs.hw.ac.uk' . "\r\n" .
			'Reply-To: reply@example.com' . "\r\n" .
			'X-Mailer: PHP/' . phpversion();
			
			mail($to, $subject, $message, $headers);
	echo '<div class="success" align="center">You have successfully changed your password.</div>
			<meta HTTP-EQUIV="REFRESH" content="3; url=../login.php"/>';
}else{
	echo '<div class="err" align="center">Password change failed, please try again.</div>';
}
	
}

?>
<script>
	$(document).ready(function() {
  $("#check").keyup(validate);
});


function validate() {
  var password1 = $("#password").val();
  var password2 = $("#check").val();

    
 
    if(password1 == password2) {
       $("#success").show(); 
    $("#validate-status").hide();
       $("#submit").show();       
    }
    else {
        $("#validate-status").show();
        $("#submit").hide();
        $("#success").hide();  
    }
    
}

</script>
<title>MyLab Password Reset</title>
<style type="text/css">
		label { font-size: 1em; font-weight: bold; }
		.error { color: red; }
</style>
<div align="center">
	<form method="post">
						<input type="hidden" name="email" id="email" value="<?php echo $row['email']; ?>"/>
						<input type="hidden" name="usr" id="usr" value="<?php echo $row['username']; ?>"/>	
		<label for="password">Choose Password <span style="color: red;">*</span></label><br />
			<input type="password" name="password" id="password" required="true"/><br /><br />
			
		<label for="phone">Verify Password <span style="color: red;">*</span></label><br />
			<input type="password" name="check" id="check" required="true"/></span><br /><br />			
	<input class="push" type="submit" id="submit" name="submit" value="Reset" hidden="true" style="display: none"/><br /><br />
	<p id="validate-status" class="err" style="display: none">Password does not match</p>
	<p id="success" class="success" style="display: none">Correct password</p>
	</form>
</div>