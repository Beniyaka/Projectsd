<?php

if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');

$db_host		= 'db4free.net';
$db_user		= 'wonderben';
$db_pass		= 'Wonder12';
$db_database	= 'mylab1'; 

$domain_name = 'http://ibktech.tk/Mylab';


$email_domains[0] = '@hw.ac.uk';
$email_domains[1] = '@macs.hw.ac.uk';

$CVdir = "userUploadedFiles/cvs/files/";
$suppStDir = "userUploadedFiles/supportingStatements/files";

$link = mysqli_connect($db_host,$db_user,$db_pass,$db_database) or die('Unable to establish a DB connection');

mysqli_query($link, "SET names UTF8");

?>
