import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;

public class TextAnalysisC {

/**
 * @param args the command line arguments
 */
public static void main(String[] args) {
    Scanner sc = new Scanner( System.in );
    System.out.println( "Please enter a line of text" );
    String userInput = sc.nextLine();

    userInput = userInput.toLowerCase();

    userInput = userInput.replaceAll( "\\W", " " );     // strip out any non words.
    userInput = userInput.replaceAll( "  ", " " );      // strip out any double spaces
                                                        //   created from stripping out non words
                                                        //   in the first place!
    String[] tokens = userInput.split( " " );

    ArrayList< String > items = new ArrayList< String >();

    items.addAll( Arrays.asList( tokens ) );

    int count = 0;

    for( int i = 0; i < items.size(); i++ )
    {
        if( items.get( i ).equals( "***" ) )    // skip words marked as duplicate
            continue;                           //   not essential, only in the interests 
                                                //   of reducing clock cycles
        for( int j = 0; j < items.size(); j++ )
        {
            if( items.get( i ).equals( items.get( j ) ) )
                count++;
            if( items.get( i ).equals( items.get( j ) ) && count > 1 )
            {
                items.remove( j );
                items.add( j, "***" );                   
            }
        }                                                     
        count = 0;
    }

    for( int i = 0; i < items.size(); i++ )     // time to strip out "***"
        if( items.get( i ).equals( "***" ) )
            items.remove( i-- );            // remove then post decrement i
                                            //   due to shifting ArrayList indexes

    int[] countArray = new int[ items.size() ];

    for( int i = 0; i < items.size(); i++ )     // count frequency of words into countArray
        for( int j = 0; j < tokens.length; j++ )
            if( items.get( i ).equals( tokens[ j ]) )
                countArray[ i ]++;

    System.out.println();

    for( int i = 0; i < items.size(); i++ )     // print results into crude table
        System.out.printf( "%s: %d\n", items.get( i ), countArray[ i ] );
}
}