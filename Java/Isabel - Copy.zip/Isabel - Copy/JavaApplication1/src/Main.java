import java.util.Scanner;

/**
 *
 
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() 
    {
        Scanner cin=new Scanner(System.in);
        System.out.println("Enter the number of rows in matrix A : ");
        A_row=cin.nextInt();
        System.out.println("Enter the number of columns in matrix A : ");
        A_col=cin.nextInt();
        System.out.println("Enter the number of rows in matrix B : ");
        B_row= cin.nextInt();
        System.out.println("Enter the number of columns in matrix B : ");
        B_col=cin.nextInt();
        
        if(A_col==B_row)
        {
            matrix_A=new int[A_row][A_col];
            matrix_B=new int[B_row][B_col];
            mult_ans=new int[A_row][B_col];
          System.out.println("Enter the elements of matrix A : ");
             for(int i=0;i<A_row;i++)
                 for(int j=0;j<A_col;j++)
                 {
                    matrix_A[i][j]=cin.nextInt();
                 }
          System.out.println("Enter the elements of matrix B : ");
            for(int i=0;i<B_row;i++)
                 for(int j=0;j<B_col;j++)
                 {
                    matrix_B[i][j]=cin.nextInt();  
                 }
             thread_pool=new mythread[A_row];
             
            for(int i=0;i<A_row;i++)
            {
                thread_pool[i]=new mythread(i);
                thread_pool[i].start();
            }
           System.out.println("The answer of the matrix A*B : "); 
             printer_thread=new threadprint[3];

                printer_thread[2]=new threadprint(mult_ans);
                printer_thread[2].start();

}
        else
        {
           System.out.print("!!! Can't multiply this matrixes !!! "); 
        }
         
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

new Main();

// TODO code application logic here
    }

private class mythread extends Thread
    {
        int index;
         
         mythread(int index)
         {
             this.index=index;
         }
        public void run() 
        {
            for(int i=0;i<B_col;i++)
            {
                for(int j=0;j<B_col;j++)
                {
                    mult_ans[index][i]+=matrix_A[index][j]*matrix_B[j][i];
                }
            }
        }
    }
    private class threadprint extends Thread
    {
        threadprint (int[][] matrix)
        {
            this.matrix=matrix;
        }
        public synchronized  void run()
        {
            for(int i=0;i<matrix.length;i++)
            {
                System.out.print("| ");
                for(int j=0;j<matrix[0].length;j++)
                {
                  System.out.print(matrix[i][j]+"  ");
                }
                System.out.println(" |");
            }
        }
        int[][] matrix;
    }
            
    private int A_row;
    private int A_col;
    private int B_row;
    private int B_col;
    private int[][] matrix_A;
    private int[][] matrix_B;
    private int[][] mult_ans;
    private mythread[] thread_pool;
    private threadprint[] printer_thread;
} 