////////////////////////////////////////////////////////////////
// School of Mathemaatics and Computer Science
// Heriot Watt University
//
// Computer Games Programming  February 2016
// Collision Detection
// 
//
//Author: Beni Iyaka
//
/////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <glut.h>
#include <time.h>
#include <string.h>
#include "Vector.h"

void display(void) {
	glClear(GL_COLOR_BUFFER_BIT);

	if(lights) {

		//Background Flag
		glBegin(GL_TRIANGLES);
		glColor3f(0.5,0.5,1.0);		//light blue
		glVertex2f(-1.0, -0.6);
		glVertex2f(0.8, 1.0);
		glVertex2f(-1, 1.0);
		//glVertex2f((-1.0/3.0), -1.0);
		glEnd();

		glBegin(GL_TRIANGLES);
		glColor3f(0.5,0.5,1.0);		//light blue
		glVertex2f(1.0, 0.6);
		glVertex2f(-0.8, -1.0);
		glVertex2f(1, -1.0);
		//glVertex2f((-1.0/3.0), -1.0);
		glEnd();

		glBegin(GL_POLYGON);
		glColor3f(1, 0.0, 0.0);	//red
		glVertex2f(1, 1);//top
		glVertex2f(1, 0.7);//top
		glVertex2f(-1.0,-1);//bottom
		glVertex2f(-1,-0.7);//bottom
		glEnd();

		glBegin(GL_POLYGON);
		glColor3f(1.0, 1, 0);		//yellow
		glVertex2f(0.8, 1);//top
		glVertex2f(1, 1);//top
		glVertex2f(-1.0,-0.7);//bottom
		glVertex2f(-1,-0.5);//bottom
		glEnd();

		glBegin(GL_POLYGON);
		glColor3f(1.0, 1, 0);		//yellow
		glVertex2f(-0.8,-1);//top
		glVertex2f(-1, -1);//top
		glVertex2f(1.0,0.7);//bottom
		glVertex2f(1,0.5);//bottom
		glEnd();


		//flag Star
		glBegin(GL_TRIANGLES);
		glColor3f(1.0, 1, 0);		//yellow
		glVertex2f(-0.85, 0.9);
		glVertex2f(-0.9, 0.8);
		glVertex2f(-0.8, 0.8);
		glEnd();
		
		glBegin(GL_TRIANGLES);
		glColor3f(1.0, 1, 0);		//yellow
		glVertex2f(-0.85, 0.7);
		glVertex2f(-0.98, 0.8);
		glVertex2f(-0.71, 0.8);
		glEnd();

		glBegin(GL_TRIANGLES);
		glColor3f(1.0, 1, 0);		//yellow
		glVertex2f(-0.85, 0.7);
		glVertex2f(-0.85, 0.9);
		glVertex2f(-0.95, 0.6);
		glEnd();

		glBegin(GL_TRIANGLES);
		glColor3f(1.0, 1, 0);		//yellow
		glVertex2f(-0.85, 0.7);
		glVertex2f(-0.85, 0.9);
		glVertex2f(-0.75, 0.6);
		glEnd();


		//shadows
		for (int i=0; i<totalNum; i++) {
			glColor4f(0.0,0.0,0.0,0.5);
			flatCircle(x[i]+x[i]/15,y[i]+(y[i]-1.0)/20, radius, 30);
		}

		//ball body
		for (int i=0; i<totalNum; i++) {
			float gAlph = glowAlph[i]-0.3;
			circle(x[i], y[i], colorR[i]+gAlph, colorG[i]+gAlph, colorB[i]+gAlph, radius,30);
			if(glowAlph[i] > 0.0) {
				glowAlph[i] -= 0.02;
				glow(x[i], y[i], colorR[i]+glowAlph[i],colorG[i]+glowAlph[i],colorB[i]+glowAlph[i],glowAlph[i], radius+.1,30);
				glColor3f(0.92/3.0, 0.33/3.0, 0.38/3.0);	//reddish
				bitmapText(-0.45, 0.85, "Collision!");
			}
		}

		//desk light. blinks when balls hit top of the screen
		glow(0, 1.0,  1,1,1, 0.8+lightGlow, 1, 30);
		if(lightGlow > 0.0) {
			lightGlow-=0.04;
		}

	}

	//lights out mode
	else {
		//corner lights
		glow(-1.0, 1.0,   -0.08,0.5,0.37, 0.3+lightGlow,	0.2,	30);
		glow( 1.0, 1.0,   0.5, 0.32, 0.03, 0.3+lightGlow,	0.2,	30);
		glow( 1.0,-1.0,   0.5, 0.32, 0.03, 0.3+lightGlow,	0.2,	30);
		glow(-1.0,-1.0,   -0.08,0.5,0.37, 0.3+lightGlow,	0.2,	30);

		//help text
		glColor4f(0.38, 0.92, 0.38, 0.1+lightGlow);
		if(lightGlow > 0.0) {
			lightGlow-=0.04;
		}


		//circle outlines
		for (int i=0; i<totalNum; i++) {
			glow(x[i],y[i],  colorR[i],colorG[i],colorB[i], 1.0, radius+.04, 30);
			glColor3f(0,0,0);
			flatCircle(x[i],y[i], radius,30);
			circleOutline(x[i], y[i], colorR[i]+glowAlph[i], colorG[i]+glowAlph[i], colorB[i]+glowAlph[i], radius,30);
			glColor4f(0.38, 0.92, 0.38, 0.1+lightGlow);
			bitmapText(-0.45, 0.85, "Collision!");
		}

		//collision glow
		for (int i=0; i<totalNum; i++) {
			if(glowAlph[i] > 0.0) {
				glowAlph[i] -= 0.02;
				glow(x[i], y[i], colorR[i]+glowAlph[i],colorG[i]+glowAlph[i],colorB[i]+glowAlph[i],glowAlph[i], radius+.1,30);
				glColor4f(0.38, 0.92, 0.38, 0.1+lightGlow);
				bitmapText(-0.45, 0.85, "Collision!");
			}

		}

	}
	glFlush();							//flush image to the screen
}




//mouse callback.
void mouse(int butt, int state, int x, int y) {
	if (state == GLUT_DOWN) {
		if(butt == GLUT_LEFT_BUTTON) {			//left click
			for(int i=0; i<totalNum; i++) {		//for every ball
				vx[i] /= 2;						//slow down x velocity
				vy[i] /= 2;						//slow down y velocity
			}
			glutPostRedisplay();
		}
		else if (butt == GLUT_RIGHT_BUTTON) {	//right click
			for(int i=0; i<totalNum; i++) {		//for every ball
				vx[i] *= 2;						//speed up x velocity
				vy[i] *= 2;						//speed up y velocity
			}
			glutPostRedisplay();
		}
	}
}

//The keyboard callback
void keyboard(unsigned char key, int x, int y) {
	int k = (int)key;
	if (k == 27)					//if the user types ESC
		exit(0);					//exit the program
	else if (k == 32){				//spacebar	toggles lights
		if(lights)
			lights = 0;
		else
			lights = 1;
	}
}

//reshape callback. adjusts both the clipping box and viewport. keeps proportions unchanged
void reshape(int w, int h) {
	float aspectRatio = 1.0;

	//Compute the aspect ratio of the resized window
	aspectRatio = (float)h / (float)w;

	// Adjust the clipping box
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	if (h >= w)
		gluOrtho2D(-1.0, 1.0, -aspectRatio, aspectRatio);
	else
		gluOrtho2D(-1.0/aspectRatio, 1.0/aspectRatio, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);

	//adjust the viewport
	glViewport(0, 0, w, h);
}


int main(int argc, char **argv) {
	initCircles();		//initialize circle values

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_SINGLE | GLUT_RGBA | GLUT_ALPHA);

	glutInitWindowPosition(0,0);					//window position
	glutInitWindowSize(WINDOW_SIZE, WINDOW_SIZE);	//window size
	glutCreateWindow ("Collision Detection");				//window name
	glClearColor(0.0, 0.0, 0.0, 0.0);				//background color
	glClear(GL_COLOR_BUFFER_BIT);

	//The four following statements set up the viewing rectangle
	glMatrixMode(GL_PROJECTION);					// use proj. matrix
	glLoadIdentity();								// load identity matrix
	gluOrtho2D(-1.0, 1.0, -1.0, 1.0);				// set orthogr. proj.
	glMatrixMode(GL_MODELVIEW);						// back to modelview m.

	glEnable (GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

	glutDisplayFunc(display);
	glutTimerFunc(waitTime, timer, 1);
	glutMouseFunc(mouse);
	glutKeyboardFunc(keyboard);
	glutReshapeFunc(reshape);

	glutMainLoop();
  	return 0;
}