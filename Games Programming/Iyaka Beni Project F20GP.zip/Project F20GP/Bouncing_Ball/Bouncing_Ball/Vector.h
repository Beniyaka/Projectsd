float WINDOW_SIZE = 500;
int totalNum = 4;			//total number of circles (10 by default)
float radius = 0.1;			//circle radius
int waitTime = 16;			//milliseconds between steps
//coordinates
float x[10];
float y[10];
//velocity
float vx[10];
float vy[10];
//new velocity
float newvx[10];
float newvy[10];
//color
float colorR[10];
float colorG[10];
float colorB[10];

float glowAlph[10];

int lights = 1;
float lightGlow = 0;
double M_PI = 3.14;

//Function to write a string to the screen at a specified location
void bitmapText(float x, float y, char* words) {
	int len = 0, i = 0;
	//Set the location where the string should appear
	glRasterPos2f(x,y);
	len = (int) strlen(words);
	//Set the character in the string to helvetica size 18
	for(int i = 0; i < len; i++) {
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,words[i]);
	}
}

//creates a gl triangle fan circle of indicated radius and segments
void flatCircle(float cx, float cy, float radius, int segments) {
	float phi, x1, y1;
	glBegin(GL_TRIANGLE_FAN);
	glVertex2f(cx, cy);					//center vertex
	for (int j = 0; j<=segments; j++) {	//for every segment,
		phi = 2 * M_PI * j / segments;	//calculate the new vertex
		x1 = radius * cos(phi) + cx;
		y1 = radius * sin(phi) + cy;
		glVertex2f(x1, y1);
	}
	glEnd();
} //end circle

//creates a gl triangle fan circle of indicated radius and segments
void circle(float cx, float cy,
			float outerR, float outerG, float outerB,
			float radius, int segments)
{
	float phi, x1, y1;
	glBegin(GL_TRIANGLE_FAN);
	//glColor3f(outerR+0.5, outerG+0.5, outerB+0.5);	//inner color
	glColor3f(outerR+0.3, outerG+0.3, outerB+0.3);	//inner color
	glVertex2f(cx, cy);								//center vertex
	glColor3f(outerR,outerG,outerB);				//outer color
	for (int j = 0; j<=segments; j++) {				//for every segment,
		phi = 2 * M_PI * j / segments;				//calculate the new vertex
		x1 = radius * cos(phi) + cx;
		y1 = radius * sin(phi) + cy;
		glVertex2f(x1, y1);
	}
	glEnd();
} //end circle

void circleOutline(float cx, float cy,
			float outerR, float outerG, float outerB,
			float radius, int segments)
{
	float phi, x1, y1;
	glBegin(GL_LINES);
	//glColor3f(outerR+0.5, outerG+0.5, outerB+0.5);	//inner color
	glColor3f(outerR+0.3, outerG+0.3, outerB+0.3);	//inner color
	//glVertex2f(cx, cy);								//center vertex
	//glColor3f(outerR,outerG,outerB);				//outer color
	for (int j = 0; j<=segments; j++) {				//for every segment,
		phi = 2 * M_PI * j / segments;				//calculate the new vertex
		x1 = radius * cos(phi) + cx;
		y1 = radius * sin(phi) + cy;
		glVertex2f(x1, y1);
		phi = 2 * M_PI * (j+1) / segments;				//calculate the new vertex
		x1 = radius * cos(phi) + cx;
		y1 = radius * sin(phi) + cy;
		glVertex2f(x1, y1);
	}
	glEnd();
} //end circle

void glow(float cx, float cy,
			float outerR, float outerG, float outerB, float outerA,
			float radius, int segments)
{
	float phi, x1, y1;
	glBegin(GL_TRIANGLE_FAN);
	glColor4f(outerR+0.5, outerG+0.5, outerB+0.5, outerA); //inner color
	glVertex2f(cx, cy);					//center vertex
	glColor4f(outerR,outerG,outerB,0.0);	//outer color
	for (int j = 0; j<=segments; j++) {	//for every segment,
		phi = 2 * M_PI * j / segments;	//calculate the new vertex
		x1 = radius * cos(phi) + cx;
		y1 = radius * sin(phi) + cy;
		glVertex2f(x1, y1);
	}
	glEnd();
} //end circle

void shadow(float cx, float cy,
			float outerR, float outerG, float outerB, float outerA,
			float radius, int segments)
{
	float phi, x1, y1;
	glBegin(GL_TRIANGLE_FAN);
	glColor4f(0.0, 0.0, 0.0, 1.0); //inner color
	glVertex2f(cx, cy);					//center vertex
	glColor4f(outerR,outerG,outerB,0.0);	//outer color
	for (int j = 0; j<=segments; j++) {	//for every segment,
		phi = 2 * M_PI * j / segments;	//calculate the new vertex
		x1 = radius * cos(phi) + cx;
		y1 = radius * sin(phi) + cy;
		glVertex2f(x1, y1);
	}
	glEnd();
} //end circle

//initializes all circle posiitons, colors, and velocities
void initCircles(void) {
	srand(time(NULL));							// seed the random number generator
	for(int i=0; i<totalNum; i++){				// for each circle,
		//current position
		x[i] = ((rand()%(int)(200-(radius*200)))/100.0)-(1.0-radius); //  random number between
		y[i] = ((rand()%(int)(200-(radius*200)))/100.0)-(1.0-radius); //    -0.9 and 0.9 (to account for radius size)
		//color values
		colorR[i] = (rand()%10)/10.0;			//	random color values
		colorG[i] = (rand()%10)/10.0;			//	  between 0 and 1
		colorB[i] = (rand()%10)/10.0;
		//velocity
		vx[i] = ((rand()%200)/10000.0)-0.01; 	//	random velocities between
		vy[i] = ((rand()%200)/10000.0)-0.01; 	//	  -0.02 and 0.02

		glowAlph[i] = 0.0;
	}
}

void timer(int value) {

	//Actually move the circles
	for(int i=0; i<totalNum; i++) {
		x[i] += vx[i];
		y[i] += vy[i];
	}


	//resolve collisions
	for(int i=0; i<totalNum; i++) {	//for each ball,
		// Reverse direction when you reach edges
	    if(x[i] > 1.0 - radius ) {		//right edge
	    	x[i] = 1.0-radius;				//to prevent balls from sticking
	       	vx[i] = -vx[i];					//change velocity
	       	lightGlow = 1;					//create a glow
	    }
	    else if(x[i] < -1.0 + radius) {	//left edge
	    	x[i] = -1.0+radius;				///to prevent balls from sticking
	    	vx[i] = -vx[i];					//change velocity
	    	lightGlow = 1;					//create a glow
	    }

	    if(y[i] > 1.0 - radius){		//top edge
	    	y[i] = 1.0 - radius;			//to prevent balls from sticking
	    	vy[i] = -vy[i];					//change velocity
	    	lightGlow = 1;					//create a glow
	    }
	    else if(y[i] < -1.0 + radius) {	//bottom edge
	    	y[i] = -1.0 + radius;			//to prevent balls from sticking
	    	vy[i] = -vy[i];					//change velocity
	    	lightGlow = 1;					//create a glow
	    }


	    for(int j=i+1; j<totalNum; j++) {	//second ball

	    	//vector between the centers of two circles
	    	float dx = x[i] - x[j];
	    	float dy = y[i] - y[j];

	    	//square of its magnitude
	    	float dSq = dx*dx + dy*dy;

	    	if (dSq <= 4.0*radius*radius) {
	    		//vector of difference of velocities
	    		float dvx = vx[j] - vx[i];
	    		float dvy = vy[j] - vy[i];

	    		//dot product of d and dv
	    		float dP = dx*dvx + dy*dvy;

	    		if (dP > 0.0) { //if they are moving towards eachother
	    			float factor = dP / dSq;

	    			float xChange = dx * factor;
	    			float yChange = dy * factor;

	    			//add change to the velocity of the first circle
	    			vx[i] += xChange;
	    			vy[i] += yChange;

	    			//subtract change from the velocity of tht second circle
	    			vx[j] -= xChange;
	    			vy[j] -= yChange;

	    			glowAlph[i] = 0.8;	//create a glow in first ball
	    			glowAlph[j] = 0.8;	//create a glow in second ball
	    		}
	    		//*/
	    	}
	    } //end for j
	} //end for i

	glutPostRedisplay();
	glutTimerFunc(waitTime, timer, 1);
}
