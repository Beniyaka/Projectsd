package beni.ibk.com;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class CountryEdit extends Activity implements OnClickListener{

 private Spinner continentList;
 private Button save, delete;
 private String mode;
 private EditText code, name, capital, population, area, language, province ;
 private String id;

 @Override
 public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  setContentView(R.layout.detail_page);

  // get the values passed to the activity from the calling activity
  // determine the mode - add, update or delete
  if (this.getIntent().getExtras() != null){
   Bundle bundle = this.getIntent().getExtras();
   mode = bundle.getString("mode");
  }

  // get references to the buttons and attach listeners
  save = (Button) findViewById(R.id.save);
  save.setOnClickListener(this);
  delete = (Button) findViewById(R.id.delete);
  delete.setOnClickListener(this);

  code = (EditText) findViewById(R.id.code);
  name = (EditText) findViewById(R.id.name);
  capital = (EditText) findViewById(R.id.Capital);
  population = (EditText) findViewById(R.id.Population);
  area = (EditText) findViewById(R.id.Area);
  language = (EditText) findViewById(R.id.Language);
  province = (EditText) findViewById(R.id.Province);

  
  // create a dropdown for users to select various continents
  continentList = (Spinner) findViewById(R.id.continentList);
  ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
    R.array.continent_array, android.R.layout.simple_spinner_item);
  adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  continentList.setAdapter(adapter);

  // if in add mode disable the delete option
  if(mode.trim().equalsIgnoreCase("add")){
   delete.setEnabled(false);
  }
  // get the rowId for the specific country 
  else{
   Bundle bundle = this.getIntent().getExtras();
   id = bundle.getString("rowId");
   loadCountryInfo();
  }

 }

 public void onClick(View v) {

  // get values from the spinner and the input text fields
  String myContinent = continentList.getSelectedItem().toString();
  String myCode = code.getText().toString();
  String myName = name.getText().toString();
  String myCapital = capital.getText().toString();
  String myPopulation = population.getText().toString();
  String myArea = area.getText().toString();
  String myLanguage = language.getText().toString();
  String myProvince = province.getText().toString();

  // check for blanks
  if(myCode.trim().equalsIgnoreCase("")){
   Toast.makeText(getBaseContext(), "Please ENTER country code", Toast.LENGTH_LONG).show();
   return;
  }

  // check for blanks
  if(myName.trim().equalsIgnoreCase("")){
   Toast.makeText(getBaseContext(), "Please ENTER country name", Toast.LENGTH_LONG).show();
   return;
  }
  //check for blanks
  if(myCapital.trim().equalsIgnoreCase("")){
   Toast.makeText(getBaseContext(), "Please ENTER capital city", Toast.LENGTH_LONG).show();
   return;
  }
  //check for blanks
  if(myPopulation.trim().equalsIgnoreCase("")){
   Toast.makeText(getBaseContext(), "Please ENTER population density", Toast.LENGTH_LONG).show();
   return;
  }
 //check for blanks
 if(myArea.trim().equalsIgnoreCase("")){
  Toast.makeText(getBaseContext(), "Please ENTER Surface area", Toast.LENGTH_LONG).show();
   return;
 }
 //check for blanks
 if(myLanguage.trim().equalsIgnoreCase("")){
  Toast.makeText(getBaseContext(), "Please ENTER official language", Toast.LENGTH_LONG).show();
  return;
 }
 //check for blanks
 if(myProvince.trim().equalsIgnoreCase("")){
  Toast.makeText(getBaseContext(), "Please ENTER number of provinces", Toast.LENGTH_LONG).show();
  return;
 }

  
  switch (v.getId()) {
  case R.id.save:
   ContentValues values = new ContentValues();
   values.put(CountriesDb.KEY_CODE, myCode);
   values.put(CountriesDb.KEY_NAME, myName);
   values.put(CountriesDb.KEY_CONTINENT, myContinent);
   values.put(CountriesDb.KEY_CAPITAL, myCapital);
   values.put(CountriesDb.KEY_POPULATION, myPopulation);
   values.put(CountriesDb.KEY_AREA, myArea);
   values.put(CountriesDb.KEY_LANGUAGE, myLanguage);
   values.put(CountriesDb.KEY_PROVINCE, myProvince);
   
   // insert a record
   if(mode.trim().equalsIgnoreCase("add")){
    getContentResolver().insert(StudentsProvider.CONTENT_URI, values);
   }
   // update a record
   else {
    Uri uri = Uri.parse(StudentsProvider.CONTENT_URI + "/" + id);
    getContentResolver().update(uri, values, null, null);
   }
   finish();
   break;

  case R.id.delete:
   // delete a record
   Uri uri = Uri.parse(StudentsProvider.CONTENT_URI + "/" + id);
   getContentResolver().delete(uri, null, null);
   finish();
   break;

   // More buttons go here (if any) ...

  }
 }

 // based on the rowId get all information from the Content Provider 
 // about that country
 private void loadCountryInfo(){

  String[] projection = { 
    CountriesDb.KEY_ROWID,
    CountriesDb.KEY_CODE, 
    CountriesDb.KEY_NAME, 
    CountriesDb.KEY_CONTINENT,
    CountriesDb.KEY_CAPITAL,
    CountriesDb.KEY_POPULATION,
    CountriesDb.KEY_AREA,
    CountriesDb.KEY_LANGUAGE,
    CountriesDb.KEY_PROVINCE};
  Uri uri = Uri.parse(StudentsProvider.CONTENT_URI + "/" + id);
  Cursor cursor = getContentResolver().query(uri, projection, null, null,
    null);
  if (cursor != null) {
   cursor.moveToFirst();
   String myCode = cursor.getString(cursor.getColumnIndexOrThrow(CountriesDb.KEY_CODE));
   String myName = cursor.getString(cursor.getColumnIndexOrThrow(CountriesDb.KEY_NAME));
   String myContinent = cursor.getString(cursor.getColumnIndexOrThrow(CountriesDb.KEY_CONTINENT));
   String myCapital = cursor.getString(cursor.getColumnIndexOrThrow(CountriesDb.KEY_CAPITAL));
   String myPopulation = cursor.getString(cursor.getColumnIndexOrThrow(CountriesDb.KEY_POPULATION));
   String myArea = cursor.getString(cursor.getColumnIndexOrThrow(CountriesDb.KEY_AREA));
   String myLanguage = cursor.getString(cursor.getColumnIndexOrThrow(CountriesDb.KEY_LANGUAGE));
   String myProvince = cursor.getString(cursor.getColumnIndexOrThrow(CountriesDb.KEY_PROVINCE));
   code.setText(myCode);
   name.setText(myName);
   capital.setText(myCapital);
   population.setText(myPopulation);
   area.setText(myArea);
   language.setText(myLanguage);
   province.setText(myProvince);
   continentList.setSelection(getIndex(continentList, myContinent));
   
  }


 }

 // this sets the spinner selection based on the value 
 private int getIndex(Spinner spinner, String myString){

  int index = 0;

  for (int i=0;i<spinner.getCount();i++){
   if (spinner.getItemAtPosition(i).equals(myString)){
    index = i;
   }
  }
  return index;
 }

}